import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "src_market.db"))
PERSISTENCE_PATH = os.getenv("PERSISTENCE_PATH", str(BASE_DIR / "src_vault_bot_data.pkl"))

# VPS manual setup:
# 1. Replace the bot token placeholder with the token from @BotFather.
# 2. The admin and channel IDs below are already configured for this install.
# Do not paste either value into chat or publish this file.
MANUAL_BOT_TOKEN = "8156309751:AAHbbCG8pye4xjVxnwDOVb9dfm8kU4bmnFg"
MANUAL_ADMIN_ID = 8732101004

# Environment variables are still accepted for hosts that use them, but a
# standalone VPS can run by editing the two manual values above.
BOT_TOKEN = os.getenv("BOT_TOKEN") or os.getenv("NOVA_BOT_TOKEN") or MANUAL_BOT_TOKEN
ADMIN_ID = int(os.getenv("ADMIN_ID") or MANUAL_ADMIN_ID or 0)
OWNER_UPI_ID = os.getenv("OWNER_UPI_ID", "kumarchx@fam")
BINANCE_ID = os.getenv("BINANCE_ID", "CURENTLY OFF")
BINANCE_USD_TO_INR = 100.0
VERIFY_API_URL = os.getenv(
    "VERIFY_API_URL",
    "https://payment-verify-hcas.vercel.app/api/verify",
)
VERIFY_API_KEY = os.getenv("VERIFY_API_KEY", "")
UPDATES_CHANNEL_URL = os.getenv(
    "UPDATES_CHANNEL_URL",
    "https://t.me/dimpiii_modz",
)
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "nezuko_ff")
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID", "-1003999455078") or 0)
PRODUCT_CHANNEL_ID = int(
    os.getenv("PRODUCT_CHANNEL_ID", "-1004387714081") or 0
)
PLATFORM_FEE_DEFAULT = float(os.getenv("PLATFORM_FEE", "10"))
MAX_FILE_MB = 50
MIN_PRICE = 49
UTR_LIMIT_PER_HOUR = 5
API_MAX_DAYS = 90
API_FULFILLMENT_HOURS = 4
API_PLAN_MONTHS = (1, 2, 3)

# Premium emoji IDs supplied for this bot. Names are semantic so they can be
# swapped later without editing handler messages.
EMOJI = {
    "sparkles": "5325547803936572038",
    "heart": "4958839553424098323",
    "candle": "4958866680437539780",
    "skull": "4956461073550017373",
    "party": "5461151367559141950",
    "celebration": "5370870691140737817",
    "star": "5994754629785620754",
    "balloon": "4956234552679859009",
    "flower": "6314282625896815974",
    "cart": "4956418939920843885",
    "rocket": "6172332822892647766",
    "champagne": "4956619819836244992",
    "hugs": "5397890811436213746",
    "screen": "5282843764451195532",
    "link": "5271604874419647061",
    "cowboy": "6226346516290736268",
    "dancer": "6226326360009216194",
    "red_heart": "6226231879318638710",
    "red_heart_alt": "6228569320780205775",
    "symbols": "6228539638261223848",
    "symbols_alt": "6228964930217840689",
    "crying": "6228674530299089855",
    "star_alt": "6229040921074208708",
    "excited": "6228809027199963519",
    "happy": "6231157502432514075",
    "gift_alt": "6228673014175632845",
    "smile": "5461117441612462242",
    "lightning": "5456140674028019486",
    "comet": "5224607267797606837",
    "stop": "5260293700088511294",
    "shop": "5229064374403998351",
    "no_entry": "5240241223632954241",
    "money": "4958839553424098323",
    "verified": "5994754629785620754",
    "code": "4956234552679859009",
    "shield": "6314282625896815974",
    "warning": "4956619819836244992",
    "wave": "6006051952847230749",
    "robot": "6181483972271283011",
    "phone": "5404350824501491839",
    "id_card": "5422683699130933153",
    "credit_card": "5445353829304387411",
    "announcement": "6267129592998270736",
    "back": "5352759161945867747",
    "cash": "6327624928916935858",
    "package": "5463172695132745432",
    "support": "6181677091180779929",
    "admin": "6088920147072915408",
}

CATEGORIES = ("Bot", "Website", "App", "Script", "API", "Other")