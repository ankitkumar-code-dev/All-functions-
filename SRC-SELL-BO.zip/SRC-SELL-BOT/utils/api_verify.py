import aiohttp

from ..config import VERIFY_API_KEY, VERIFY_API_URL


async def verify_payment(utr: str, amount: float, upi_id: str) -> tuple[bool, dict]:
    """Verify a UTR using the configured payment API.

    The supplied payment verifier uses GET query parameters named txn_id and
    amount. The optional bearer token remains supported for private verifier
    deployments, but the UPI ID is not sent because it is not part of the
    supplied verifier contract.
    """
    if not VERIFY_API_URL:
        return False, {"status": "error", "error": "Verification API is not configured"}
    url = VERIFY_API_URL.rstrip("/")
    headers = {"Authorization": f"Bearer {VERIFY_API_KEY}"} if VERIFY_API_KEY else {}
    params = {"txn_id": utr, "amount": f"{amount:.2f}"}
    try:
        timeout = aiohttp.ClientTimeout(total=25)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url, params=params, headers=headers) as response:
                data = await response.json(content_type=None)
                if not isinstance(data, dict):
                    data = {"status": "error", "response": str(data)}
                status = str(data.get("status") or data.get("result") or "").lower()
                verified_amount = data.get("amount") or data.get("amount_inr")
                amount_matches = True
                if verified_amount not in (None, ""):
                    try:
                        amount_matches = abs(float(verified_amount) - float(amount)) < 0.01
                    except (TypeError, ValueError):
                        amount_matches = False
                ok = response.ok and status == "success" and amount_matches
                return ok, data
    except Exception as exc:
        return False, {"status": "error", "error": type(exc).__name__}