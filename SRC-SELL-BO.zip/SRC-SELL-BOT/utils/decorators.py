from functools import wraps

from ..config import ADMIN_ID


def owner_only(handler):
    @wraps(handler)
    async def wrapped(update, context, *args, **kwargs):
        if update.effective_user and update.effective_user.id == ADMIN_ID:
            return await handler(update, context, *args, **kwargs)
        if update.callback_query:
            await update.callback_query.answer("Owner access only.", show_alert=True)
        elif update.message:
            await update.message.reply_text("⛔ Owner access only.")
        return None
    return wrapped