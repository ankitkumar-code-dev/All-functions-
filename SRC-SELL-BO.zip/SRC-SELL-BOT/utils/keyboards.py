import re
import unicodedata

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

try:
    from telegram import CopyTextButton
except ImportError:  # python-telegram-bot versions without native copy buttons
    CopyTextButton = None


EMOJI_IDS = {
    "announcement": "6267129592998270736",
    "user": "5316705578670636235",
    "screen": "5282843764451195532",
    "link": "5271604874419647061",
    "money": "6327624928916935858",
    "cart": "5440841102871517055",
    "profile": "5422683699130933153",
    "back": "5352759161945867747",
    "stop": "4956337889593000947",
    "cash": "4956601935592424315",
    "box": "5463172695132745432",
    "card": "5445353829304387411",
    "shield": "5197288647275071607",
    "key": "5307843983102204243",
    "group": "5453957997418004470",
    "plus": "5039891861246838069",
    "search": "5039649904264217620",
    "phone": "5404350824501491839",
    "message": "6181240211402400565",
    "admin": "6088920147072915408",
    "warning": "6089429233841478230",
    "star": "6229040921074208708",
    "celebrate": "6181390707056451332",
    "package": "5229064374403998351",
    "developer": "6181483972271283011",
    "task": "5040017274291880943",
}


_EMOJI_RANGES = (
    (0x1F000, 0x1FAFF),  # Miscellaneous symbols and pictographs
    (0x1FC00, 0x1FFFF),  # Supplementary pictographs
    (0x2190, 0x21FF),    # Arrows commonly used as button emoji
    (0x2300, 0x23FF),    # Technical symbols
    (0x2600, 0x27BF),    # Miscellaneous symbols and dingbats
    (0x2B00, 0x2BFF),    # Miscellaneous symbols and arrows
)
_EMOJI_EXTRAS = {
    0x00A9, 0x00AE, 0x203C, 0x2049, 0x2122, 0x2139,
    0x3030, 0x303D, 0x3297, 0x3299,
}
_EMOJI_FORMAT_CHARS = {0x200D, 0x20E3, 0xFE0E, 0xFE0F}


def _plain_button_text(text: str) -> str:
    """Remove Unicode emoji from labels; custom Telegram icons remain."""
    cleaned = []
    for character in str(text):
        codepoint = ord(character)
        in_emoji_range = any(
            start <= codepoint <= end for start, end in _EMOJI_RANGES
        )
        if (
            in_emoji_range
            or codepoint in _EMOJI_EXTRAS
            or codepoint in _EMOJI_FORMAT_CHARS
            or unicodedata.category(character) == "So"
        ):
            continue
        cleaned.append(character)
    return re.sub(r"\s{2,}", " ", "".join(cleaned)).strip()


def _button_presentation(text: str, action: str) -> tuple[str, str]:
    """Choose a Telegram button style and a supplied premium emoji ID."""
    haystack = f"{text} {action}".casefold()

    if any(token in haystack for token in (
        "cancel", "reject", "❌", "report", "remove", "delete", "ban",
        "refund", "danger", "⛔", "🚫",
    )):
        style = "danger"
    elif any(token in haystack for token in (
        "approve", "verify", "joined", "genuine", "restore", "submit",
        "confirm", "complete", "buy", "deposit", "add", "create", "✅",
        "♻", "➕",
    )):
        style = "success"
    else:
        style = "primary"

    icon = "screen"
    semantic_icons = (
        (("back", "home", "previous", "◀", "↩", "🔙"), "back"),
        (("account", "profile", "seller", "user", "👤"), "profile"),
        (("admin", "security", "🛡"), "admin"),
        (("balance", "fund", "earning", "withdraw", "money", "₹", "💰", "💸"), "money"),
        (("deposit", "wallet", "payment", "💳"), "card"),
        (("cart", "store", "product", "purchase", "buy", "🛒", "🛍", "🏪"), "cart"),
        (("listing", "src", "package", "📦"), "package"),
        (("api", "code", "developer", "🔌", "💻"), "developer"),
        (("task", "earn", "🎯", "📋"), "task"),
        (("review", "rate", "⭐"), "star"),
        (("offer", "chat", "message", "support", "📞", "💬"), "message"),
        (("channel", "updates", "📢", "📣"), "announcement"),
        (("join", "url", "link", "open", "↗"), "link"),
        (("search", "find", "🔎"), "search"),
        (("warning", "error", "report", "⚠"), "warning"),
        (("security", "shield", "🔐"), "shield"),
        (("key", "access", "🔑"), "key"),
        (("seller", "creator", "👨‍💻"), "developer"),
        (("preview", "view", "screen", "🖥"), "screen"),
        (("withdraw", "cash", "💵"), "cash"),
    )
    for tokens, semantic in semantic_icons:
        if any(token in haystack for token in tokens):
            icon = semantic
            break

    return style, EMOJI_IDS[icon]


def _api_kwargs(style: str, icon_custom_emoji_id: str) -> dict:
    return {
        "style": style,
        "icon_custom_emoji_id": str(icon_custom_emoji_id),
    }


def btn(
    text: str,
    callback: str,
    *,
    style: str | None = None,
    icon_custom_emoji_id: str | None = None,
) -> InlineKeyboardButton:
    """Create a styled callback button using Bot API fields supported by PTB."""
    inferred_style, inferred_icon = _button_presentation(text, callback)
    return InlineKeyboardButton(
        _plain_button_text(text),
        callback_data=callback,
        api_kwargs=_api_kwargs(
            style or inferred_style,
            icon_custom_emoji_id or inferred_icon,
        ),
    )


def url_btn(
    text: str,
    url: str,
    *,
    style: str = "primary",
    icon_custom_emoji_id: str | None = None,
) -> InlineKeyboardButton:
    _, inferred_icon = _button_presentation(text, url)
    return InlineKeyboardButton(
        _plain_button_text(text),
        url=url,
        api_kwargs=_api_kwargs(style, icon_custom_emoji_id or inferred_icon),
    )


def copy_btn(
    text: str,
    value: str,
    *,
    style: str = "primary",
    icon_custom_emoji_id: str | None = None,
) -> InlineKeyboardButton:
    """Add Telegram's native copy-to-clipboard button."""
    _, inferred_icon = _button_presentation(text, "copy")
    kwargs = _api_kwargs(style, icon_custom_emoji_id or inferred_icon)
    if CopyTextButton is None:
        return InlineKeyboardButton(
            _plain_button_text(text),
            callback_data="noop",
            api_kwargs=kwargs,
        )
    return InlineKeyboardButton(
        _plain_button_text(text),
        copy_text=CopyTextButton(text=(value or "No description")[:256]),
        api_kwargs=kwargs,
    )


def main_menu(
    owner: bool = False,
    display_name: str = "Account",
    updates_url: str = "",
) -> InlineKeyboardMarkup:
    rows = [
        [btn(f"👤 {display_name[:24]} Account", "account")],
        [btn("💰 Balance", "balance"), btn("👤 Profile", "profile")],
        [btn("🌑 Earn", "earn"), btn("🏪 Store", "store"), btn("💳 Deposit", "deposit")],
        [btn("📊 Dashboard", "dashboard"), btn("📞 Support", "support")],
    ]
    rows.append(
        [url_btn("📢 Official Updates Channel ↗", updates_url)]
        if updates_url
        else [btn("📢 Official Updates Channel ↗", "updates")]
    )
    if owner:
        rows.append([btn("🛡 Admin Panel", "admin")])
    return InlineKeyboardMarkup(rows)


def profile_menu(verified: bool = False, owner: bool = False) -> InlineKeyboardMarkup:
    seller_label = (
        "✅ Owner Seller Center"
        if owner
        else "✅ Verified Seller Center"
        if verified
        else "👨‍💻 Become a Verified Seller"
    )
    seller_callback = "seller_center" if (verified or owner) else "verify_seller"
    return InlineKeyboardMarkup([
        [btn("💰 Balance", "balance"), btn("🌑 Earn", "earn")],
        [btn("📘 My Purchases", "my_purchases"), btn("📜 Transactions", "transactions")],
        [btn("⭐ My Reviews", "reviews")],
        [btn(seller_label, seller_callback)],
        [btn("↩️ Back to Home", "menu")],
    ])


def earning_tasks_menu(
    has_tasks: bool = False, has_history: bool = False
) -> InlineKeyboardMarkup:
    rows = []
    if has_tasks:
        rows.append([btn("📋 Available Tasks", "earn_tasks")])
    if has_history:
        rows.append([btn("📜 My Task History", "earn_history")])
    if not has_tasks:
        rows.append([btn("🔔 Notify me", "earn_notify")])
    rows.append([btn("↩️ Back to Home", "menu")])
    return InlineKeyboardMarkup(rows)


def seller_center_menu(verified: bool = False, owner: bool = False) -> InlineKeyboardMarkup:
    if not verified and not owner:
        return profile_menu(verified=False, owner=False)
    rows = [
        [btn("➕ Add Product", "sell"), btn("🔌 Add API Add-on", "sell_api")],
        [btn("📦 My Products", "my_listings")],
        [btn("💬 My Offers", "seller_offers")],
        [btn("💰 Funds", "seller_funds"), btn("💸 Withdraw", "withdraw")],
        [btn("👁 Preview Profile", "seller_preview")],
    ]
    rows.append([btn("↩️ Back to Profile", "profile")])
    return InlineKeyboardMarkup(rows)


def task_detail_menu(task_id: int, channel_url: str) -> InlineKeyboardMarkup:
    rows = []
    if channel_url:
        rows.append([url_btn("📢 Join Channel", channel_url)])
    rows.append([btn("✅ I Joined — Verify", f"task_claim:{task_id}")])
    rows.append([btn("↩️ Back to Tasks", "earn_tasks")])
    return InlineKeyboardMarkup(rows)


def task_list_menu(tasks: list[dict]) -> InlineKeyboardMarkup:
    rows = [
        [btn(f"🎯 {task['title'][:38]} · ₹{float(task['reward']):.0f}", f"task_view:{task['id']}")]
        for task in tasks
    ]
    rows.append([btn("↩️ Back to Earn", "earn")])
    return InlineKeyboardMarkup(rows)


def back_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[btn("↩️ Back to Home", "menu")]])


def api_plan_menu(
    listing_id: int, monthly_price: float, months: tuple[int, ...] = (1, 2, 3)
) -> InlineKeyboardMarkup:
    rows = [
        [
            btn(
                f"📅 {month} Month{'s' if month != 1 else ''} · "
                f"₹{float(monthly_price) * month:.2f}",
                f"api_plan:{listing_id}:{month}",
            )
        ]
        for month in months
    ]
    rows.append([btn("↩️ Back to Product", f"listing:{listing_id}")])
    return InlineKeyboardMarkup(rows)


def api_request_menu(request_id: int, listing_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [btn("📤 Submit API Access", f"api_deliver:{request_id}")],
        [btn("💬 Chat Buyer", f"api_chat:{request_id}")],
        [btn("🏪 Open Listing", f"listing:{listing_id}")],
    ])