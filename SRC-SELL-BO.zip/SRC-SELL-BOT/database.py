import json
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

import aiosqlite

from .config import BINANCE_ID, DB_PATH, PLATFORM_FEE_DEFAULT, OWNER_UPI_ID


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def init_db() -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, last_name TEXT,
                role TEXT NOT NULL DEFAULT 'buyer', upi_id TEXT,
                joined_at TEXT NOT NULL, banned INTEGER NOT NULL DEFAULT 0,
                earnings REAL NOT NULL DEFAULT 0,
                wallet_balance REAL NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS seller_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
                full_name TEXT NOT NULL, email TEXT NOT NULL, upi_id TEXT NOT NULL,
                identity TEXT, portfolio TEXT, telegram_username TEXT DEFAULT '',
                telegram_user_id INTEGER, status TEXT NOT NULL DEFAULT 'pending',
                rejection_reason TEXT, created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS listings (
                id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id INTEGER NOT NULL,
                title TEXT NOT NULL, description TEXT NOT NULL, price REAL NOT NULL,
                category TEXT NOT NULL, file_id TEXT, file_type TEXT DEFAULT 'document',
                link TEXT, api_base_url TEXT, text_content TEXT,
                api_plans TEXT NOT NULL DEFAULT '[]',
                preview_file_id TEXT, preview_type TEXT,
                preview TEXT, status TEXT NOT NULL DEFAULT 'live',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT, buyer_id INTEGER NOT NULL,
                listing_id INTEGER NOT NULL, amount REAL NOT NULL, utr TEXT,
                status TEXT NOT NULL DEFAULT 'awaiting_payment',
                verified_at TEXT, created_at TEXT NOT NULL,
                duration_days INTEGER NOT NULL DEFAULT 30,
                duration_months INTEGER NOT NULL DEFAULT 1,
                monthly_price REAL NOT NULL DEFAULT 0,
                fulfillment_status TEXT NOT NULL DEFAULT 'not_required',
                fulfillment_deadline TEXT, seller_delivered_at TEXT
            );
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL,
                utr TEXT, screenshot_file_id TEXT, api_response TEXT, status TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS deposits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                reference TEXT NOT NULL UNIQUE,
                upi_id TEXT NOT NULL,
                utr TEXT,
                screenshot_file_id TEXT,
                provider_response TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                reviewed_by INTEGER,
                reviewed_at TEXT,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL UNIQUE,
                buyer_id INTEGER NOT NULL, seller_id INTEGER NOT NULL,
                rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
                comment TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS chat_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                listing_id INTEGER NOT NULL, buyer_id INTEGER NOT NULL,
                seller_id INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL, ended_at TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS api_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reference TEXT NOT NULL UNIQUE,
                order_id INTEGER NOT NULL UNIQUE,
                listing_id INTEGER NOT NULL,
                buyer_id INTEGER NOT NULL,
                seller_id INTEGER NOT NULL,
                duration_days INTEGER NOT NULL DEFAULT 30,
                duration_months INTEGER NOT NULL,
                monthly_price REAL NOT NULL,
                total_amount REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending_seller',
                deadline TEXT NOT NULL,
                access_payload TEXT,
                seller_note TEXT,
                submitted_at TEXT,
                validated_at TEXT,
                rejection_reason TEXT,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS wallet_credits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                order_id INTEGER NOT NULL UNIQUE,
                amount REAL NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS wallet_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                order_id INTEGER NOT NULL UNIQUE,
                amount REAL NOT NULL,
                transaction_type TEXT NOT NULL,
                reason TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS wallet_adjustments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                reason TEXT NOT NULL,
                actor_id INTEGER NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor_id INTEGER,
                event_type TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS earning_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                channel_ref TEXT NOT NULL,
                channel_id TEXT NOT NULL DEFAULT '',
                channel_link TEXT NOT NULL DEFAULT '',
                reward REAL NOT NULL CHECK(reward > 0),
                retention_days INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_by INTEGER NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS task_claims (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'credited',
                claimed_at TEXT NOT NULL,
                monitor_until TEXT NOT NULL,
                credited_at TEXT NOT NULL,
                clawed_back_at TEXT,
                failure_reason TEXT,
                UNIQUE(task_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS earning_task_notifications (
                user_id INTEGER PRIMARY KEY,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS support_issues (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                created_at TEXT NOT NULL,
                resolved_at TEXT,
                resolved_by INTEGER
            );
            CREATE TABLE IF NOT EXISTS offers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                listing_id INTEGER NOT NULL,
                buyer_id INTEGER NOT NULL,
                seller_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS withdrawal_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                upi_id TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                reviewed_by INTEGER,
                reviewed_at TEXT,
                note TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );
            """
        )
        # Marketplace commission is fixed at 10%: buyers pay the listed amount,
        # the seller receives 90%, and the remaining 10% stays with the owner.
        await db.execute(
            """
            INSERT INTO settings(key,value) VALUES('platform_fee',?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value
            """,
            (str(PLATFORM_FEE_DEFAULT),),
        )
        await db.execute(
            "INSERT OR IGNORE INTO settings(key,value) VALUES('auto_verify','1')"
        )
        await db.execute(
            "INSERT OR IGNORE INTO settings(key,value) VALUES('owner_upi',?)",
            (OWNER_UPI_ID,),
        )
        # Replace the old hard-coded payment address in existing SQLite
        # installs. The owner can still change it later from the admin panel.
        await db.execute(
            """
            UPDATE settings
            SET value=?
            WHERE key='owner_upi' AND lower(trim(value))='amankumar234@fam'
            """,
            (OWNER_UPI_ID,),
        )
        # Listings are published immediately after the seller upload flow.
        # Convert any rows left in the old approval queue to the new live state.
        await db.execute(
            "UPDATE listings SET status='live' WHERE status='pending_review'"
        )
        try:
            await db.execute("ALTER TABLE users ADD COLUMN earnings REAL NOT NULL DEFAULT 0")
        except Exception:
            pass
        try:
            await db.execute(
                "ALTER TABLE users ADD COLUMN wallet_balance REAL NOT NULL DEFAULT 0"
            )
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE users ADD COLUMN last_name TEXT DEFAULT ''")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE payments ADD COLUMN screenshot_file_id TEXT")
        except Exception:
            pass
        for column, definition in (
            ("duration_days", "INTEGER NOT NULL DEFAULT 30"),
            ("duration_months", "INTEGER NOT NULL DEFAULT 1"),
            ("monthly_price", "REAL NOT NULL DEFAULT 0"),
            ("fulfillment_status", "TEXT NOT NULL DEFAULT 'not_required'"),
            ("fulfillment_deadline", "TEXT"),
            ("seller_delivered_at", "TEXT"),
        ):
            try:
                await db.execute(f"ALTER TABLE orders ADD COLUMN {column} {definition}")
            except Exception:
                pass
        await db.execute(
            "UPDATE orders SET monthly_price=amount WHERE monthly_price=0 OR monthly_price IS NULL"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status, fulfillment_status)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_api_requests_status ON api_requests(status, deadline)"
        )
        for column, definition in (
            ("telegram_username", "TEXT DEFAULT ''"),
            ("telegram_user_id", "INTEGER"),
            ("file_type", "TEXT DEFAULT 'document'"),
            ("preview_file_id", "TEXT"),
            ("preview_type", "TEXT"),
            ("api_base_url", "TEXT DEFAULT ''"),
            ("api_plans", "TEXT DEFAULT '[]'"),
        ):
            try:
                await db.execute(
                    f"ALTER TABLE {'listings' if column in {'file_type', 'preview_file_id', 'preview_type', 'api_base_url', 'api_plans'} else 'seller_requests'} "
                    f"ADD COLUMN {column} {definition}"
                )
            except Exception:
                pass
        try:
            await db.execute(
                "ALTER TABLE api_requests ADD COLUMN duration_days INTEGER NOT NULL DEFAULT 30"
            )
        except Exception:
            pass
        for column, definition in (
            ("channel_id", "TEXT NOT NULL DEFAULT ''"),
            ("channel_link", "TEXT NOT NULL DEFAULT ''"),
        ):
            try:
                await db.execute(
                    f"ALTER TABLE earning_tasks ADD COLUMN {column} {definition}"
                )
            except Exception:
                pass
        await db.execute(
            """
            UPDATE earning_tasks
            SET channel_id=channel_ref
            WHERE channel_id='' AND channel_ref IS NOT NULL
            """
        )
        await db.commit()


async def ensure_user(user: Any) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO users(id,username,first_name,last_name,joined_at)
            VALUES(?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET username=excluded.username,
            first_name=excluded.first_name, last_name=excluded.last_name
            """,
            (
                user.id,
                user.username or "",
                user.first_name or "",
                user.last_name or "",
                now(),
            ),
        )
        await db.commit()
    return await get_user(user.id)


async def get_user(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM users WHERE id=?", (user_id,))
        row = await cur.fetchone()
    return dict(row) if row else None


async def get_or_create_chat_session(
    listing_id: int, buyer_id: int, seller_id: int
) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT * FROM chat_sessions
            WHERE listing_id=? AND buyer_id=? AND seller_id=? AND active=1
            ORDER BY id DESC LIMIT 1
            """,
            (listing_id, buyer_id, seller_id),
        )
        row = await cur.fetchone()
        if not row:
            cur = await db.execute(
                """
                INSERT INTO chat_sessions(listing_id,buyer_id,seller_id,created_at)
                VALUES(?,?,?,?)
                """,
                (listing_id, buyer_id, seller_id, now()),
            )
            session_id = cur.lastrowid
            await db.commit()
            cur = await db.execute(
                "SELECT * FROM chat_sessions WHERE id=?", (session_id,)
            )
            row = await cur.fetchone()
        return dict(row)


async def get_chat_session(session_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM chat_sessions WHERE id=?", (session_id,)
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def end_chat_session(session_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE chat_sessions SET active=0, ended_at=? WHERE id=?",
            (now(), session_id),
        )
        await db.commit()


async def set_role(user_id: int, role: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET role=? WHERE id=?", (role, user_id))
        await db.commit()


async def get_setting(key: str, default: str = "") -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = await cur.fetchone()
    return row[0] if row else default


async def set_setting(key: str, value: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        await db.commit()


async def get_force_join_channels() -> list[dict]:
    raw = await get_setting("force_join_channels", "[]")
    try:
        channels = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return []
    if not isinstance(channels, list):
        return []
    return [
        {
            "chat_id": str(item.get("chat_id", "")).strip(),
            "link": str(item.get("link", "")).strip(),
        }
        for item in channels
        if isinstance(item, dict)
        and str(item.get("chat_id", "")).strip()
        and str(item.get("link", "")).strip()
    ]


async def set_force_join_channels(channels: list[dict]) -> None:
    normalized = [
        {
            "chat_id": str(item.get("chat_id", "")).strip(),
            "link": str(item.get("link", "")).strip(),
        }
        for item in channels
        if str(item.get("chat_id", "")).strip()
        and str(item.get("link", "")).strip()
    ]
    await set_setting("force_join_channels", json.dumps(normalized))


async def create_support_issue(user_id: int, message: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO support_issues(user_id,message,created_at)
            VALUES(?,?,?)
            """,
            (user_id, message[:4000], now()),
        )
        await db.commit()
        return cur.lastrowid


async def list_open_support_issues(limit: int = 50) -> list[dict]:
    return await _many(
        """
        SELECT i.*, u.username, u.first_name, u.last_name
        FROM support_issues i
        LEFT JOIN users u ON u.id=i.user_id
        WHERE i.status='open'
        ORDER BY i.id DESC LIMIT ?
        """,
        (limit,),
    )


async def get_support_issue(issue_id: int) -> dict | None:
    return await _one(
        """
        SELECT i.*, u.username, u.first_name, u.last_name
        FROM support_issues i
        LEFT JOIN users u ON u.id=i.user_id
        WHERE i.id=?
        """,
        (issue_id,),
    )


async def resolve_support_issue(issue_id: int, resolved_by: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            UPDATE support_issues
            SET status='resolved', resolved_at=?, resolved_by=?
            WHERE id=? AND status='open'
            """,
            (now(), resolved_by, issue_id),
        )
        await db.commit()
    return await get_support_issue(issue_id)


async def create_earning_task(
    created_by: int,
    title: str,
    description: str,
    channel_ref: str,
    reward: float,
    retention_days: int,
    channel_id: str = "",
    channel_link: str = "",
) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO earning_tasks(
                title,description,channel_ref,channel_id,channel_link,
                reward,retention_days,created_by,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?)
            """,
            (
                title[:160],
                description[:2000],
                (channel_id or channel_ref)[:300],
                (channel_id or channel_ref)[:300],
                channel_link[:500],
                round(float(reward), 2),
                max(0, int(retention_days)),
                created_by,
                now(),
            ),
        )
        await db.commit()
        return cur.lastrowid


async def subscribe_to_earning_task_notifications(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT OR IGNORE INTO earning_task_notifications(user_id, created_at)
            VALUES(?,?)
            """,
            (user_id, now()),
        )
        await db.commit()
    return cur.rowcount > 0


async def list_earning_task_notification_users() -> list[int]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT user_id FROM earning_task_notifications ORDER BY created_at ASC"
        )
        rows = await cur.fetchall()
    return [int(row[0]) for row in rows]


async def clear_earning_task_notification(user_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM earning_task_notifications WHERE user_id=?", (user_id,)
        )
        await db.commit()


async def get_earning_task(task_id: int) -> dict | None:
    return await _one("SELECT * FROM earning_tasks WHERE id=?", (task_id,))


async def list_active_earning_tasks(limit: int = 50) -> list[dict]:
    return await _many(
        "SELECT * FROM earning_tasks WHERE active=1 ORDER BY id DESC LIMIT ?",
        (limit,),
    )


async def list_all_earning_tasks(limit: int = 100) -> list[dict]:
    return await _many(
        "SELECT * FROM earning_tasks ORDER BY id DESC LIMIT ?",
        (limit,),
    )


async def set_earning_task_active(task_id: int, active: bool) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE earning_tasks SET active=? WHERE id=?",
            (1 if active else 0, task_id),
        )
        await db.commit()
    return await get_earning_task(task_id)


async def get_task_claim(task_id: int, user_id: int) -> dict | None:
    return await _one(
        """
        SELECT c.*, t.title, t.reward, t.retention_days, t.channel_ref
        FROM task_claims c
        JOIN earning_tasks t ON t.id=c.task_id
        WHERE c.task_id=? AND c.user_id=?
        """,
        (task_id, user_id),
    )


async def list_user_task_claims(user_id: int, limit: int = 30) -> list[dict]:
    return await _many(
        """
        SELECT c.*, t.title, t.reward, t.retention_days, t.channel_ref
        FROM task_claims c
        JOIN earning_tasks t ON t.id=c.task_id
        WHERE c.user_id=? ORDER BY c.id DESC LIMIT ?
        """,
        (user_id, limit),
    )


async def claim_earning_task(
    user_id: int, task_id: int, monitor_until: str
) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM earning_tasks WHERE id=? AND active=1", (task_id,)
        )
        task = await cur.fetchone()
        if not task:
            await db.rollback()
            return None
        cur = await db.execute(
            "SELECT 1 FROM task_claims WHERE task_id=? AND user_id=?",
            (task_id, user_id),
        )
        if await cur.fetchone():
            await db.rollback()
            return None
        claimed_at = now()
        await db.execute(
            """
            INSERT INTO task_claims(
                task_id,user_id,status,claimed_at,monitor_until,credited_at
            ) VALUES(?,?,?,?,?,?)
            """,
            (task_id, user_id, "credited", claimed_at, monitor_until, claimed_at),
        )
        await db.execute(
            "UPDATE users SET earnings=earnings+? WHERE id=?",
            (round(float(task["reward"]), 2), user_id),
        )
        await db.commit()
    return await get_task_claim(task_id, user_id)


async def list_monitored_task_claims(limit: int = 200) -> list[dict]:
    return await _many(
        """
        SELECT c.*, t.title, t.reward, t.channel_ref
        FROM task_claims c
        JOIN earning_tasks t ON t.id=c.task_id
        WHERE c.status='credited' AND c.monitor_until > ?
        ORDER BY c.id ASC LIMIT ?
        """,
        (now(), limit),
    )


async def clawback_task_claim(claim_id: int, reason: str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT c.*, t.reward
            FROM task_claims c
            JOIN earning_tasks t ON t.id=c.task_id
            WHERE c.id=? AND c.status='credited'
            """,
            (claim_id,),
        )
        claim = await cur.fetchone()
        if not claim:
            await db.rollback()
            return None
        await db.execute(
            """
            UPDATE task_claims
            SET status='clawed_back', clawed_back_at=?, failure_reason=?
            WHERE id=? AND status='credited'
            """,
            (now(), reason[:500], claim_id),
        )
        await db.execute(
            """
            UPDATE users
            SET earnings=MAX(0, earnings-?)
            WHERE id=?
            """,
            (round(float(claim["reward"]), 2), claim["user_id"]),
        )
        await db.commit()
    return await _one(
        """
        SELECT c.*, t.title, t.reward, t.channel_ref
        FROM task_claims c JOIN earning_tasks t ON t.id=c.task_id
        WHERE c.id=?
        """,
        (claim_id,),
    )


async def get_payment_config() -> dict:
    """Return the active payment configuration without exposing secrets in logs."""
    upi_id = await get_setting("owner_upi", OWNER_UPI_ID)
    if upi_id == "your-upi@bank":
        upi_id = ""
    return {
        "upi_id": upi_id.strip(),
        "owner_name": (await get_setting("owner_name", "SRC Vault")).strip(),
        "qr_file_id": (await get_setting("owner_qr_file_id", "")).strip(),
        "binance_id": BINANCE_ID.strip(),
    }


async def create_deposit(user_id: int, amount: float, upi_id: str) -> dict:
    reference = f"SV{secrets.token_hex(5).upper()}"
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO deposits(user_id,amount,reference,upi_id,created_at)
            VALUES(?,?,?,?,?)
            """,
            (user_id, round(amount, 2), reference, upi_id, now()),
        )
        deposit_id = cur.lastrowid
        await db.commit()
    return await get_deposit(deposit_id)


async def get_deposit(deposit_id: int) -> dict | None:
    return await _one("SELECT * FROM deposits WHERE id=?", (deposit_id,))


async def list_user_deposits(user_id: int, limit: int = 20) -> list[dict]:
    return await _many(
        "SELECT * FROM deposits WHERE user_id=? ORDER BY id DESC LIMIT ?",
        (user_id, limit),
    )


async def list_pending_deposits(limit: int = 30) -> list[dict]:
    return await _many(
        """
        SELECT d.*, u.first_name, u.last_name, u.username
        FROM deposits d
        LEFT JOIN users u ON u.id=d.user_id
        WHERE d.status='pending'
        ORDER BY d.id ASC
        LIMIT ?
        """,
        (limit,),
    )


async def approve_manual_deposit(
    deposit_id: int, reviewer_id: int
) -> dict | None:
    """Approve a manually reviewed Binance deposit exactly once."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM deposits WHERE id=?", (deposit_id,)
        )
        row = await cur.fetchone()
        if not row or row["status"] != "pending":
            return dict(row) if row else None
        if not str(row["upi_id"] or "").startswith("BINANCE:"):
            await db.rollback()
            return None
        try:
            provider = json.loads(row["provider_response"] or "{}")
        except json.JSONDecodeError:
            provider = {}
        if provider.get("method") != "binance" or not provider.get("txid"):
            await db.rollback()
            return None
        provider.update({
            "method": "binance",
            "status": "success",
            "amount": round(float(row["amount"]), 2),
        })
        updated = await db.execute(
            """
            UPDATE deposits
            SET status='approved', reviewed_by=?, reviewed_at=?, provider_response=?
            WHERE id=? AND status='pending'
            """,
            (
                reviewer_id,
                now(),
                json.dumps(provider),
                deposit_id,
            ),
        )
        if updated.rowcount != 1:
            await db.rollback()
            return await get_deposit(deposit_id)
        await db.execute(
            "UPDATE users SET wallet_balance=wallet_balance+? WHERE id=?",
            (row["amount"], row["user_id"]),
        )
        await db.commit()
    return await get_deposit(deposit_id)


async def record_deposit_proof(
    deposit_id: int,
    utr: str,
    provider_response: dict,
    screenshot_file_id: str | None = None,
    status: str = "pending",
) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            UPDATE deposits
            SET utr=?, screenshot_file_id=?, provider_response=?, status=?
            WHERE id=? AND status='pending'
            """,
            (utr, screenshot_file_id, json.dumps(provider_response), status, deposit_id),
        )
        await db.commit()
    return await get_deposit(deposit_id)


async def approve_deposit(deposit_id: int, reviewer_id: int) -> dict | None:
    """Approve only a verified deposit, exactly once, and credit it once."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM deposits WHERE id=?", (deposit_id,)
        )
        row = await cur.fetchone()
        if not row or row["status"] != "pending":
            return dict(row) if row else None
        try:
            provider = json.loads(row["provider_response"] or "{}")
            provider_status = str(provider.get("status", "")).lower()
            verified_amount = round(float(provider.get("amount")), 2)
            verified = (
                provider_status in {"success", "verified", "approved"}
                and verified_amount == round(float(row["amount"]), 2)
            )
        except (TypeError, ValueError, json.JSONDecodeError):
            verified = False
        if not verified:
            await db.execute(
                """
                UPDATE deposits
                SET status='rejected', reviewed_by=?, reviewed_at=?
                WHERE id=? AND status='pending'
                """,
                (reviewer_id, now(), deposit_id),
            )
            await db.commit()
            return await get_deposit(deposit_id)
        updated = await db.execute(
            """
            UPDATE deposits
            SET status='approved', reviewed_by=?, reviewed_at=?
            WHERE id=? AND status='pending'
            """,
            (reviewer_id, now(), deposit_id),
        )
        if updated.rowcount != 1:
            await db.rollback()
            return await get_deposit(deposit_id)
        await db.execute(
            "UPDATE users SET wallet_balance=wallet_balance+? WHERE id=?",
            (row["amount"], row["user_id"]),
        )
        await db.commit()
    return await get_deposit(deposit_id)


async def reconcile_unverified_deposits() -> list[dict]:
    """Revoke legacy wallet credits that were approved without verification.

    Older database snapshots may contain an approved deposit whose provider
    response is an error. Those credits must not remain spendable.
    """
    revoked_requests: list[dict] = []
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM deposits WHERE status='approved' ORDER BY id"
        )
        approved = await cur.fetchall()
        for deposit in approved:
            provider = {}
            try:
                provider = json.loads(deposit["provider_response"] or "{}")
                provider_status = str(provider.get("status", "")).lower()
                verified_amount = round(float(provider.get("amount")), 2)
                verified = (
                    provider_status in {"success", "verified", "approved"}
                    and verified_amount == round(float(deposit["amount"]), 2)
                )
            except (TypeError, ValueError, json.JSONDecodeError):
                verified = False
            if verified:
                continue

            await db.execute(
                """
                UPDATE deposits
                SET status='rejected',
                    reviewed_at=?,
                    provider_response=?
                WHERE id=? AND status='approved'
                """,
                (
                    now(),
                    json.dumps({
                        "security_reconciliation": "rejected_unverified_approved_deposit",
                        "original_response": provider,
                    }),
                    deposit["id"],
                ),
            )
            await db.execute(
                """
                UPDATE users
                SET wallet_balance=MAX(
                    0, COALESCE(wallet_balance, 0)-?
                )
                WHERE id=?
                """,
                (float(deposit["amount"]), deposit["user_id"]),
            )
            cur = await db.execute(
                """
                SELECT r.*, l.title
                FROM api_requests r
                JOIN listings l ON l.id=r.listing_id
                JOIN wallet_transactions wt
                  ON wt.order_id=r.order_id AND wt.user_id=r.buyer_id
                WHERE r.buyer_id=?
                  AND wt.created_at >= ?
                  AND r.status IN ('pending_seller', 'submitted')
                """,
                (deposit["user_id"], deposit["created_at"]),
            )
            requests = await cur.fetchall()
            for request in requests:
                request_dict = dict(request)
                await db.execute(
                    """
                    UPDATE api_requests
                    SET status='rejected',
                        rejection_reason=?,
                        validated_at=?
                    WHERE id=? AND status IN ('pending_seller', 'submitted')
                    """,
                    (
                        "Order revoked because its wallet funding was not verified",
                        now(),
                        request["id"],
                    ),
                )
                await db.execute(
                    """
                    UPDATE orders
                    SET status='reversed', fulfillment_status='rejected'
                    WHERE id=? AND status='paid'
                    """,
                    (request["order_id"],),
                )
                revoked_requests.append(request_dict)
            await db.execute(
                """
                INSERT INTO audit_events(
                    actor_id,event_type,entity_type,entity_id,details,created_at
                ) VALUES(?,?,?,?,?,?)
                """,
                (
                    None,
                    "unverified_wallet_credit_revoked",
                    "deposit",
                    str(deposit["id"]),
                    (
                        f"Rejected approved deposit {deposit['id']} for user "
                        f"{deposit['user_id']} and removed its wallet credit."
                    ),
                    now(),
                ),
            )
        await db.commit()
    return revoked_requests


async def reject_deposit(deposit_id: int, reviewer_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            UPDATE deposits
            SET status='rejected', reviewed_by=?, reviewed_at=?
            WHERE id=? AND status='pending'
            """,
            (reviewer_id, now(), deposit_id),
        )
        await db.commit()
    return await get_deposit(deposit_id)


async def deposit_attempts(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT COUNT(*) FROM deposits
            WHERE user_id=? AND created_at >= datetime('now','-1 hour')
            """,
            (user_id,),
        )
        return (await cur.fetchone())[0]


async def utr_already_used(utr: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT 1 FROM deposits WHERE lower(utr)=lower(?) AND status IN ('pending','approved')
            UNION ALL
            SELECT 1 FROM payments WHERE lower(utr)=lower(?) AND status IN ('success','paid')
            LIMIT 1
            """,
            (utr.strip(), utr.strip()),
        )
        return await cur.fetchone() is not None


async def create_seller_request(user_id: int, data: dict) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO seller_requests(
                user_id,full_name,email,upi_id,identity,portfolio,
                telegram_username,telegram_user_id,created_at
            )
            VALUES(?,?,?,?,?,?,?,?,?)
            """,
            (user_id, data["full_name"], data["email"], data["upi_id"],
             data.get("identity", ""), data["portfolio"],
             data.get("telegram_username", ""), data.get("telegram_user_id"),
             now()),
        )
        await db.commit()
        return cur.lastrowid


async def get_seller_request(request_id: int) -> dict | None:
    return await _one("SELECT * FROM seller_requests WHERE id=?", (request_id,))


async def review_seller_request(request_id: int, status: str, reason: str = "") -> dict | None:
    row = await get_seller_request(request_id)
    if not row or row["status"] != "pending":
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE seller_requests SET status=?,rejection_reason=? WHERE id=?",
            (status, reason, request_id),
        )
        if status == "approved":
            await db.execute(
                "UPDATE users SET role='verified_seller',upi_id=? WHERE id=?",
                (row["upi_id"], row["user_id"]),
            )
        await db.commit()
    return row


async def create_listing(
    seller_id: int, data: dict, status: str = "live"
) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO listings(
                seller_id,title,description,price,category,file_id,file_type,
                link,api_base_url,text_content,api_plans,preview_file_id,
                preview_type,preview,status,created_at
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (seller_id, data["title"], data["description"], data["price"],
             data["category"], data.get("file_id"), data.get("file_type", "document"),
             data.get("link"), data.get("api_base_url", ""), data.get("text_content"),
             json.dumps(data.get("api_plans", [])), data.get("preview_file_id"),
             data.get("preview_type"),
             data.get("preview"), status, now()),
        )
        await db.commit()
        return cur.lastrowid


async def get_listing(listing_id: int) -> dict | None:
    return await _one("SELECT * FROM listings WHERE id=?", (listing_id,))


async def list_live_listings(
    limit: int = 8, offset: int = 0, market: str | None = None
) -> list[dict]:
    if market == "api":
        query = (
            "SELECT * FROM listings WHERE status='live' AND category='API' "
            "ORDER BY id DESC LIMIT ? OFFSET ?"
        )
    elif market == "src":
        query = (
            "SELECT * FROM listings WHERE status='live' AND category!='API' "
            "ORDER BY id DESC LIMIT ? OFFSET ?"
        )
    else:
        query = "SELECT * FROM listings WHERE status='live' ORDER BY id DESC LIMIT ? OFFSET ?"
    return await _many(query, (limit, offset))


async def list_pending_sellers(limit: int = 20) -> list[dict]:
    return await _many(
        "SELECT * FROM seller_requests WHERE status='pending' ORDER BY id DESC LIMIT ?",
        (limit,),
    )


async def list_pending_listings(limit: int = 20) -> list[dict]:
    return await _many(
        "SELECT * FROM listings WHERE status='pending_review' ORDER BY id DESC LIMIT ?",
        (limit,),
    )


async def list_all_listings(limit: int = 50) -> list[dict]:
    return await _many(
        "SELECT * FROM listings ORDER BY id DESC LIMIT ?",
        (limit,),
    )


async def set_listing_status(listing_id: int, status: str) -> dict | None:
    row = await get_listing(listing_id)
    if not row:
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE listings SET status=? WHERE id=?", (status, listing_id))
        await db.commit()
    return row


async def list_recent_orders(limit: int = 20) -> list[dict]:
    return await _many(
        """
        SELECT o.*, l.title FROM orders o
        LEFT JOIN listings l ON l.id=o.listing_id
        ORDER BY o.id DESC LIMIT ?
        """,
        (limit,),
    )


async def list_user_orders(user_id: int, limit: int = 20) -> list[dict]:
    return await _many(
        """
        SELECT o.*, l.title, l.seller_id,
               r.id AS api_request_id, r.status AS api_status
        FROM orders o LEFT JOIN listings l ON l.id=o.listing_id
        LEFT JOIN api_requests r ON r.order_id=o.id
        WHERE o.buyer_id=? ORDER BY o.id DESC LIMIT ?
        """,
        (user_id, limit),
    )


async def list_user_transactions(user_id: int, limit: int = 20) -> list[dict]:
    return await _many(
        """
        SELECT p.*, o.amount, o.buyer_id, l.title
        FROM payments p
        JOIN orders o ON o.id=p.order_id
        LEFT JOIN listings l ON l.id=o.listing_id
        WHERE o.buyer_id=? ORDER BY p.id DESC LIMIT ?
        """,
        (user_id, limit),
    )


async def list_user_listings(user_id: int, limit: int = 20) -> list[dict]:
    return await _many(
        "SELECT * FROM listings WHERE seller_id=? ORDER BY id DESC LIMIT ?",
        (user_id, limit),
    )


async def list_user_reviews(user_id: int, limit: int = 20) -> list[dict]:
    return await _many(
        """
        SELECT r.*, l.title
        FROM reviews r
        LEFT JOIN orders o ON o.id=r.order_id
        LEFT JOIN listings l ON l.id=o.listing_id
        WHERE r.buyer_id=? ORDER BY r.id DESC LIMIT ?
        """,
        (user_id, limit),
    )


async def list_listing_reviews(listing_id: int, limit: int = 20) -> list[dict]:
    return await _many(
        """
        SELECT r.*, u.username, u.first_name
        FROM reviews r
        JOIN orders o ON o.id=r.order_id
        LEFT JOIN users u ON u.id=r.buyer_id
        WHERE o.listing_id=?
        ORDER BY r.id DESC LIMIT ?
        """,
        (listing_id, limit),
    )


async def user_metrics(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        queries = {
            "purchases": "SELECT COUNT(*) FROM orders WHERE buyer_id=? AND status='paid'",
            "transactions": "SELECT COUNT(*) FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.buyer_id=?",
            "listings": "SELECT COUNT(*) FROM listings WHERE seller_id=?",
            "sales": "SELECT COUNT(*) FROM orders o JOIN listings l ON l.id=o.listing_id WHERE l.seller_id=? AND o.status='paid'",
        }
        values = {}
        for key, query in queries.items():
            values[key] = (await (await db.execute(query, (user_id,))).fetchone())[0]
        return values


async def create_offer(
    listing_id: int, buyer_id: int, seller_id: int, message: str
) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO offers(listing_id,buyer_id,seller_id,message,created_at)
            VALUES(?,?,?,?,?)
            """,
            (listing_id, buyer_id, seller_id, message[:700], now()),
        )
        await db.commit()
        return cur.lastrowid


async def list_seller_offers(seller_id: int, limit: int = 30) -> list[dict]:
    return await _many(
        """
        SELECT o.*, l.title, l.price, u.username AS buyer_username,
               u.first_name AS buyer_first_name
        FROM offers o
        JOIN listings l ON l.id=o.listing_id
        LEFT JOIN users u ON u.id=o.buyer_id
        WHERE o.seller_id=?
        ORDER BY o.id DESC LIMIT ?
        """,
        (seller_id, limit),
    )


async def seller_earning_metrics(user_id: int) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        withdrawals = await (
            await db.execute(
                """
                SELECT
                  COALESCE(SUM(CASE WHEN status='approved' THEN amount ELSE 0 END),0),
                  COALESCE(SUM(CASE WHEN status='pending' THEN amount ELSE 0 END),0)
                FROM withdrawal_requests WHERE user_id=?
                """,
                (user_id,),
            )
        ).fetchone()
        offers = await (
            await db.execute(
                "SELECT COUNT(*) FROM offers WHERE seller_id=? AND status='pending'",
                (user_id,),
            )
        ).fetchone()
        sales = await (
            await db.execute(
                """
                SELECT COUNT(*), COALESCE(SUM(o.amount),0)
                FROM orders o JOIN listings l ON l.id=o.listing_id
                WHERE l.seller_id=? AND o.status='paid'
                """,
                (user_id,),
            )
        ).fetchone()
    return {
        "withdrawn": float(withdrawals[0] or 0),
        "pending_withdrawal": float(withdrawals[1] or 0),
        "offers": int(offers[0] or 0),
        "sales": int(sales[0] or 0),
        "gross_sales": float(sales[1] or 0),
    }


async def create_withdrawal_request(
    user_id: int, amount: float, upi_id: str
) -> dict | None:
    amount = round(float(amount), 2)
    if amount <= 0 or not upi_id.strip():
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute("SELECT earnings FROM users WHERE id=?", (user_id,))
        row = await cur.fetchone()
        if not row or float(row[0] or 0) < amount:
            await db.rollback()
            return None
        await db.execute(
            "UPDATE users SET earnings=earnings-? WHERE id=?",
            (amount, user_id),
        )
        cur = await db.execute(
            """
            INSERT INTO withdrawal_requests(user_id,amount,upi_id,created_at)
            VALUES(?,?,?,?)
            """,
            (user_id, amount, upi_id.strip()[:120], now()),
        )
        request_id = cur.lastrowid
        await db.commit()
    return await _one("SELECT * FROM withdrawal_requests WHERE id=?", (request_id,))


async def get_withdrawal_request(request_id: int) -> dict | None:
    return await _one("SELECT * FROM withdrawal_requests WHERE id=?", (request_id,))


async def review_withdrawal_request(
    request_id: int, status: str, reviewer_id: int, note: str = ""
) -> dict | None:
    if status not in {"approved", "rejected"}:
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM withdrawal_requests WHERE id=?", (request_id,)
        )
        row = await cur.fetchone()
        if not row or row["status"] != "pending":
            await db.rollback()
            return dict(row) if row else None
        await db.execute(
            """
            UPDATE withdrawal_requests
            SET status=?, reviewed_by=?, reviewed_at=?, note=?
            WHERE id=? AND status='pending'
            """,
            (status, reviewer_id, now(), note[:500], request_id),
        )
        if status == "rejected":
            await db.execute(
                "UPDATE users SET earnings=earnings+? WHERE id=?",
                (row["amount"], row["user_id"]),
            )
        await db.commit()
    return await get_withdrawal_request(request_id)


async def create_review(order_id: int, buyer_id: int, rating: int, comment: str = "") -> bool:
    order = await _one(
        """
        SELECT o.id, o.buyer_id, o.status, l.seller_id, l.category,
               r.status AS api_status
        FROM orders o JOIN listings l ON l.id=o.listing_id
        LEFT JOIN api_requests r ON r.order_id=o.id
        WHERE o.id=?
        """,
        (order_id,),
    )
    if not order or order["buyer_id"] != buyer_id or order["status"] != "paid":
        return False
    if order["category"] == "API" and order["api_status"] != "delivered":
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                """
                INSERT INTO reviews(order_id,buyer_id,seller_id,rating,comment,created_at)
                VALUES(?,?,?,?,?,?)
                """,
                (order_id, buyer_id, order["seller_id"], rating, comment[:500], now()),
            )
            await db.commit()
            return True
        except aiosqlite.IntegrityError:
            return False


async def list_user_ids() -> list[int]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT id FROM users WHERE banned=0")
        return [row[0] for row in await cur.fetchall()]


async def set_banned(user_id: int, banned: bool) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET banned=? WHERE id=?", (int(banned), user_id))
        await db.commit()


async def find_users(query: str, limit: int = 10) -> list[dict]:
    """Find existing users by Telegram ID, username, or display name."""
    query = (query or "").strip()
    if not query:
        return []
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        if query.isdigit():
            cur = await db.execute(
                "SELECT * FROM users WHERE id=? LIMIT ?", (int(query), limit)
            )
        else:
            term = query.lstrip("@")
            like = f"%{term}%"
            cur = await db.execute(
                """
                SELECT * FROM users
                WHERE username LIKE ? COLLATE NOCASE
                   OR first_name LIKE ? COLLATE NOCASE
                   OR last_name LIKE ? COLLATE NOCASE
                ORDER BY id DESC LIMIT ?
                """,
                (like, like, like, limit),
            )
        return [dict(row) for row in await cur.fetchall()]


async def add_wallet_credit(
    actor_id: int, user_id: int, amount: float, reason: str
) -> dict | None:
    """Atomically add an owner-issued wallet credit and record its audit trail."""
    amount = round(float(amount), 2)
    reason = (reason or "Manual credit by owner").strip()[:500]
    if amount <= 0 or not reason:
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT id FROM users WHERE id=?", (user_id,))
        if not await cur.fetchone():
            await db.rollback()
            return None
        await db.execute(
            "UPDATE users SET wallet_balance=COALESCE(wallet_balance, 0)+? WHERE id=?",
            (amount, user_id),
        )
        await db.execute(
            """
            INSERT INTO wallet_adjustments(user_id,amount,reason,actor_id,created_at)
            VALUES(?,?,?,?,?)
            """,
            (user_id, amount, reason, actor_id, now()),
        )
        await db.commit()
    return await get_user(user_id)


async def review_listing(listing_id: int, status: str) -> dict | None:
    row = await get_listing(listing_id)
    if not row or row["status"] != "pending_review":
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE listings SET status=? WHERE id=?", (status, listing_id))
        await db.commit()
    return row


async def create_order(
    buyer_id: int,
    listing_id: int,
    amount: float,
    duration_days: int = 30,
    duration_months: int | None = None,
    monthly_price: float | None = None,
) -> int:
    if duration_months is not None:
        duration_months = max(1, min(3, int(duration_months)))
        duration_days = duration_months * 30
    else:
        duration_days = max(1, min(90, int(duration_days)))
        duration_months = max(1, min(3, (duration_days + 29) // 30))
    monthly_price = round(
        float(monthly_price if monthly_price is not None else amount),
        2,
    )
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO orders(
                buyer_id,listing_id,amount,duration_days,duration_months,monthly_price,
                fulfillment_status,created_at
            )
            VALUES(?,?,?,?,?,?,?,?)
            """,
            (
                buyer_id, listing_id, round(amount, 2), duration_days,
                duration_months, monthly_price, "not_required", now(),
            ),
        )
        await db.commit()
        return cur.lastrowid


async def charge_order_from_wallet(
    order_id: int, buyer_id: int, amount: float
) -> bool:
    """Atomically debit a buyer wallet and mark an order paid exactly once."""
    amount = round(float(amount), 2)
    if amount <= 0:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM orders WHERE id=? AND buyer_id=?",
            (order_id, buyer_id),
        )
        order = await cur.fetchone()
        cur = await db.execute(
            "SELECT wallet_balance FROM users WHERE id=?", (buyer_id,)
        )
        user = await cur.fetchone()
        if (
            not order
            or order["status"] != "awaiting_payment"
            or not user
            or float(user["wallet_balance"] or 0) < amount
        ):
            await db.rollback()
            return False
        await db.execute(
            """
            INSERT INTO wallet_transactions(
                user_id,order_id,amount,transaction_type,reason,created_at
            ) VALUES(?,?,?,?,?,?)
            """,
            (
                buyer_id, order_id, amount, "debit",
                "API/SRC purchase from wallet", now(),
            ),
        )
        updated = await db.execute(
            """
            UPDATE users
            SET wallet_balance=COALESCE(wallet_balance, 0)-?
            WHERE id=? AND COALESCE(wallet_balance, 0) >= ?
            """,
            (amount, buyer_id, amount),
        )
        if updated.rowcount != 1:
            await db.rollback()
            return False
        await db.execute(
            """
            UPDATE orders
            SET status='paid', utr=?, verified_at=?
            WHERE id=? AND status='awaiting_payment'
            """,
            (f"WALLET-{order_id}", now(), order_id),
        )
        await db.commit()
    return True


async def get_order(order_id: int) -> dict | None:
    return await _one("SELECT * FROM orders WHERE id=?", (order_id,))


async def record_payment(
    order_id: int, utr: str, api_response: dict, status: str,
    screenshot_file_id: str | None = None,
) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO payments(order_id,utr,screenshot_file_id,api_response,status,created_at)
            VALUES(?,?,?,?,?,?)
            """,
            (order_id, utr, screenshot_file_id, json.dumps(api_response), status, now()),
        )
        await db.execute("UPDATE orders SET utr=?,status=? WHERE id=?", (utr, status, order_id))
        await db.commit()


async def credit_seller_earnings(seller_id: int, amount: float) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET earnings=earnings+? WHERE id=?",
            (amount, seller_id),
        )
        await db.commit()


async def complete_order(order_id: int) -> dict | None:
    """Return only an already wallet-paid order; never bypass wallet charging."""
    order = await get_order(order_id)
    if not order or order["status"] != "paid":
        return None
    return order


async def create_api_request_for_order(order_id: int) -> dict | None:
    """Create the durable seller fulfilment request exactly once."""
    order = await _one(
        """
        SELECT o.*, l.seller_id, l.category, l.title
        FROM orders o JOIN listings l ON l.id=o.listing_id
        WHERE o.id=?
        """,
        (order_id,),
    )
    if not order or order["category"] != "API":
        return None
    existing = await _one("SELECT * FROM api_requests WHERE order_id=?", (order_id,))
    if existing:
        return existing
    deadline = (
        datetime.now(timezone.utc) + timedelta(hours=4)
    ).isoformat()
    reference = f"API-{secrets.token_hex(4).upper()}"
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO api_requests(
                reference,order_id,listing_id,buyer_id,seller_id,
                duration_days,duration_months,monthly_price,total_amount,deadline,created_at
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                reference, order["id"], order["listing_id"], order["buyer_id"],
                order["seller_id"], order.get("duration_days") or 30,
                order.get("duration_months") or 1,
                order.get("monthly_price") or order["amount"], order["amount"],
                deadline, now(),
            ),
        )
        await db.execute(
            """
            UPDATE orders
            SET fulfillment_status='pending_seller', fulfillment_deadline=?
            WHERE id=? AND status='paid'
            """,
            (deadline, order_id),
        )
        await db.commit()
    return await _one("SELECT * FROM api_requests WHERE order_id=?", (order_id,))


async def get_api_request(request_id: int) -> dict | None:
    return await _one(
        """
        SELECT r.*, l.title, l.description, l.category,
               u.username AS buyer_username, u.first_name AS buyer_first_name,
               s.username AS seller_username, s.first_name AS seller_first_name
        FROM api_requests r
        JOIN listings l ON l.id=r.listing_id
        LEFT JOIN users u ON u.id=r.buyer_id
        LEFT JOIN users s ON s.id=r.seller_id
        WHERE r.id=?
        """,
        (request_id,),
    )


async def get_api_request_by_reference(reference: str) -> dict | None:
    return await _one("SELECT * FROM api_requests WHERE reference=?", (reference,))


async def list_pending_api_requests(limit: int = 50) -> list[dict]:
    return await _many(
        """
        SELECT r.*, l.title,
               u.username AS buyer_username, u.first_name AS buyer_first_name
        FROM api_requests r
        JOIN listings l ON l.id=r.listing_id
        LEFT JOIN users u ON u.id=r.buyer_id
        WHERE r.status IN ('pending_seller','submitted')
        ORDER BY r.deadline ASC, r.id DESC LIMIT ?
        """,
        (limit,),
    )


async def list_api_requests_admin(limit: int = 100) -> list[dict]:
    return await _many(
        """
        SELECT r.*, l.title,
               u.username AS buyer_username, u.first_name AS buyer_first_name,
               s.username AS seller_username, s.first_name AS seller_first_name
        FROM api_requests r
        JOIN listings l ON l.id=r.listing_id
        LEFT JOIN users u ON u.id=r.buyer_id
        LEFT JOIN users s ON s.id=r.seller_id
        ORDER BY r.id DESC LIMIT ?
        """,
        (limit,),
    )


async def list_seller_api_requests(seller_id: int, limit: int = 50) -> list[dict]:
    return await _many(
        """
        SELECT r.*, l.title
        FROM api_requests r JOIN listings l ON l.id=r.listing_id
        WHERE r.seller_id=? ORDER BY r.id DESC LIMIT ?
        """,
        (seller_id, limit),
    )


async def submit_api_delivery(
    request_id: int, seller_id: int, access_payload: str, seller_note: str = ""
) -> dict | None:
    """Save seller delivery once; the owner can audit the durable payload."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM api_requests WHERE id=? AND seller_id=?",
            (request_id, seller_id),
        )
        row = await cur.fetchone()
        if not row or row["status"] not in ("pending_seller", "submitted"):
            await db.rollback()
            return dict(row) if row else None
        try:
            expired = datetime.fromisoformat(row["deadline"]) < datetime.now(timezone.utc)
        except (TypeError, ValueError):
            expired = False
        if expired:
            await db.execute(
                "UPDATE api_requests SET status='overdue' WHERE id=? AND status='pending_seller'",
                (request_id,),
            )
            await db.commit()
            return None
        await db.execute(
            """
            UPDATE api_requests
            SET status='submitted', access_payload=?, seller_note=?, submitted_at=?
            WHERE id=? AND seller_id=?
            """,
            (access_payload[:12000], seller_note[:1000], now(), request_id, seller_id),
        )
        await db.execute(
            "UPDATE orders SET fulfillment_status='submitted', seller_delivered_at=? WHERE id=?",
            (now(), row["order_id"]),
        )
        await db.commit()
    return await get_api_request(request_id)


async def expire_api_requests() -> list[dict]:
    """Expire missed seller SLAs and refund each buyer exactly once."""
    cutoff = datetime.now(timezone.utc).isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            """
            SELECT * FROM api_requests
            WHERE status='pending_seller' AND deadline < ?
            """,
            (cutoff,),
        )
        rows = [dict(row) for row in await cur.fetchall()]
        if rows:
            await db.execute(
                """
                UPDATE api_requests
                SET status='overdue',
                    rejection_reason='Seller missed the 4-hour fulfilment deadline',
                    validated_at=?
                WHERE status='pending_seller' AND deadline < ?
                """,
                (now(), cutoff),
            )
            await db.execute(
                """
                UPDATE orders
                SET status='refunded', fulfillment_status='refunded'
                WHERE id IN (SELECT order_id FROM api_requests WHERE status='overdue')
                """
            )
            for row in rows:
                cur = await db.execute(
                    "SELECT 1 FROM wallet_credits WHERE order_id=?",
                    (row["order_id"],),
                )
                if await cur.fetchone():
                    row["refund_added"] = False
                    continue
                await db.execute(
                    """
                    INSERT INTO wallet_credits(user_id,order_id,amount,reason,created_at)
                    VALUES(?,?,?,?,?)
                    """,
                    (
                        row["buyer_id"], row["order_id"], row["total_amount"],
                        "Automatic refund: seller missed the 4-hour API deadline",
                        now(),
                    ),
                )
                await db.execute(
                    "UPDATE users SET wallet_balance=wallet_balance+? WHERE id=?",
                    (row["total_amount"], row["buyer_id"]),
                )
                row["refund_added"] = True
        await db.commit()
    return rows


async def mark_api_request_delivered(
    request_id: int, seller_amount: float
) -> dict | None:
    """Owner/automated acceptance settles seller earnings exactly once."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM api_requests WHERE id=?", (request_id,))
        row = await cur.fetchone()
        if not row:
            await db.rollback()
            return None
        if row["status"] == "delivered":
            await db.commit()
            return dict(row)
        if row["status"] != "submitted":
            await db.rollback()
            return dict(row)
        await db.execute(
            "UPDATE api_requests SET status='delivered', validated_at=? WHERE id=?",
            (now(), request_id),
        )
        await db.execute(
            """
            UPDATE orders
            SET fulfillment_status='delivered', seller_delivered_at=COALESCE(seller_delivered_at,?)
            WHERE id=?
            """,
            (now(), row["order_id"]),
        )
        await db.execute(
            "UPDATE users SET earnings=earnings+? WHERE id=?",
            (round(float(seller_amount), 2), row["seller_id"]),
        )
        await db.commit()
    return await get_api_request(request_id)


async def admin_refund_api_request(
    request_id: int, reason: str, seller_amount: float
) -> dict | None:
    """Refund an API order to wallet and reverse settlement when necessary."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM api_requests WHERE id=?", (request_id,))
        row = await cur.fetchone()
        if not row:
            await db.rollback()
            return None
        if row["status"] == "rejected":
            await db.commit()
            return dict(row)
        await db.execute(
            """
            UPDATE api_requests
            SET status='rejected', rejection_reason=?, validated_at=?
            WHERE id=?
            """,
            (reason[:1000], now(), request_id),
        )
        await db.execute(
            "UPDATE orders SET fulfillment_status='rejected' WHERE id=?",
            (row["order_id"],),
        )
        if row["status"] == "delivered":
            await db.execute(
                "UPDATE users SET earnings=MAX(0, earnings-?) WHERE id=?",
                (round(float(seller_amount), 2), row["seller_id"]),
            )
        cur = await db.execute(
            "SELECT 1 FROM wallet_credits WHERE order_id=?", (row["order_id"],)
        )
        if not await cur.fetchone():
            await db.execute(
                """
                INSERT INTO wallet_credits(user_id,order_id,amount,reason,created_at)
                VALUES(?,?,?,?,?)
                """,
                (
                    row["buyer_id"], row["order_id"], row["total_amount"],
                    "admin API fulfilment refund: " + reason[:700], now(),
                ),
            )
            await db.execute(
                "UPDATE users SET wallet_balance=wallet_balance+? WHERE id=?",
                (row["total_amount"], row["buyer_id"]),
            )
        await db.commit()
    return await get_api_request(request_id)


async def refund_order_to_wallet(order_id: int, user_id: int, amount: float) -> bool:
    """Credit a failed order once; this is a wallet credit, not a bank reversal."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "SELECT 1 FROM wallet_credits WHERE order_id=?", (order_id,)
        )
        if await cur.fetchone():
            await db.rollback()
            return False
        await db.execute(
            """
            INSERT INTO wallet_credits(user_id,order_id,amount,reason,created_at)
            VALUES(?,?,?,?,?)
            """,
            (user_id, order_id, round(float(amount), 2), "automatic payment verification refund", now()),
        )
        await db.execute(
            "UPDATE users SET wallet_balance=wallet_balance+? WHERE id=?",
            (round(float(amount), 2), user_id),
        )
        await db.execute(
            "UPDATE orders SET status='refunded', fulfillment_status='refunded' WHERE id=?",
            (order_id,),
        )
        await db.commit()
    return True


async def record_audit_event(
    actor_id: int | None, event_type: str, entity_type: str, entity_id: str, details: str = ""
) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO audit_events(actor_id,event_type,entity_type,entity_id,details,created_at)
            VALUES(?,?,?,?,?,?)
            """,
            (actor_id, event_type, entity_type, entity_id, details[:4000], now()),
        )
        await db.commit()


async def utr_attempts(user_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT COUNT(*) FROM payments p JOIN orders o ON o.id=p.order_id
            WHERE o.buyer_id=? AND p.created_at >= datetime('now','-1 hour')
            """,
            (user_id,),
        )
        return (await cur.fetchone())[0]


async def stats() -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        values = {}
        for key, query in {
            "users": "SELECT COUNT(*) FROM users",
            "sellers": "SELECT COUNT(*) FROM users WHERE role='verified_seller'",
            "listings": "SELECT COUNT(*) FROM listings WHERE status='live'",
            "sales": "SELECT COUNT(*) FROM orders WHERE status='paid'",
            "revenue": "SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='paid'",
            "pending_deposits": "SELECT COUNT(*) FROM deposits WHERE status='pending'",
            "approved_deposits": "SELECT COALESCE(SUM(amount),0) FROM deposits WHERE status='approved'",
        }.items():
            values[key] = (await (await db.execute(query)).fetchone())[0]
    return values


async def _one(query: str, params: tuple = ()) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(query, params)
        row = await cur.fetchone()
    return dict(row) if row else None


async def _many(query: str, params: tuple = ()) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(query, params)
        rows = await cur.fetchall()
    return [dict(row) for row in rows]