"""Premium SRC marketplace bot.

Run with either:
  python main.py
  python -m src_vault_bot.main

The direct-script bootstrap below keeps the package-relative imports working
when this file is copied into a flat VPS folder and started as ``python main.py``.
The state machine intentionally lives in context.user_data so it survives
callback -> message transitions without exposing any credentials.
"""
if __package__ in (None, ""):
    import sys as _sys
    import types as _types
    from pathlib import Path as _BootstrapPath

    _runtime_package_name = "_src_vault_runtime"
    _runtime_package = _types.ModuleType(_runtime_package_name)
    _runtime_package.__path__ = [str(_BootstrapPath(__file__).resolve().parent)]
    _sys.modules[_runtime_package_name] = _runtime_package
    __package__ = _runtime_package_name

import html
import json
import logging
import re
import unicodedata
from base64 import b64decode
from datetime import datetime, timedelta, timezone
from io import BytesIO
from pathlib import Path
from urllib.parse import quote, urlencode, urlparse

import qrcode
from telegram import InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest
from telegram.ext import (
    Application, CallbackQueryHandler, CommandHandler, ContextTypes, ExtBot,
    MessageHandler, PicklePersistence, filters,
)

from .config import (
    ADMIN_ID, API_FULFILLMENT_HOURS, API_MAX_DAYS, API_PLAN_MONTHS,
    BOT_TOKEN, CATEGORIES,
    BINANCE_USD_TO_INR,
    MAX_FILE_MB, MIN_PRICE, PLATFORM_FEE_DEFAULT,
    EMOJI, SUPPORT_USERNAME,
    LOG_CHANNEL_ID, PRODUCT_CHANNEL_ID,
    PERSISTENCE_PATH, UPDATES_CHANNEL_URL, UTR_LIMIT_PER_HOUR,
)
from .database import (
    charge_order_from_wallet, complete_order, create_api_request_for_order,
    create_listing, create_order,
    create_offer, create_withdrawal_request,
    create_seller_request,
    create_deposit,
    create_earning_task, claim_earning_task, clawback_task_claim,
    credit_seller_earnings,
    ensure_user, get_listing, get_order, get_seller_request, get_setting,
    get_deposit, get_payment_config,
    get_earning_task, get_task_claim,
    get_force_join_channels, set_force_join_channels,
    create_support_issue, list_open_support_issues, get_support_issue,
    resolve_support_issue,
    get_user, get_chat_session, get_or_create_chat_session, end_chat_session,
    admin_refund_api_request, expire_api_requests, get_api_request, list_api_requests_admin,
    list_pending_api_requests, list_seller_api_requests, mark_api_request_delivered,
    refund_order_to_wallet, submit_api_delivery,
    init_db, list_all_listings, list_live_listings,
    list_pending_deposits, list_pending_sellers, list_recent_orders,
    list_user_deposits, find_users,
    add_wallet_credit,
    list_active_earning_tasks, list_all_earning_tasks, list_user_task_claims,
    list_monitored_task_claims, set_earning_task_active,
    subscribe_to_earning_task_notifications,
    list_earning_task_notification_users, clear_earning_task_notification,
    list_user_ids,
    list_user_listings, list_user_orders, list_user_reviews, list_listing_reviews,
    list_seller_offers, seller_earning_metrics, get_withdrawal_request,
    review_withdrawal_request,
    list_user_transactions, record_deposit_proof, record_payment, review_listing,
    approve_deposit, approve_manual_deposit, reject_deposit,
    reconcile_unverified_deposits, set_listing_status,
    review_seller_request, set_banned, set_role, set_setting, stats,
    user_metrics, create_review, utr_attempts, deposit_attempts, utr_already_used,
    record_audit_event,
)
from .utils.api_verify import verify_payment
from .utils.keyboards import (
    api_plan_menu, api_request_menu, back_menu, btn, copy_btn,
    earning_tasks_menu, main_menu, profile_menu, seller_center_menu,
    task_detail_menu, task_list_menu, url_btn,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
log = logging.getLogger("src-selling-bot")

WELCOME_IMAGE_URL = "https://files.catbox.moe/tmpbv9.jpg"


def esc(value: object) -> str:
    return html.escape(str(value or ""))


def ce(name: str) -> str:
    """Render a configurable premium Telegram emoji in HTML messages."""
    emoji_id = EMOJI.get(name)
    return f"<tg-emoji emoji-id=\"{emoji_id}\">✨</tg-emoji>" if emoji_id else ""


_PREMIUM_EMOJI_BY_CHAR = {
    "👋": EMOJI["wave"],
    "🤖": EMOJI["robot"],
    "📱": EMOJI["phone"],
    "🪪": EMOJI["id_card"],
    "💳": EMOJI["credit_card"],
    "✨": EMOJI["sparkles"],
    "✅": EMOJI["verified"],
    "❌": EMOJI["stop"],
    "⚠": EMOJI["warning"],
    "💰": EMOJI["money"],
    "💵": EMOJI["cash"],
    "💸": EMOJI["cash"],
    "🛒": EMOJI["cart"],
    "🛍": EMOJI["cart"],
    "📦": EMOJI["package"],
    "💬": EMOJI["support"],
    "📞": EMOJI["support"],
    "🔌": EMOJI["code"],
    "🌑": EMOJI["comet"],
    "📊": EMOJI["screen"],
    "📢": EMOJI["announcement"],
    "📣": EMOJI["announcement"],
    "🛡": EMOJI["admin"],
    "🎯": EMOJI["star_alt"],
    "➕": EMOJI["sparkles"],
    "↩": EMOJI["back"],
    "🔙": EMOJI["back"],
    "◀": EMOJI["back"],
    "▶": EMOJI["link"],
    "↗": EMOJI["link"],
    "⭐": EMOJI["star_alt"],
    "★": EMOJI["star_alt"],
    "☆": EMOJI["star_alt"],
    "🎁": EMOJI["gift_alt"],
    "🎉": EMOJI["celebration"],
    "📋": EMOJI["screen"],
    "🔎": EMOJI["screen"],
    "🆔": EMOJI["id_card"],
    "🧾": EMOJI["screen"],
    "🧩": EMOJI["code"],
    "👤": EMOJI["id_card"],
    "👥": EMOJI["id_card"],
    "💻": EMOJI["developer"] if "developer" in EMOJI else EMOJI["code"],
    "⏳": EMOJI["candle"],
    "ℹ": EMOJI["screen"],
    "🆘": EMOJI["support"],
}
_PREMIUM_EMOJI_RANGES = (
    (0x1F000, 0x1FAFF),
    (0x1FC00, 0x1FFFF),
    (0x2190, 0x21FF),
    (0x2300, 0x23FF),
    (0x2600, 0x27BF),
    (0x2B00, 0x2BFF),
)
_PREMIUM_FORMAT_CHARS = {0x200D, 0x20E3, 0xFE0E, 0xFE0F}
_PREMIUM_TAG_RE = re.compile(r"(<tg-emoji\b[^>]*>.*?</tg-emoji>)", re.DOTALL)
_HTML_TAG_RE = re.compile(r"(<[^>]+>)")


def _is_emoji_character(character: str) -> bool:
    codepoint = ord(character)
    return any(start <= codepoint <= end for start, end in _PREMIUM_EMOJI_RANGES)


def _premiumize_segment(segment: str) -> str:
    rendered = []
    for character in segment:
        if ord(character) in _PREMIUM_FORMAT_CHARS:
            continue
        if character in {"✦", "✧"}:
            continue
        if character in _PREMIUM_EMOJI_BY_CHAR:
            rendered.append(
                f"<tg-emoji emoji-id=\"{_PREMIUM_EMOJI_BY_CHAR[character]}\">"
                f"{character}</tg-emoji>"
            )
        elif _is_emoji_character(character):
            rendered.append(
                f"<tg-emoji emoji-id=\"{EMOJI['sparkles']}\">✨</tg-emoji>"
            )
        else:
            rendered.append(character)
    return "".join(rendered)


def _bold_unformatted_text(text: str) -> str:
    """Bold literal text without nesting existing HTML/entity tags."""
    rendered = []
    bold_depth = 0
    code_depth = 0
    custom_emoji_depth = 0

    for part in _HTML_TAG_RE.split(text):
        if not part:
            continue
        if part.startswith("<") and part.endswith(">"):
            tag = part.casefold()
            closing = tag.startswith("</")
            if "tg-emoji" in tag:
                custom_emoji_depth += -1 if closing else 1
            elif "<b" in tag:
                bold_depth += -1 if closing else 1
            elif "<code" in tag or "<pre" in tag:
                code_depth += -1 if closing else 1
            rendered.append(part)
            continue

        if bold_depth or code_depth or custom_emoji_depth or not part.strip():
            rendered.append(part)
        else:
            rendered.append(f"<b>{part}</b>")
    return "".join(rendered)


def premiumize_message(text: str) -> str:
    """Replace raw emoji and make outgoing bot text consistently bold."""
    if not isinstance(text, str):
        return text
    parts = _PREMIUM_TAG_RE.split(text)
    premium_text = "".join(
        part if _PREMIUM_TAG_RE.fullmatch(part) else _premiumize_segment(part)
        for part in parts
    )
    return _bold_unformatted_text(premium_text)


class PremiumBot(ExtBot):
    """ExtBot that applies the bot's premium message presentation centrally."""

    @staticmethod
    def _decorate(
        args: tuple,
        kwargs: dict,
        content_index: int,
        content_key: str,
        parse_mode_index: int,
    ) -> tuple[list, dict]:
        decorated_args = list(args)
        if len(decorated_args) > content_index:
            if isinstance(decorated_args[content_index], str):
                decorated_args[content_index] = premiumize_message(
                    decorated_args[content_index]
                )
        elif isinstance(kwargs.get(content_key), str):
            kwargs[content_key] = premiumize_message(kwargs[content_key])

        if len(decorated_args) > parse_mode_index:
            decorated_args[parse_mode_index] = ParseMode.HTML
        else:
            kwargs["parse_mode"] = ParseMode.HTML
        return decorated_args, kwargs

    async def send_message(self, *args, **kwargs):
        args, kwargs = self._decorate(args, kwargs, 1, "text", 2)
        return await super().send_message(*args, **kwargs)

    async def send_photo(self, *args, **kwargs):
        args, kwargs = self._decorate(args, kwargs, 2, "caption", 5)
        return await super().send_photo(*args, **kwargs)

    async def send_document(self, *args, **kwargs):
        args, kwargs = self._decorate(args, kwargs, 2, "caption", 5)
        return await super().send_document(*args, **kwargs)

    async def edit_message_text(self, *args, **kwargs):
        args, kwargs = self._decorate(args, kwargs, 3, "text", 5)
        try:
            return await super().edit_message_text(*args, **kwargs)
        except BadRequest as error:
            if "no text in the message to edit" not in str(error).casefold():
                raise

            def value(index: int, key: str, default=None):
                if key in kwargs:
                    return kwargs[key]
                return args[index] if len(args) > index else default

            chat_id = value(0, "chat_id")
            message_id = value(1, "message_id")
            inline_message_id = value(2, "inline_message_id")
            text = value(3, "text", "")
            reply_markup = value(4, "reply_markup")
            if chat_id is None and inline_message_id is None:
                raise
            try:
                return await super().edit_message_caption(
                    chat_id=chat_id,
                    message_id=message_id,
                    inline_message_id=inline_message_id,
                    caption=text,
                    reply_markup=reply_markup,
                    parse_mode=ParseMode.HTML,
                )
            except BadRequest:
                if chat_id is None:
                    raise
                return await super().send_message(
                    chat_id=chat_id,
                    text=text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=reply_markup,
                )

    async def edit_message_caption(self, *args, **kwargs):
        args, kwargs = self._decorate(args, kwargs, 3, "caption", 5)
        return await super().edit_message_caption(*args, **kwargs)


def is_owner(user_id: int) -> bool:
    return bool(ADMIN_ID and user_id == ADMIN_ID)


UPI_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{1,80}@[A-Za-z0-9.-]{2,40}$")


def is_valid_upi_id(value: str) -> bool:
    candidate = (value or "").strip()
    return candidate.lower() != "your-upi@bank" and bool(UPI_ID_RE.fullmatch(candidate))


def is_valid_http_url(value: str) -> bool:
    parsed = urlparse((value or "").strip())
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def notification_chat_id() -> int:
    return LOG_CHANNEL_ID or ADMIN_ID


def product_chat_id() -> int:
    return PRODUCT_CHANNEL_ID


def log_destination_ids() -> tuple[int, ...]:
    """Return every Telegram chat that must receive the operational logs."""
    destinations = [LOG_CHANNEL_ID, STAR_EMOJI_ID]
    if not any(destinations):
        destinations.append(ADMIN_ID)
    return tuple(dict.fromkeys(chat_id for chat_id in destinations if chat_id))


async def verify_log_destinations(bot: ExtBot) -> None:
    """Verify every configured Telegram logging destination during startup."""
    destinations = (
        ("audit log", LOG_CHANNEL_ID, False),
        ("star log", STAR_EMOJI_ID, True),
        ("product announcements", PRODUCT_CHANNEL_ID, False),
    )
    checked = set()
    for label, chat_id, silent in destinations:
        if not chat_id or chat_id in checked:
            if not chat_id and not silent:
                log.warning("%s destination is not configured", label.capitalize())
            continue
        checked.add(chat_id)
        try:
            chat = await bot.get_chat(chat_id)
            if silent:
                continue
            title = getattr(chat, "title", None) or getattr(chat, "username", None)
            log.info(
                "Connected %s destination: %s%s",
                label,
                title or "chat",
                f" ({chat_id})",
            )
        except Exception:
            if silent:
                continue
            log.exception(
                "Could not connect %s destination %s",
                label,
                chat_id,
            )


def telegram_user_label(user, user_id: int | None = None) -> str:
    resolved_id = user_id or getattr(user, "id", 0)
    first_name = (getattr(user, "first_name", "") or "").strip()
    last_name = (getattr(user, "last_name", "") or "").strip()
    username = (getattr(user, "username", "") or "").strip()
    name = " ".join(part for part in (first_name, last_name) if part) or "Unknown user"
    username_text = f"@{username}" if username else "username not set"
    return (
        f"<b>{esc(name)}</b> · {esc(username_text)}\n"
        f"Telegram ID: <code>{resolved_id}</code>"
    )


async def send_channel_notification(
    context: ContextTypes.DEFAULT_TYPE,
    text: str,
    reply_markup=None,
    chat_id: int | None = None,
) -> None:
    if chat_id is None:
        destinations = log_destination_ids()
    elif chat_id:
        destinations = (chat_id,)
    else:
        return
    for destination in destinations:
        try:
            await context.bot.send_message(
                chat_id=destination,
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup,
                disable_notification=True,
            )
        except Exception:
            log.exception(
                "Could not send channel notification to %s",
                destination,
            )


async def listing_start_link(
    context: ContextTypes.DEFAULT_TYPE, listing_id: int
) -> str:
    bot = await context.bot.get_me()
    if not bot.username:
        return ""
    return f"https://t.me/{bot.username}?start={quote(f'listing_{listing_id}')}"


def is_valid_telegram_link(value: str) -> bool:
    parsed = urlparse((value or "").strip())
    host = (parsed.netloc or "").casefold().removeprefix("www.")
    return (
        parsed.scheme in {"http", "https"}
        and host in {"t.me", "telegram.me"}
        and bool(parsed.path.strip("/"))
    )


def build_upi_uri(upi_id: str, owner_name: str, amount: float, reference: str) -> str:
    return "upi://pay?" + urlencode({
        "pa": upi_id,
        "pn": owner_name[:60] or "SRC Vault",
        "am": f"{amount:.2f}",
        "cu": "INR",
        "tn": f"SRC Vault {reference}",
    })


def make_upi_qr(uri: str) -> BytesIO:
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=9,
        border=4,
    )
    qr.add_data(uri)
    qr.make(fit=True)
    image = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer


async def edit_callback_content(
    query,
    context: ContextTypes.DEFAULT_TYPE,
    text: str,
    parse_mode: str = ParseMode.HTML,
    reply_markup=None,
) -> None:
    """Update callback content for both text and media messages.

    Product details are sometimes displayed as a photo/video with a caption.
    Telegram rejects edit_message_text for those messages, so fall back to a
    caption update and finally to a fresh text message.
    """
    try:
        await query.edit_message_text(
            text, parse_mode=ParseMode.HTML, reply_markup=reply_markup
        )
        return
    except Exception:
        pass

    try:
        await query.edit_message_caption(
            caption=text[:1024],
            parse_mode=ParseMode.HTML,
            reply_markup=reply_markup,
        )
        return
    except Exception:
        pass

    message = await context.bot.send_message(
        chat_id=query.message.chat_id,
        text=text,
        parse_mode=ParseMode.HTML,
        reply_markup=reply_markup,
    )
    try:
        await query.message.delete()
    except Exception:
        pass


async def send_new_callback_message(
    query,
    context: ContextTypes.DEFAULT_TYPE,
    text: str,
    parse_mode: str = ParseMode.HTML,
    reply_markup=None,
) -> None:
    """Delete the current callback message and send a fresh text message."""
    chat_id = query.message.chat_id
    try:
        await query.message.delete()
    except Exception:
        pass
    await context.bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode=parse_mode,
        reply_markup=reply_markup,
    )


def welcome_copy(display_name: str, text: str | None = None) -> str:
    return text or (
        f"{ce('wave')} <b>ᴡᴇʟᴄᴏᴍᴇ, {esc(display_name.upper())} !!</b>\n\n"
        f"{ce('robot')} <b>ɪ ᴀᴍ 𝐒𝐑𝐂 𝐕𝐀𝐔𝐋𝐓</b>\n\n"
        f"{ce('cart')} <b>ʙᴜʏ ᴠᴇʀɪꜰɪᴇᴅ ꜱʀᴄ ᴘʀᴏᴅᴜᴄᴛꜱ</b>\n"
        f"{ce('verified')} <b>ꜱᴇʟʟ ʏᴏᴜʀ ᴡᴏʀᴋ ᴀꜱ ᴀ ᴠᴇʀɪꜰɪᴇᴅ ᴄʀᴇᴀᴛᴏʀ</b>\n"
        f"{ce('shield')} <b>ꜱᴇᴄᴜʀᴇ ᴜᴘɪ ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ ᴀɴᴅ ɪɴꜱᴛᴀɴᴛ ᴅᴇʟɪᴠᴇʀʏ</b>\n\n"
        f"{ce('sparkles')} <b>ᴜꜱᴇ ᴛʜᴇ ᴍᴇɴᴜ ʙᴇʟᴏᴡ ᴛᴏ ɴᴀᴠɪɢᴀᴛᴇ.</b>"
    )


def welcome_markup(user_id: int, display_name: str) -> InlineKeyboardMarkup:
    return main_menu(
        is_owner(user_id),
        display_name=display_name,
        updates_url=UPDATES_CHANNEL_URL,
    )


async def send_welcome_photo(
    chat_id: int,
    context: ContextTypes.DEFAULT_TYPE,
    user_id: int,
    display_name: str,
    text: str | None = None,
    reply_to_message_id: int | None = None,
) -> None:
    caption = welcome_copy(display_name, text)
    markup = welcome_markup(user_id, display_name)
    try:
        await context.bot.send_photo(
            chat_id=chat_id,
            photo=WELCOME_IMAGE_URL,
            caption=caption,
            parse_mode=ParseMode.HTML,
            reply_markup=markup,
            reply_to_message_id=reply_to_message_id,
        )
    except Exception:
        log.exception("Could not send the welcome image; using text fallback")
        await context.bot.send_message(
            chat_id=chat_id,
            text=caption,
            parse_mode=ParseMode.HTML,
            reply_markup=markup,
            reply_to_message_id=reply_to_message_id,
        )


def _member_is_joined(member) -> bool:
    status = getattr(member, "status", "")
    return status in {"member", "administrator", "creator"} or (
        status == "restricted" and bool(getattr(member, "is_member", False))
    )


async def missing_force_join_channels(
    context: ContextTypes.DEFAULT_TYPE, user_id: int
) -> list[dict]:
    missing = []
    for channel in await get_force_join_channels():
        try:
            member = await context.bot.get_chat_member(channel["chat_id"], user_id)
        except Exception:
            log.exception(
                "Could not verify force-join membership for %s", channel["chat_id"]
            )
            missing.append(channel)
            continue
        if not _member_is_joined(member):
            missing.append(channel)
    return missing


async def send_force_join_prompt(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    missing: list[dict],
    *,
    fresh_callback_message: bool = False,
) -> None:
    rows = [
        [url_btn(f"📢 Join Required Channel {index}", channel["link"])]
        for index, channel in enumerate(missing, 1)
    ]
    rows.append([btn("✅ Verify Join", "force_join_verify")])
    text = (
        "🔐 <b>Join required channels first</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "To use SRC Vault, join every channel below, then press "
        "<b>Verify Join</b>.\n\n"
        "Public channels and private invite links are supported."
    )
    markup = InlineKeyboardMarkup(rows)
    if fresh_callback_message:
        await send_new_callback_message(
            update.callback_query, context, text, reply_markup=markup
        )
    else:
        await update.effective_message.reply_text(
            text, parse_mode=ParseMode.HTML, reply_markup=markup
        )


async def force_join_allowed(
    update: Update, context: ContextTypes.DEFAULT_TYPE, *, prompt: bool = True
) -> bool:
    user = update.effective_user
    if not user or is_owner(user.id):
        return True
    configured = await get_force_join_channels()
    if not configured:
        return True
    missing = await missing_force_join_channels(context, user.id)
    if not missing:
        return True
    if prompt:
        if update.callback_query:
            await update.callback_query.answer(
                "Join the required channel(s) first.", show_alert=True
            )
            await send_force_join_prompt(
                update, context, missing, fresh_callback_message=True
            )
        else:
            await send_force_join_prompt(update, context, missing)
    return False


async def force_join_verify_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE
):
    query = update.callback_query
    missing = await missing_force_join_channels(context, update.effective_user.id)
    if missing:
        await query.answer(
            "You still need to join every required channel.", show_alert=True
        )
        await send_force_join_prompt(update, context, missing, fresh_callback_message=True)
        return
    await query.answer("Membership verified.")
    try:
        await query.message.delete()
    except Exception:
        pass
    display_name = update.effective_user.first_name or update.effective_user.username or "Account"
    await send_welcome_photo(
        query.message.chat_id,
        context,
        update.effective_user.id,
        display_name,
    )


async def send_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str = None):
    user = update.effective_user
    await ensure_user(user)
    if not await force_join_allowed(update, context):
        return
    display_name = user.first_name or user.username or "Account"
    # Keep the chat clean: /start opens a fresh welcome message instead of
    # editing or reusing a previous menu message.
    try:
        await update.effective_message.delete()
    except Exception:
        pass
    await send_welcome_photo(
        update.effective_chat.id,
        context,
        user.id,
        display_name,
        text,
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    existing = await get_user(update.effective_user.id)
    if existing and existing.get("banned"):
        await update.message.reply_text(
            "⛔ This account is restricted. Contact support if you believe this is an error."
        )
        return
    deep_link = (context.args[0] if context.args else "").strip()
    if deep_link.startswith("listing_"):
        try:
            listing_id = int(deep_link.removeprefix("listing_"))
        except ValueError:
            listing_id = 0
        if listing_id:
            if not await force_join_allowed(update, context):
                return
            row = await get_listing(listing_id)
            if row and row["status"] == "live":
                try:
                    await update.effective_message.delete()
                except Exception:
                    pass
                context.user_data["view_listing"] = listing_id
                if await send_listing_detail_message(
                    context, update.effective_chat.id, row
                ):
                    return
    await send_menu(update, context)


async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data.clear()
    try:
        await query.message.delete()
    except Exception:
        pass
    display_name = update.effective_user.first_name or update.effective_user.username or "Account"
    await send_welcome_photo(
        query.message.chat_id,
        context,
        update.effective_user.id,
        display_name,
    )


async def profile_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    metrics = await user_metrics(user["id"])
    role = {"buyer": "Buyer", "verified_seller": "Verified Seller"}.get(
        user["role"], user["role"].title()
    )
    owner = is_owner(user["id"])
    if owner:
        role = "Owner / Admin"
    await query.edit_message_text(
        f"👤 <b>Profile</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Name: <b>{esc(user['first_name'])}</b>\n"
        f"User ID: <code>{user['id']}</code>\n"
        f"Username: @{esc(user['username']) or 'not set'}\n"
        f"Role: <b>{esc(role)}</b>\n"
        f"Wallet balance: <b>₹{float(user.get('wallet_balance', 0)):.2f}</b>\n"
        f"Seller earnings: <b>₹{float(user['earnings']):.2f}</b>\n"
        f"Purchases: <b>{metrics['purchases']}</b>\n"
        f"Joined: <code>{esc(user['joined_at'][:10])}</code>\n\n"
        "Use the buttons below to manage your marketplace account.",
        parse_mode=ParseMode.HTML,
        reply_markup=profile_menu(user["role"] == "verified_seller", owner=owner),
    )


async def account_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await profile_callback(update, context)


async def balance_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    metrics = await user_metrics(user["id"])
    await query.edit_message_text(
        f"💰 <b>Balance & Earnings</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Wallet balance: <b>₹{float(user.get('wallet_balance', 0)):.2f}</b>\n"
        f"Available seller earnings: <b>₹{float(user['earnings']):.2f}</b>\n"
        f"Completed sales: <b>{metrics['sales']}</b>\n\n"
        "Buyer payments are made per SRC order. Seller earnings are credited "
        "after successful payment verification.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("➕ Deposit", "deposit"), btn("📜 Deposits", "deposit_history")],
            [btn("🌑 Earn", "earn"), btn("📜 Transactions", "transactions")],
            [btn("↩️ Back to Home", "menu")],
        ]),
    )


async def earn_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    claims = await list_user_task_claims(user["id"], 5)
    tasks = await list_active_earning_tasks()
    completed = sum(1 for claim in claims if claim["status"] == "credited")
    task_status = (
        "Choose an admin-created task below to start earning."
        if tasks
        else
        "No earning tasks are live right now. Tap “Notify me” and we’ll "
        "message you when an admin publishes one."
    )
    await query.edit_message_text(
        f"🌑 <b>Earn with SRC Vault</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Completed tasks: <b>{completed}</b>\n\n"
        f"{task_status}\n\n"
        "Join the required channel and remain joined for the stated retention "
        "period to keep the reward.",
        parse_mode=ParseMode.HTML,
        reply_markup=earning_tasks_menu(
            has_tasks=bool(tasks), has_history=bool(claims)
        ),
    )


async def seller_center_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    owner = is_owner(user["id"])
    verified = user["role"] == "verified_seller"
    if not verified and not owner:
        await query.edit_message_text(
            "🔒 <b>Verified seller access required</b>\n\n"
            "Apply from your profile first. Seller tools will appear after approval.",
            parse_mode=ParseMode.HTML,
            reply_markup=profile_menu(verified=False, owner=False),
        )
        return
    metrics = await user_metrics(user["id"])
    seller_metrics = await seller_earning_metrics(user["id"])
    platform_fee = PLATFORM_FEE_DEFAULT
    available = float(user.get("earnings", 0))
    lifetime = available + seller_metrics["withdrawn"] + seller_metrics["pending_withdrawal"]
    role = "Owner / Admin" if owner else "Verified Seller"
    await query.edit_message_text(
        "✦ <b>SELLER DASHBOARD</b> ✦\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>{esc(user.get('first_name') or 'Seller')}</b>\n"
        f"✅ {role}\n\n"
        "💰 <b>Earnings</b>\n"
        f"💵 Available: <b>₹{available:.2f}</b>\n"
        f"📈 Lifetime: <b>₹{lifetime:.2f}</b>\n"
        f"💸 Withdrawn: <b>₹{seller_metrics['withdrawn']:.2f}</b>\n"
        f"🧾 Tax/Sale: <b>{platform_fee:.0f}%</b>\n"
        f"💬 Offers: <b>{seller_metrics['offers']} pending</b>\n\n"
        f"📦 Products: <b>{metrics['listings']}</b> · "
        f"✅ Sales: <b>{metrics['sales']}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=seller_center_menu(verified=verified, owner=owner),
    )


async def seller_preview_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    owner = is_owner(user["id"])
    verified = user["role"] == "verified_seller" or owner
    if not verified:
        await query.edit_message_text(
            "🔒 Seller profile preview is available after your application is approved.",
            reply_markup=back_menu(),
        )
        return
    role = "Owner / Admin" if owner else "Verified Seller"
    await query.edit_message_text(
        "✦ <b>SELLER PROFILE PREVIEW</b> ✦\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>{esc(user.get('first_name') or 'Seller')}</b>\n"
        f"🛡 <b>{role}</b>\n"
        f"🆔 <code>{user['id']}</code>\n"
        f"📅 Since: <code>{esc(user['joined_at'][:10])}</code>\n\n"
        "This is the profile buyers see before opening your products.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("🛍 Seller Dashboard", "seller_center")],
            [btn("↩️ Back to Profile", "profile")],
        ]),
    )


async def seller_funds_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    owner = is_owner(user["id"])
    if user["role"] != "verified_seller" and not owner:
        await query.edit_message_text(
            "🔒 Seller funds are available after your seller application is approved.",
            reply_markup=profile_menu(verified=False, owner=False),
        )
        return
    metrics = await seller_earning_metrics(user["id"])
    available = float(user.get("earnings", 0))
    lifetime = available + metrics["withdrawn"] + metrics["pending_withdrawal"]
    await query.edit_message_text(
        "💰 <b>Seller Funds</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Available: <b>₹{available:.2f}</b>\n"
        f"Lifetime: <b>₹{lifetime:.2f}</b>\n"
        f"Withdrawn: <b>₹{metrics['withdrawn']:.2f}</b>\n"
        f"Pending withdrawal: <b>₹{metrics['pending_withdrawal']:.2f}</b>\n\n"
        "Withdrawals are reviewed by the owner and sent to your UPI ID.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("💸 Withdraw", "withdraw")],
            [btn("🛍 Seller Dashboard", "seller_center")],
        ]),
    )


async def seller_offers_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    if user["role"] != "verified_seller" and not is_owner(user["id"]):
        await query.edit_message_text(
            "🔒 Seller offers are available after your seller application is approved.",
            reply_markup=profile_menu(verified=False, owner=False),
        )
        return
    rows = await list_seller_offers(update.effective_user.id)
    if not rows:
        text = (
            "💬 <b>My Offers</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No offers received yet."
        )
    else:
        text = "💬 <b>My Offers</b>\n━━━━━━━━━━━━━━━━━━━━\n" + "\n\n".join(
            f"#{row['id']} · <b>{esc(row['title'])}</b>\n"
            f"From: <b>{esc(row.get('buyer_first_name') or row.get('buyer_username') or 'Buyer')}</b>\n"
            f"{esc(row['message'])}\n"
            f"Status: <b>{esc(row['status'])}</b>"
            for row in rows
        )
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("🛍 Seller Dashboard", "seller_center")],
            [btn("↩️ Back to Profile", "profile")],
        ]),
    )


async def withdraw_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    owner = is_owner(user["id"])
    if user["role"] != "verified_seller" and not owner:
        await query.edit_message_text(
            "🔒 <b>Verified seller access required</b>\n\n"
            "Withdrawals are available only after seller approval.",
            parse_mode=ParseMode.HTML,
            reply_markup=profile_menu(verified=False, owner=False),
        )
        return
    available = float(user.get("earnings", 0))
    if available <= 0:
        await query.edit_message_text(
            "💸 <b>Withdraw</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "You do not have any available earnings to withdraw yet.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💰 Funds", "seller_funds")],
                [btn("↩️ Seller Dashboard", "seller_center")],
            ]),
        )
        return
    context.user_data.update({
        "flow": "withdrawal",
        "step": "upi",
        "withdrawal": {},
    })
    await query.edit_message_text(
        "💸 <b>Withdraw Earnings</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Available: <b>₹{available:.2f}</b>\n\n"
        "Step 1/2 — Send the UPI ID where the payment should be sent.\n"
        "Example: name@upi",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[btn("❌ Cancel", "seller_center")]]),
    )
def task_chat_ref(channel_ref: str) -> str:
    """Return the Telegram chat ID or public username used for membership checks."""
    value = (channel_ref or "").strip()
    if value.startswith(("https://t.me/", "http://t.me/")):
        slug = value.rstrip("/").rsplit("/", 1)[-1]
        if slug and not slug.startswith(("+", "joinchat")):
            return f"@{slug.lstrip('@')}"
    return value


def task_channel_url(channel_ref: str, channel_link: str = "") -> str:
    value = (channel_link or channel_ref or "").strip()
    if value.startswith(("https://t.me/", "http://t.me/")):
        return value
    if value.startswith("@"):
        return f"https://t.me/{value[1:]}"
    return ""


async def earn_tasks_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    tasks = await list_active_earning_tasks()
    if not tasks:
        await query.edit_message_text(
            "📋 <b>Available Tasks</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No earning tasks are live right now. Tap “Notify me” and we’ll "
            "let you know when one is published.",
            parse_mode=ParseMode.HTML,
            reply_markup=earning_tasks_menu(
                has_tasks=False,
                has_history=bool(await list_user_task_claims(user["id"], 1)),
            ),
        )
        return
    await query.edit_message_text(
        "📋 <b>Available Tasks</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Join the required channel, remain connected for the stated period, "
        "then verify your task. Leaving early can claw back the reward.",
        parse_mode=ParseMode.HTML,
        reply_markup=task_list_menu(tasks),
    )


async def earn_history_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    claims = await list_user_task_claims(update.effective_user.id, 30)
    if not claims:
        await query.edit_message_text(
            "📜 <b>My Task History</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "You have not joined any earning task yet.",
            parse_mode=ParseMode.HTML,
            reply_markup=earning_tasks_menu(
                has_tasks=bool(await list_active_earning_tasks(1)),
                has_history=False,
            ),
        )
        return
    lines = []
    for claim in claims:
        status = {
            "credited": "credited",
            "clawed_back": "clawed back",
            "failed": "not completed",
            "pending": "pending",
        }.get(claim["status"], claim["status"])
        lines.append(
            f"• <b>{esc(claim['title'])}</b> · ₹{float(claim['reward']):.2f} · {status}"
        )
    await query.edit_message_text(
        "📜 <b>My Task History</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=earning_tasks_menu(
            has_tasks=bool(await list_active_earning_tasks(1)),
            has_history=True,
        ),
    )


async def earn_notify_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = await ensure_user(update.effective_user)
    tasks = await list_active_earning_tasks(50)
    if tasks:
        await query.answer("An earning task is already available.", show_alert=True)
        claims = await list_user_task_claims(user["id"], 5)
        await query.edit_message_text(
            "🌑 <b>Earn with SRC Vault</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "An admin-created earning task is available now.\n\n"
            "Join the required channel and remain joined for the stated "
            "retention period to keep the reward.",
            parse_mode=ParseMode.HTML,
            reply_markup=earning_tasks_menu(
                has_tasks=True, has_history=bool(claims)
            ),
        )
        return
    added = await subscribe_to_earning_task_notifications(user["id"])
    await query.answer(
        "You’ll be notified when an earning task is published."
        if added
        else "You’re already on the notification list."
    )
    claims = await list_user_task_claims(user["id"], 5)
    await query.edit_message_text(
        "🌑 <b>Earn with SRC Vault</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "No earning tasks are live right now.\n\n"
        "🔔 <b>Notification enabled.</b> We’ll message you when an admin "
        "publishes a task.",
        parse_mode=ParseMode.HTML,
        reply_markup=earning_tasks_menu(
            has_tasks=False, has_history=bool(claims)
        ),
    )


async def task_view_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, task_id: int
):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    task = await get_earning_task(task_id)
    if not task or not task["active"]:
        await query.edit_message_text(
            "This task is no longer active.",
            reply_markup=earning_tasks_menu(
                has_tasks=bool(await list_active_earning_tasks(1)),
                has_history=bool(await list_user_task_claims(user["id"], 1)),
            ),
        )
        return
    claim = await get_task_claim(task_id, update.effective_user.id)
    claim_text = ""
    if claim:
        claim_text = f"\nYour status: <b>{esc(claim['status'])}</b>\n"
    await query.edit_message_text(
        f"🎯 <b>{esc(task['title'])}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"{esc(task['description'])}\n\n"
        f"Reward: <b>₹{float(task['reward']):.2f}</b>\n"
        f"Stay joined: <b>{task['retention_days']} day(s)</b>\n"
        f"Telegram chat ID: <code>{esc(task.get('channel_id') or task['channel_ref'])}</code>\n"
        f"Join link: <code>{esc(task.get('channel_link') or task_channel_url(task['channel_ref']))}</code>\n"
        f"{claim_text}\n"
        "Join the channel, then press “I Joined — Verify”.",
        parse_mode=ParseMode.HTML,
        reply_markup=task_detail_menu(
            task_id,
            task_channel_url(task["channel_ref"], task.get("channel_link", "")),
        ),
    )


async def task_claim_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, task_id: int
):
    query = update.callback_query
    user = await ensure_user(update.effective_user)
    task = await get_earning_task(task_id)
    if not task or not task["active"]:
        await query.answer("This task is no longer active.", show_alert=True)
        return
    chat_ref = task_chat_ref(task.get("channel_id") or task["channel_ref"])
    if not chat_ref:
        await query.answer("This task has no valid channel configured.", show_alert=True)
        return
    try:
        member = await context.bot.get_chat_member(chat_ref, update.effective_user.id)
    except Exception:
        log.exception("Could not verify task channel membership for task %s", task_id)
        await query.answer(
            "Membership check is unavailable. The bot must be in that channel.",
            show_alert=True,
        )
        return
    if member.status not in {"member", "administrator", "creator"}:
        await query.answer("Join the channel first, then try again.", show_alert=True)
        return
    existing = await get_task_claim(task_id, update.effective_user.id)
    if existing:
        await query.answer(
            f"Task already marked {existing['status']}.", show_alert=True
        )
        return
    monitor_until = datetime.now(timezone.utc) + timedelta(
        days=max(0, int(task["retention_days"]))
    )
    claim = await claim_earning_task(
        update.effective_user.id, task_id, monitor_until.isoformat()
    )
    if not claim:
        await query.answer("Task was already claimed.", show_alert=True)
        return
    await query.answer("Reward added. Stay joined for the retention period.")
    await send_channel_notification(
        context,
        "✅ <b>TASK COMPLETED</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>User</b>\n{telegram_user_label(update.effective_user)}\n"
        f"🎯 Task: <b>{esc(task['title'])}</b>\n"
        f"🆔 Task ID: <code>#{task_id}</code>\n"
        f"💰 Reward: <b>₹{float(task['reward']):.2f}</b>\n"
        f"⏱ Retention: <b>{task['retention_days']} day(s)</b>\n"
        "📌 Status: <b>Monitoring membership</b>",
    )
    await query.edit_message_text(
        f"✅ <b>Task completed</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"₹{float(task['reward']):.2f} added to your earnings.\n"
        f"Stay in the channel for <b>{task['retention_days']} day(s)</b>.\n"
        "If you leave early, this reward will be automatically clawed back.",
        parse_mode=ParseMode.HTML,
        reply_markup=earning_tasks_menu(
            has_tasks=True,
            has_history=True,
        ),
    )


async def deposit_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    config = await get_payment_config()
    upi_available = is_valid_upi_id(config["upi_id"])
    binance_available = bool(config["binance_id"])
    if not upi_available and not binance_available:
        await query.edit_message_text(
            "💳 <b>Deposit is temporarily unavailable</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No payment method has been configured yet. Please try again later.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_menu(),
        )
        return
    buttons = []
    if upi_available:
        buttons.append([btn("🇮🇳 UPI — Automatic", "deposit_start_upi")])
    if binance_available:
        buttons.append([btn("₿ Binance — Manual", "deposit_start_binance")])
    buttons.extend([
        [btn("📜 My Deposits", "deposit_history")],
        [btn("↩️ Back to Home", "menu")],
    ])
    await query.edit_message_text(
        f"💳 <b>Deposit / Payment</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Choose a payment method for adding money to your wallet.\n\n"
        "UPI deposits are verified automatically.\n"
        f"Binance deposits are manual and use $1 = ₹{BINANCE_USD_TO_INR:.0f}.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def deposit_start_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data.clear()
    context.user_data.update({
        "flow": "deposit",
        "step": "amount",
        "deposit_method": "upi",
    })
    await query.edit_message_text(
        "➕ <b>New Deposit</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Send the amount in INR (minimum ₹10, maximum ₹100,000).\n\n"
        "Do not send a payment until the bot shows your unique QR.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )


async def deposit_binance_start_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE
):
    query = update.callback_query
    await query.answer()
    config = await get_payment_config()
    if not config["binance_id"]:
        await query.edit_message_text(
            "Binance deposits are temporarily unavailable.",
            reply_markup=back_menu(),
        )
        return
    context.user_data.clear()
    context.user_data.update({
        "flow": "deposit",
        "step": "amount",
        "deposit_method": "binance",
    })
    await query.edit_message_text(
        "₿ <b>Binance Manual Deposit</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Binance ID: <code>{esc(config['binance_id'])}</code>\n"
        f"Rate: <b>$1 = ₹{BINANCE_USD_TO_INR:.0f}</b>\n\n"
        "Send the amount in USD (minimum $1, maximum $1,000). "
        "After payment, send the screenshot and Binance transaction ID.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )


def deposit_history_line(row: dict) -> str:
    if str(row.get("upi_id") or "").startswith("BINANCE:"):
        try:
            provider = json.loads(row.get("provider_response") or "{}")
        except json.JSONDecodeError:
            provider = {}
        usd = provider.get("paid_usd")
        amount = (
            f"${float(usd):.2f} → ₹{float(row['amount']):.2f}"
            if usd is not None
            else f"₹{float(row['amount']):.2f}"
        )
        method = "Binance manual"
    else:
        amount = f"₹{float(row['amount']):.2f}"
        method = "UPI automatic"
    return (
        f"#{row['id']} · {method} · {amount} · "
        f"<code>{esc(row['reference'])}</code> · <b>{esc(row['status'])}</b>"
    )


async def deposit_history_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    rows = await list_user_deposits(update.effective_user.id)
    if not rows:
        text = (
            "📜 <b>My Deposits</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No deposits yet."
        )
    else:
        text = "📜 <b>My Deposits</b>\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(
            deposit_history_line(row) for row in rows
        )
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("➕ New Deposit", "deposit_start")],
            [btn("↩️ Back to Deposit", "deposit")],
        ]),
    )


async def show_deposit_qr(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    deposit: dict,
    config: dict,
) -> None:
    uri = build_upi_uri(
        config["upi_id"], config["owner_name"], deposit["amount"], deposit["reference"]
    )
    qr = make_upi_qr(uri)
    caption = (
        f"💳 <b>SRC Vault Deposit #{deposit['id']}</b>\n"
        f"Amount: <b>₹{deposit['amount']:.2f}</b>\n"
        f"UPI: <code>{esc(config['upi_id'])}</code>\n"
        f"Reference: <code>{esc(deposit['reference'])}</code>\n\n"
        "Scan this QR with any UPI app and pay the exact amount. "
        "After payment, send the screenshot and UTR here."
    )
    await update.effective_message.reply_photo(
        photo=qr,
        caption=caption,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[btn("❌ Cancel", "menu")]]),
    )


async def handle_deposit_amount(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> None:
    config = await get_payment_config()
    payment_method = context.user_data.get("deposit_method", "upi")
    if payment_method == "binance":
        try:
            usd_amount = round(
                float(
                    text.upper()
                    .replace("USD", "")
                    .replace("$", "")
                    .replace(",", "")
                    .strip()
                ),
                2,
            )
            if not 1 <= usd_amount <= 1000:
                raise ValueError
        except ValueError:
            await update.message.reply_text(
                "Send a valid Binance amount between $1 and $1,000."
            )
            return
        if await deposit_attempts(update.effective_user.id) >= 5:
            await update.message.reply_text(
                "Deposit request limit reached. Try again after one hour."
            )
            return
        inr_amount = round(usd_amount * BINANCE_USD_TO_INR, 2)
        deposit = await create_deposit(
            update.effective_user.id,
            inr_amount,
            f"BINANCE:{config['binance_id']}",
        )
        context.user_data.update({
            "flow": "deposit",
            "step": "binance_txid",
            "deposit_id": deposit["id"],
            "deposit_usd": usd_amount,
        })
        await update.message.reply_text(
            f"✅ Binance deposit request <code>{esc(deposit['reference'])}</code> created.\n"
            f"Pay <b>${usd_amount:.2f}</b> to <code>{esc(config['binance_id'])}</code>.\n"
            f"Wallet credit after approval: <b>₹{inr_amount:.2f}</b>\n\n"
            "Send the payment screenshot, then send the Binance transaction ID.",
            parse_mode=ParseMode.HTML,
        )
        return
    try:
        amount = round(float(text.replace("₹", "").replace(",", "").strip()), 2)
        if not 10 <= amount <= 100000:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "Send a valid amount between ₹10 and ₹100,000."
        )
        return
    if not is_valid_upi_id(config["upi_id"]):
        context.user_data.clear()
        await update.message.reply_text(
            "Deposits are temporarily unavailable. Please try again later.",
            reply_markup=back_menu(),
        )
        return
    if await deposit_attempts(update.effective_user.id) >= 5:
        await update.message.reply_text(
            "Deposit request limit reached. Try again after one hour."
        )
        return
    deposit = await create_deposit(
        update.effective_user.id, amount, config["upi_id"]
    )
    context.user_data.update({
        "flow": "deposit",
        "step": "utr",
        "deposit_id": deposit["id"],
    })
    await update.message.reply_text(
        f"✅ Deposit request <code>{esc(deposit['reference'])}</code> created.\n"
        "The QR below is locked to this exact amount and reference.",
        parse_mode=ParseMode.HTML,
    )
    await show_deposit_qr(update, context, deposit, config)


async def handle_binance_payment(
    update: Update, context: ContextTypes.DEFAULT_TYPE, txid: str
) -> None:
    deposit_id = context.user_data.get("deposit_id")
    deposit = await get_deposit(deposit_id) if deposit_id else None
    if (
        not deposit
        or deposit["user_id"] != update.effective_user.id
        or not str(deposit.get("upi_id") or "").startswith("BINANCE:")
    ):
        context.user_data.clear()
        await update.message.reply_text(
            "Binance deposit request not found. Start again from Deposit.",
            reply_markup=back_menu(),
        )
        return
    txid = txid.strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{5,127}", txid):
        await update.message.reply_text(
            "Send a valid Binance transaction ID (6–128 characters)."
        )
        return
    if await utr_already_used(txid):
        context.user_data.clear()
        await update.message.reply_text(
            "This transaction ID has already been submitted.",
            reply_markup=back_menu(),
        )
        return
    provider_response = {
        "method": "binance",
        "status": "manual_pending",
        "txid": txid,
        "paid_usd": context.user_data.get("deposit_usd"),
        "exchange_rate": BINANCE_USD_TO_INR,
        "amount": round(float(deposit["amount"]), 2),
    }
    await record_deposit_proof(
        deposit["id"],
        txid,
        provider_response,
        context.user_data.get("deposit_screenshot"),
        "pending",
    )
    await send_channel_notification(
        context,
        "₿ <b>BINANCE DEPOSIT PENDING</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>User</b>\n{telegram_user_label(update.effective_user)}\n"
        f"💵 Amount: <b>${float(provider_response['paid_usd']):.2f}</b>\n"
        f"💰 Wallet credit: <b>₹{float(deposit['amount']):.2f}</b>\n"
        f"🧾 Reference: <code>{esc(deposit['reference'])}</code>\n"
        f"🔢 Transaction ID: <code>{esc(txid)}</code>\n"
        "📌 Status: <b>Manual review required</b>",
    )
    context.user_data.clear()
    await update.message.reply_text(
        "✅ Binance payment submitted for manual review.\n"
        f"Reference: <code>{esc(deposit['reference'])}</code>\n"
        f"Expected wallet credit: <b>₹{float(deposit['amount']):.2f}</b>\n\n"
        "Your wallet will be credited after the owner approves the payment.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )


async def handle_deposit_payment(
    update: Update, context: ContextTypes.DEFAULT_TYPE, utr: str
) -> None:
    deposit_id = context.user_data.get("deposit_id")
    deposit = await get_deposit(deposit_id) if deposit_id else None
    if not deposit or deposit["user_id"] != update.effective_user.id:
        context.user_data.clear()
        await update.message.reply_text(
            "Deposit request not found. Start again from Deposit.",
            reply_markup=back_menu(),
        )
        return
    utr = utr.strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]{5,63}", utr):
        await update.message.reply_text(
            "Send a valid UTR / transaction ID (6–64 letters or numbers)."
        )
        return
    if await utr_already_used(utr):
        context.user_data.clear()
        await update.message.reply_text(
            "This UTR has already been submitted and cannot be reused.",
            reply_markup=back_menu(),
        )
        return

    config = await get_payment_config()
    provider_response = {
        "status": "error",
        "reason": "Verification API was not reached",
    }
    provider_ok = False
    if config["upi_id"]:
        provider_ok, response = await verify_payment(
            utr, deposit["amount"], deposit["upi_id"]
        )
        provider_response = response or provider_response
        try:
            provider_ok = provider_ok and round(
                float(provider_response.get("amount")), 2
            ) == round(float(deposit["amount"]), 2)
        except (TypeError, ValueError):
            provider_ok = False

    screenshot = context.user_data.get("deposit_screenshot")
    await record_deposit_proof(
        deposit["id"], utr, provider_response, screenshot, "pending"
    )
    if provider_ok:
        approved = await approve_deposit(deposit["id"], ADMIN_ID or 0)
        context.user_data.clear()
        if approved and approved["status"] == "approved":
            await send_channel_notification(
                context,
                "💳 <b>DEPOSIT APPROVED</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"👤 <b>User</b>\n{telegram_user_label(update.effective_user)}\n"
                f"💰 Amount: <b>₹{float(deposit['amount']):.2f}</b>\n"
                f"🧾 Reference: <code>{esc(deposit['reference'])}</code>\n"
                f"🔢 UTR: <code>{esc(utr)}</code>\n"
                "✅ Wallet credit: <b>Added</b>",
            )
            await update.message.reply_text(
                f"✅ <b>Deposit verified</b>\n₹{deposit['amount']:.2f} "
                "has been added to your wallet.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_menu(),
            )
            return
    api_message = str(
        provider_response.get("message")
        or provider_response.get("reason")
        or "UTR or amount could not be confirmed"
    )
    await reject_deposit(deposit["id"], ADMIN_ID or 0)
    await send_channel_notification(
        context,
        "❌ <b>DEPOSIT REJECTED</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>User</b>\n{telegram_user_label(update.effective_user)}\n"
        f"💰 Amount: <b>₹{float(deposit['amount']):.2f}</b>\n"
        f"🧾 Reference: <code>{esc(deposit['reference'])}</code>\n"
        f"🔢 UTR: <code>{esc(utr)}</code>\n"
        f"📝 Reason: <b>{esc(api_message)[:300]}</b>\n"
        "🚫 Wallet credit: <b>Not added</b>",
    )
    context.user_data.clear()
    await update.message.reply_text(
        "❌ <b>Automatic verification failed</b>\n"
        f"{esc(api_message)[:300]}\n\n"
        "No wallet credit was added. Check the exact amount and UTR, then start a new deposit.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )


async def dashboard_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    metrics = await user_metrics(user["id"])
    await query.edit_message_text(
        f"📊 <b>Your Dashboard</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Account: <b>{esc(user['first_name'])}</b>\n"
        f"Purchases: <b>{metrics['purchases']}</b>\n"
        f"Transactions: <b>{metrics['transactions']}</b>\n"
        f"Listings: <b>{metrics['listings']}</b>\n"
        f"Sales: <b>{metrics['sales']}</b>\n"
        f"Earnings: <b>₹{float(user['earnings']):.2f}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("👤 Profile", "profile"), btn("🌑 Earn", "earn")],
            [btn("↩️ Back to Home", "menu")],
        ]),
    )


async def updates_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    text = (
        "📢 <b>Official Updates</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "The updates channel link has not been configured yet. Please check back later."
        if not UPDATES_CHANNEL_URL
        else "📢 Open the official SRC Vault updates channel using the button below."
    )
    keyboard = [[btn("↩️ Back to Home", "menu")]]
    if UPDATES_CHANNEL_URL:
        from .utils.keyboards import url_btn
        keyboard.insert(0, [url_btn("📢 Open Updates Channel ↗", UPDATES_CHANNEL_URL)])
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def purchases_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    rows = await list_user_orders(update.effective_user.id)
    paid = [row for row in rows if row["status"] == "paid"]
    if not paid:
        await query.edit_message_text(
            "📘 <b>My Purchases</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "You have no completed purchases yet. Open Store to find your first SRC.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🏪 Open Store", "store")],
                [btn("↩️ Back to Profile", "profile")],
            ]),
        )
        return
    text = "📘 <b>My Purchases</b>\n━━━━━━━━━━━━━━━━━━━━\n"
    text += "\n".join(
        f"#{row['id']} · <b>{esc(row.get('title') or 'SRC')}</b> · "
        f"₹{row['amount']:.2f}"
        + (
            f" · API: {esc(row.get('api_status') or 'pending')}"
            if row.get("api_request_id") else ""
        )
        for row in paid
    )
    keyboard = []
    for row in paid:
        if not row.get("api_request_id"):
            keyboard.append([btn(f"⭐ Rate Order #{row['id']}", f"rate:{row['id']}")])
        elif row.get("api_status") == "delivered":
            keyboard.append([btn(f"⭐ Rate API #{row['id']}", f"rate:{row['id']}")])
            keyboard.append([
                btn("⚠️ Report API Error", f"api_error:{row['api_request_id']}")
            ])
        elif row.get("api_status") == "submitted":
            keyboard.append([
                btn("✅ API is Genuine", f"api_genuine:{row['api_request_id']}"),
                btn("⚠️ Report Error", f"api_error:{row['api_request_id']}"),
            ])
    keyboard.append([btn("↩️ Back to Profile", "profile")])
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def transactions_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    rows = await list_user_transactions(update.effective_user.id)
    if not rows:
        text = (
            "📜 <b>Transactions</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No payment attempts recorded yet."
        )
    else:
        text = "📜 <b>Transactions</b>\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(
            f"#{row['order_id']} · ₹{row['amount']:.2f} · "
            f"<b>{esc(row['status'])}</b> · {esc(row.get('utr') or 'No UTR')}"
            for row in rows
        )
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("💰 Balance", "balance"), btn("↩️ Back to Profile", "profile")],
        ]),
    )


async def reviews_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    rows = await list_user_reviews(update.effective_user.id)
    if not rows:
        text = (
            "⭐ <b>My Reviews</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No reviews yet. After a completed purchase, rate the seller from My Purchases."
        )
    else:
        text = "⭐ <b>My Reviews</b>\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(
            f"{'⭐' * int(row['rating'])} · "
            f"<b>{esc(row.get('title') or 'SRC')}</b>\n"
            f"{esc(row.get('comment') or 'Rating submitted')}"
            for row in rows
        )
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("📘 My Purchases", "my_purchases")],
            [btn("↩️ Back to Profile", "profile")],
        ]),
    )


async def my_listings_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    if user["role"] != "verified_seller" and not is_owner(user["id"]):
        await query.edit_message_text(
            "🔒 Your listings will appear after your seller application is approved.",
            reply_markup=profile_menu(verified=False, owner=False),
        )
        return
    rows = await list_user_listings(update.effective_user.id)
    if not rows:
        text = (
            "📦 <b>My Listings</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "You have not submitted any SRC listings yet."
        )
    else:
        text = "📦 <b>My Listings</b>\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(
            f"#{row['id']} · <b>{esc(row['title'])}</b> · "
            f"₹{row['price']:.2f} · <b>{esc(row['status'])}</b>"
            for row in rows
        )
    await query.edit_message_text(
        text, parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("🛒 Sell New SRC", "sell")],
            [btn("↩️ Back to Earn", "earn")],
        ]),
    )


async def rate_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    parts = query.data.split(":")
    order_id = int(parts[1])
    if len(parts) == 2:
        await query.answer()
        await query.edit_message_text(
            f"⭐ <b>Rate Order #{order_id}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "How was the seller and the delivered SRC?",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("⭐ 1", f"rate:{order_id}:1"), btn("⭐ 2", f"rate:{order_id}:2"),
                 btn("⭐ 3", f"rate:{order_id}:3")],
                [btn("⭐ 4", f"rate:{order_id}:4"), btn("⭐ 5", f"rate:{order_id}:5")],
                [btn("↩️ Back to Purchases", "my_purchases")],
            ]),
        )
        return
    rating = max(1, min(5, int(parts[2])))
    saved = await create_review(order_id, update.effective_user.id, rating)
    await query.answer("Review saved." if saved else "This order was already reviewed.")
    await query.edit_message_text(
        "✅ <b>Review saved</b>\nThanks for helping buyers choose trusted sellers."
        if saved else
        "ℹ️ This order already has a review.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("⭐ My Reviews", "reviews"), btn("↩️ Back to Profile", "profile")],
        ]),
    )


async def support_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    contact = f"@{esc(SUPPORT_USERNAME)}" if SUPPORT_USERNAME else "the owner"
    await update.callback_query.edit_message_text(
        "🆘 <b>Support</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Contact {contact} for payment, seller, or delivery issues.\n"
        "Include your order number and UTR when asking about a payment.\n\n"
        "You can also report the problem directly so the owner can track it.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("📝 Report a Problem", "support_report")],
            [btn("↩️ Back to Home", "menu")],
        ]),
    )


async def support_report_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    context.user_data.update({"flow": "support", "step": "issue"})
    await update.callback_query.edit_message_text(
        "📝 <b>Report a Problem</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Send the problem in one message. Include an order number, payment "
        "reference, or screenshot context if relevant.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[btn("❌ Cancel", "support")]]),
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await force_join_allowed(update, context):
        return
    await update.message.reply_text(
        "🆘 <b>SRC Vault Help</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Use the inline menu to buy or sell source code. "
        "For payment issues, send the order number and UTR to the owner.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )


async def verify_seller_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    if user["role"] == "verified_seller":
        await query.edit_message_text(
            "✅ You are already a verified seller.",
            reply_markup=back_menu(),
        )
        return
    username = update.effective_user.username or "none"
    data = {
        "full_name": update.effective_user.first_name or "Telegram seller",
        "email": username,
        "upi_id": "",
        "identity": "Telegram account verification",
        "portfolio": "",
        "telegram_username": username,
        "telegram_user_id": update.effective_user.id,
    }
    request_id = await create_seller_request(update.effective_user.id, data)
    await query.edit_message_text(
        "✅ <b>Verified Seller Application</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Telegram ID: <code>{update.effective_user.id}</code>\n"
        f"Username: <b>@{esc(username)}</b>\n\n"
        f"Request <code>SR-{request_id}</code> admin review में भेज दी गई है.\n"
        "Approval के बाद आप Add SRC से product submit कर सकेंगे.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )
    await context.bot.send_message(
        ADMIN_ID,
        f"🔔 <b>New Seller Request #{request_id}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Telegram ID: <code>{update.effective_user.id}</code>\n"
        f"Username: @{esc(username)}\n"
        "Verification data is limited to Telegram ID and username.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[
            btn("✅ Approve", f"seller_approve:{request_id}"),
            btn("❌ Reject", f"seller_reject:{request_id}"),
        ]]),
    )


async def seller_begin(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    forced_category: str | None = None,
):
    query = update.callback_query
    await query.answer()
    user = await ensure_user(update.effective_user)
    owner = is_owner(user["id"])
    if user["role"] != "verified_seller" and not owner:
        await query.edit_message_text(
            "🔒 <b>Verified seller access required</b>\n\n"
            "Apply first so buyers can trust your profile. The owner can publish "
            "SRC and API add-ons directly.",
            parse_mode=ParseMode.HTML,
            reply_markup=profile_menu(verified=False, owner=False),
        )
        return
    context.user_data.update({
        "flow": "listing",
        "step": "title",
        "listing": {},
        "listing_category": forced_category,
    })
    product_name = "API add-on" if forced_category == "API" else "SRC product"
    await query.edit_message_text(
        f"➕ <b>Add {product_name}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Step 1/6 — Send the product <b>name</b>.",
        parse_mode=ParseMode.HTML,
    )


async def buy_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await store_callback(update, context, answer=False)


async def store_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    answer: bool = True,
):
    query = update.callback_query
    if answer:
        await query.answer()
    await send_new_callback_message(
        query, context,
        "🏪 <b>SRC Vault Store</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Choose what you want to browse:",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("🧩 SRC Store", "store:src"), btn("🔌 API Store", "store:api")],
            [btn("↩️ Back to Home", "menu")],
        ]),
    )


async def show_listings(query, offset: int, market: str | None = None):
    rows = await list_live_listings(8, offset, market)
    market_name = "API Store" if market == "api" else "SRC Store"
    if not rows:
        await query.edit_message_text(
            f"🏪 <b>{market_name}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "No approved products are live in this section yet.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("↩️ Store Sections", "store")],
                [btn("↩️ Back to Home", "menu")],
            ]),
        )
        return
    keyboard = [
        [btn(f"💻 {row['title'][:34]} · ₹{row['price']:.0f}", f"listing:{row['id']}")]
        for row in rows
    ]
    nav = []
    if offset:
        nav.append(btn("◀️ Previous", f"store_page:{market or 'all'}:{max(0, offset - 8)}"))
    if len(rows) == 8:
        nav.append(btn("Next ▶️", f"store_page:{market or 'all'}:{offset + 8}"))
    if nav:
        keyboard.append(nav)
    keyboard.append([btn("↩️ Store Sections", "store")])
    await query.edit_message_text(
        f"🏪 <b>{market_name}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "Products go live automatically after upload and are checked for marketplace safety.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


def _listing_rating(reviews: list[dict]) -> str:
    if not reviews:
        return "No reviews yet"
    average = sum(int(review["rating"]) for review in reviews) / len(reviews)
    return f"★ {average:.1f}/5 · {len(reviews)} review{'s' if len(reviews) != 1 else ''}"


def _seller_label(seller: dict | None, seller_id: int) -> str:
    if not seller:
        return f"Seller #{seller_id}"
    name = " ".join(
        part for part in (seller.get("first_name"), seller.get("last_name")) if part
    ).strip()
    return esc(name or "Seller")


def _listing_delivery_label(row: dict) -> str:
    if row.get("category") == "API":
        return "🔌 API Base URL"
    if row.get("link"):
        return "🔗 Link"
    if row.get("text_content"):
        return "📝 Text"
    return "📦 File"


def _listing_copy_text(row: dict) -> str:
    description = (row.get("description") or "").strip()
    return description or "No description provided."


def _listing_detail_text(
    row: dict,
    seller: dict | None,
    reviews: list[dict],
    compact: bool = False,
) -> str:
    description = _listing_copy_text(row)
    if compact and len(description) > 560:
        description = description[:560].rstrip() + "…"
    price_line = (
        f"💰 Monthly: <b>₹{float(row['price']):.2f}</b>\n"
        "📅 API plans: <b>1 / 2 / 3 months</b>\n"
        f"🌐 Base URL: <code>{esc(row.get('api_base_url') or 'Provided after purchase')}</code>\n"
        if row.get("category") == "API"
        else f"💰 <b>₹{float(row['price']):.2f}</b>\n"
    )
    return (
        f"╭━━━ ✦ <b>PRODUCT DETAILS</b> ✦ ━━━╮\n"
        f"📦 <b>{esc(row['title'])}</b>\n"
        f"{price_line}"
        f"🗂 Type: <b>{esc(row['category'])}</b>\n"
        f"📤 Delivery: <b>{_listing_delivery_label(row)}</b>\n"
        f"👤 Seller: <b>{_seller_label(seller, row['seller_id'])}</b>\n"
        f"{_listing_rating(reviews)}\n"
        f"╰━━━━━━━━━━━━━━━━━━━━╯\n\n"
        f"📝 <b>Description</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"{esc(description)}\n\n"
        "🛡 Reviewed listing · Secure payment · Instant delivery"
    )


def _listing_detail_keyboard(row: dict, seller: dict | None) -> InlineKeyboardMarkup:
    listing_id = row["id"]
    buy_label = "🔌 Choose API Plan" if row.get("category") == "API" else "🧾 Buy Now"
    buy_callback = f"api_plans:{listing_id}" if row.get("category") == "API" else f"buy_now:{listing_id}"
    return InlineKeyboardMarkup([
        [btn(buy_label, buy_callback)],
        [
            btn("💰 Make Offer", f"offer:{listing_id}"),
            btn("💬 Chat Seller", f"chat:{listing_id}"),
        ],
        [
            btn("⭐ Reviews", f"listing_reviews:{listing_id}"),
            btn("⚠️ Report", f"report:{listing_id}"),
        ],
        [
            copy_btn("📋 Copy Description", _listing_copy_text(row)),
            btn("◀️ Back to Listings", "buy"),
        ],
    ])


async def send_listing_detail_message(
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    row: dict,
) -> bool:
    if not row or row["status"] != "live":
        return False
    listing_id = int(row["id"])
    seller = await get_user(row["seller_id"])
    reviews = await list_listing_reviews(listing_id)
    keyboard = _listing_detail_keyboard(row, seller)
    detail_text = _listing_detail_text(row, seller, reviews)
    preview_id = row.get("preview_file_id")
    preview_type = row.get("preview_type") or ""

    if preview_id and preview_type in {"photo", "video", "animation"}:
        caption = _listing_detail_text(row, seller, reviews, compact=True)
        send_kwargs = {
            "chat_id": chat_id,
            "caption": caption,
            "parse_mode": ParseMode.HTML,
            "reply_markup": keyboard,
        }
        try:
            if preview_type == "photo":
                await context.bot.send_photo(photo=preview_id, **send_kwargs)
            elif preview_type == "video":
                await context.bot.send_video(video=preview_id, **send_kwargs)
            else:
                await context.bot.send_animation(animation=preview_id, **send_kwargs)
            return True
        except Exception:
            log.warning("Invalid preview media for listing %s; using text fallback", listing_id)

    await context.bot.send_message(
        chat_id=chat_id,
        text=detail_text,
        parse_mode=ParseMode.HTML,
        reply_markup=keyboard,
    )
    return True


async def listing_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row or row["status"] != "live":
        await query.answer("Listing is no longer available.", show_alert=True)
        return
    await query.answer()
    context.user_data["view_listing"] = listing_id
    try:
        await query.message.delete()
    except Exception:
        # Telegram may reject deletion for an old message or a restricted chat.
        # Keep the preview and send a fresh listing message instead of silently
        # dropping the seller's uploaded image.
        log.debug("Could not delete listing menu message %s", listing_id)
    await send_listing_detail_message(context, query.message.chat_id, row)


async def offer_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row or row["status"] != "live":
        await query.answer("Listing unavailable.", show_alert=True)
        return
    context.user_data.update({
        "flow": "offer",
        "step": "message",
        "offer_listing_id": listing_id,
    })
    await query.answer()
    await edit_callback_content(
        query, context,
        f"💰 <b>Make an Offer</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Product: <b>{esc(row['title'])}</b>\n"
        f"Listed price: <b>₹{float(row['price']):.2f}</b>\n\n"
        "Send the price you want to offer and any short message. "
        "The seller can reply through Chat Seller.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("❌ Cancel Offer", f"listing:{listing_id}")],
        ]),
    )


async def listing_reviews_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int
):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row:
        await query.answer("Listing unavailable.", show_alert=True)
        return
    reviews = await list_listing_reviews(listing_id)
    if reviews:
        lines = []
        for review in reviews[:8]:
            buyer = review.get("username") or review.get("first_name") or "Buyer"
            stars = "⭐" * int(review["rating"])
            comment = f"\n{esc(review['comment'])}" if review.get("comment") else ""
            lines.append(f"{stars} <b>{esc(buyer)}</b>{comment}")
        body = "\n\n".join(lines)
    else:
        body = "No reviews yet. Verified buyers can review after a completed purchase."
    await query.answer()
    await edit_callback_content(
        query, context,
        f"⭐ <b>Reviews · {esc(row['title'])}</b>\n━━━━━━━━━━━━━━━━━━━━\n{body}",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("↩️ Back to Product", f"listing:{listing_id}")],
            [btn("🏪 Back to Listings", "buy")],
        ]),
    )


async def chat_seller_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int
):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row or row["status"] != "live":
        await query.answer("Listing unavailable.", show_alert=True)
        return
    seller = await get_user(row["seller_id"])
    if not seller:
        await query.answer("Seller is unavailable.", show_alert=True)
        return
    if update.effective_user.id == row["seller_id"]:
        await query.answer("You cannot start a chat with yourself.", show_alert=True)
        return
    session = await get_or_create_chat_session(
        listing_id, update.effective_user.id, row["seller_id"]
    )
    context.user_data.update({
        "flow": "chat",
        "step": "message",
        "chat_listing_id": listing_id,
        "chat_session_id": session["id"],
        "chat_peer_name": _seller_label(seller, row["seller_id"]),
    })
    await query.answer()
    await edit_callback_content(
        query, context,
        f"💬 <b>Chat with {_seller_label(seller, row['seller_id'])}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"Product: <b>{esc(row['title'])}</b>\n\n"
        "Send your message. The bot will deliver it privately to the seller. "
        "Your username and profile link will not be shared.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("⛔ End Chat", f"chat_end:{session['id']}")],
        ]),
    )


async def report_listing_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int
):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row:
        await query.answer("Listing unavailable.", show_alert=True)
        return
    if ADMIN_ID:
        try:
            await context.bot.send_message(
                ADMIN_ID,
                f"⚠️ <b>Listing report</b>\n"
                f"Listing: <code>#{listing_id}</code> · {esc(row['title'])}\n"
                f"Reported by: <code>{update.effective_user.id}</code>",
                parse_mode=ParseMode.HTML,
            )
        except Exception:
            log.exception("Could not send listing report to owner")
    await query.answer("Report sent to the owner.", show_alert=True)


async def chat_reply_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    peer_id: int,
    listing_id: int,
):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row:
        await query.answer("This conversation is no longer available.", show_alert=True)
        return
    current_id = update.effective_user.id
    if current_id == row["seller_id"]:
        buyer_id = peer_id
    elif peer_id == row["seller_id"]:
        buyer_id = current_id
    else:
        await query.answer("This conversation is not available to this account.", show_alert=True)
        return
    session = await get_or_create_chat_session(listing_id, buyer_id, row["seller_id"])
    context.user_data.update({
        "flow": "chat",
        "step": "message",
        "chat_listing_id": listing_id,
        "chat_session_id": session["id"],
        "chat_peer_name": "the other participant",
    })
    await query.answer()
    await query.message.reply_text(
        f"💬 <b>Reply about {esc(row['title'])}</b>\n\n"
        "Send your message. It will be relayed by the bot without exposing "
        "either user's profile.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("⛔ End Chat", f"chat_end:{session['id']}")],
        ]),
    )


async def end_chat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, session_id: int):
    query = update.callback_query
    session = await get_chat_session(session_id)
    if not session or not session["active"] or update.effective_user.id not in {
        session["buyer_id"], session["seller_id"]
    }:
        await query.answer("Chat already ended.", show_alert=True)
        return
    await end_chat_session(session_id)
    context.user_data.clear()
    await query.answer("Chat ended.")
    await query.edit_message_text(
        "⛔ <b>Private chat ended.</b>\n"
        "No profile link or username was shared.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("🏪 Back to Listings", "buy")],
        ]),
    )


async def handle_chat_message(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    listing_id = context.user_data.get("chat_listing_id")
    session_id = context.user_data.get("chat_session_id")
    session = await get_chat_session(session_id) if session_id else None
    row = await get_listing(listing_id) if listing_id else None
    current_id = update.effective_user.id
    if not session or not session["active"] or not row or row["status"] != "live":
        context.user_data.clear()
        await update.effective_message.reply_text(
            "This conversation is no longer available.", reply_markup=back_menu()
        )
        return
    if current_id == session["buyer_id"]:
        peer_id = session["seller_id"]
    elif current_id == session["seller_id"]:
        peer_id = session["buyer_id"]
    else:
        context.user_data.clear()
        await update.effective_message.reply_text(
            "This conversation is not available to this account.",
            reply_markup=back_menu(),
        )
        return
    sender = update.effective_user
    sender_name = _seller_label(
        {"first_name": sender.first_name, "last_name": sender.last_name},
        sender.id,
    )
    try:
        await context.bot.send_message(
            peer_id,
            f"💬 <b>New private message</b>\n"
            f"Product: <b>{esc(row['title'])}</b>\n"
            f"From: <b>{sender_name}</b>\n\n"
            f"{esc(text[:1500])}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[
                btn("↩️ Reply", f"chat_reply:{sender.id}:{listing_id}"),
            ]]),
        )
    except Exception:
        log.exception("Could not relay private chat message")
        await update.effective_message.reply_text(
            "The other participant cannot receive messages right now.",
            reply_markup=back_menu(),
        )
        return
    context.user_data.clear()
    await update.effective_message.reply_text(
        "✅ Message delivered privately through the bot.",
        reply_markup=InlineKeyboardMarkup([
            [btn("💬 Send Another Message", f"chat:{listing_id}")],
            [btn("⛔ End Chat", f"chat_end:{session_id}")],
            [btn("🏪 Back to Listings", "buy")],
        ]),
    )


async def handle_offer(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    listing_id = context.user_data.get("offer_listing_id")
    row = await get_listing(listing_id) if listing_id else None
    if not row or row["status"] != "live":
        context.user_data.clear()
        await update.effective_message.reply_text(
            "This listing is no longer available.", reply_markup=back_menu()
        )
        return
    buyer = update.effective_user
    offer_text = text[:700]
    buyer_name = _seller_label(
        {"first_name": buyer.first_name, "last_name": buyer.last_name},
        buyer.id,
    )
    try:
        await create_offer(listing_id, buyer.id, row["seller_id"], offer_text)
        await context.bot.send_message(
            row["seller_id"],
            f"💰 <b>New offer received</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"Product: <b>{esc(row['title'])}</b>\n"
            f"Listed price: <b>₹{float(row['price']):.2f}</b>\n"
            f"From: <b>{buyer_name}</b>\n\n"
            f"{esc(offer_text)}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[
                btn("↩️ Reply Privately", f"chat_reply:{buyer.id}:{listing_id}"),
            ]]),
        )
    except Exception:
        log.exception("Could not deliver offer to seller")
        await update.effective_message.reply_text(
            "The seller could not be reached right now. Try Chat Seller instead.",
            reply_markup=back_menu(),
        )
        return
    context.user_data.clear()
    await update.effective_message.reply_text(
        f"✅ <b>Offer sent</b>\nThe seller received your message for "
        f"<b>{esc(row['title'])}</b>.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("💬 Chat Seller", f"chat:{listing_id}")],
            [btn("🏪 Back to Listings", "buy")],
        ]),
    )


async def wallet_shortage_callback(
    query, context: ContextTypes.DEFAULT_TYPE, title: str, required: float, balance: float
):
    context.user_data.clear()
    await query.answer("Wallet balance is insufficient. Add money first.", show_alert=True)
    await edit_callback_content(
        query,
        context,
        f"💳 <b>Wallet top-up required</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"Product: <b>{esc(title)}</b>\n"
        f"Required: <b>₹{required:.2f}</b>\n"
        f"Wallet balance: <b>₹{balance:.2f}</b>\n"
        f"Short by: <b>₹{max(0, required - balance):.2f}</b>\n\n"
        "Please add money to your wallet, then come back and buy again.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("➕ Add Money", "deposit")],
            [btn("🏪 Back to Store", "buy")],
        ]),
    )


async def buy_now(update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row or row["status"] != "live":
        await query.answer("Listing unavailable.", show_alert=True)
        return
    if row.get("category") == "API":
        return await api_plans_callback(update, context, listing_id)
    total = round(float(row["price"]), 2)
    user = await get_user(update.effective_user.id)
    balance = float((user or {}).get("wallet_balance", 0) or 0)
    if balance < total:
        return await wallet_shortage_callback(query, context, row["title"], total, balance)
    await query.answer()
    order_id = await create_order(update.effective_user.id, listing_id, total)
    if not await charge_order_from_wallet(order_id, update.effective_user.id, total):
        user = await get_user(update.effective_user.id)
        return await wallet_shortage_callback(
            query, context, row["title"], total,
            float((user or {}).get("wallet_balance", 0) or 0),
        )
    listing = await get_listing(listing_id)
    await deliver_listing(update, context, listing, order_id)
    fee = PLATFORM_FEE_DEFAULT
    seller_amount = round(total * (1 - fee / 100), 2)
    platform_amount = round(total - seller_amount, 2)
    await credit_seller_earnings(listing["seller_id"], seller_amount)
    await context.bot.send_message(
        listing["seller_id"],
        f"💰 <b>Sale completed</b>\nListing: {esc(listing['title'])}\n"
        f"Your wallet credit: <b>₹{seller_amount:.2f}</b> "
        f"(10% platform share: ₹{platform_amount:.2f}).",
        parse_mode=ParseMode.HTML,
    )
    if ADMIN_ID:
        await context.bot.send_message(
            ADMIN_ID,
            f"💰 <b>Sale completed</b>\nOrder #{order_id} · ₹{total:.2f}\n"
            f"Seller wallet: ₹{seller_amount:.2f} · Platform share: ₹{platform_amount:.2f}",
            parse_mode=ParseMode.HTML,
        )
    context.user_data.clear()


async def api_plans_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int
):
    query = update.callback_query
    row = await get_listing(listing_id)
    if not row or row["status"] != "live" or row.get("category") != "API":
        await query.answer("API listing unavailable.", show_alert=True)
        return
    await query.answer()
    monthly = float(row["price"])
    await edit_callback_content(
        query,
        context,
        f"🔌 <b>{esc(row['title'])}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"Monthly price: <b>₹{monthly:.2f}</b>\n"
        "Choose API access duration. Total is calculated automatically:",
        parse_mode=ParseMode.HTML,
        reply_markup=api_plan_menu(listing_id, monthly, API_PLAN_MONTHS),
    )


async def buy_api_plan(
    update: Update, context: ContextTypes.DEFAULT_TYPE, listing_id: int, months: int
):
    query = update.callback_query
    if months not in API_PLAN_MONTHS:
        await query.answer("Only 1, 2, or 3 months are available.", show_alert=True)
        return
    row = await get_listing(listing_id)
    if not row or row["status"] != "live" or row.get("category") != "API":
        await query.answer("API listing unavailable.", show_alert=True)
        return
    monthly = round(float(row["price"]), 2)
    total = round(monthly * months, 2)
    user = await get_user(update.effective_user.id)
    balance = float((user or {}).get("wallet_balance", 0) or 0)
    if balance < total:
        return await wallet_shortage_callback(query, context, row["title"], total, balance)
    await query.answer()
    order_id = await create_order(
        update.effective_user.id,
        listing_id,
        total,
        duration_months=months,
        monthly_price=monthly,
    )
    if not await charge_order_from_wallet(order_id, update.effective_user.id, total):
        user = await get_user(update.effective_user.id)
        return await wallet_shortage_callback(
            query, context, row["title"], total,
            float((user or {}).get("wallet_balance", 0) or 0),
        )
    request = await create_api_request_for_order(order_id)
    if not request:
        await refund_order_to_wallet(order_id, update.effective_user.id, total)
        await edit_callback_content(
            query,
            context,
            "❌ API order could not be created safely. The full amount was returned "
            "to your wallet.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_menu(),
        )
        return
    context.user_data.clear()
    deadline = request["deadline"].replace("T", " ")[:16]
    await edit_callback_content(
        query,
        context,
        "✅ <b>Wallet payment successful</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"Product: <b>{esc(row['title'])}</b>\n"
        f"Duration: <b>{months} month{'s' if months != 1 else ''}</b>\n"
        f"Amount paid from wallet: <b>₹{total:.2f}</b>\n\n"
        f"Seller delivery deadline: <b>{deadline} UTC</b>\n"
        "The seller has 4 hours to submit API access. If they miss it, "
        "the full amount will be refunded to your wallet.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("💬 Chat Seller", f"api_chat:{request['id']}")],
            [btn("🏪 Back to Store", "buy")],
        ]),
    )
    try:
        await context.bot.send_message(
            request["seller_id"],
            "🔌 <b>New API fulfilment request</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Request: <code>{esc(request['reference'])}</code>\n"
            f"Product: <b>{esc(row['title'])}</b>\n"
            f"Duration: <b>{request['duration_months']} month(s)</b>\n"
            f"Amount: <b>₹{float(request['total_amount']):.2f}</b>\n"
            f"Deadline: <b>{deadline} UTC</b>\n\n"
            "Submit the API access details within 4 hours. Seller payout stays "
            "on hold until the buyer confirms the API is genuine.",
            parse_mode=ParseMode.HTML,
            reply_markup=api_request_menu(request["id"], request["listing_id"]),
        )
    except Exception:
        log.exception("Could not notify API seller for request %s", request["id"])
    if ADMIN_ID:
        await context.bot.send_message(
            ADMIN_ID,
            f"🔌 API order paid from wallet · <code>{esc(request['reference'])}</code>\n"
            f"Buyer: <code>{request['buyer_id']}</code> · Seller: <code>{request['seller_id']}</code>\n"
            f"Amount: ₹{float(request['total_amount']):.2f} · Deadline: {deadline} UTC",
            parse_mode=ParseMode.HTML,
        )


async def api_delivery_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: int
):
    query = update.callback_query
    request = await get_api_request(request_id)
    if not request or request["seller_id"] != update.effective_user.id:
        await query.answer("This API request is not assigned to you.", show_alert=True)
        return
    if request["status"] not in ("pending_seller", "submitted"):
        await query.answer(
            f"Request is already {request['status']}.", show_alert=True
        )
        return
    context.user_data.update({
        "flow": "api_delivery",
        "step": "payload",
        "api_request_id": request_id,
    })
    await query.answer()
    await edit_callback_content(
        query,
        context,
        "📤 <b>Submit API Access</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"Request: <code>{esc(request['reference'])}</code>\n"
        f"Product: <b>{esc(request['title'])}</b>\n"
        f"Duration: <b>{request['duration_months']} month(s)</b>\n\n"
        "Send the API base URL, key/access instructions and any usage limits "
        "in one message. Do not send unrelated passwords or private keys.\n\n"
        "The buyer will receive exactly what you submit.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("❌ Cancel", f"listing:{request['listing_id']}")],
        ]),
    )


async def api_chat_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: int
):
    request = await get_api_request(request_id)
    if not request:
        await update.callback_query.answer("API request not found.", show_alert=True)
        return
    current_id = update.effective_user.id
    if current_id == request["seller_id"]:
        return await chat_reply_callback(
            update, context, request["buyer_id"], request["listing_id"]
        )
    if current_id == request["buyer_id"]:
        return await chat_seller_callback(update, context, request["listing_id"])
    await update.callback_query.answer("This chat is not available.", show_alert=True)


async def api_genuine_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: int
):
    query = update.callback_query
    request = await get_api_request(request_id)
    if not request or request["buyer_id"] != update.effective_user.id:
        await query.answer("This API confirmation is not for your account.", show_alert=True)
        return
    if request["status"] not in ("submitted", "delivered"):
        await query.answer(
            "The API cannot be confirmed in its current state.", show_alert=True
        )
        return
    fee = PLATFORM_FEE_DEFAULT
    seller_amount = round(float(request["total_amount"]) * (1 - fee / 100), 2)
    platform_amount = round(float(request["total_amount"]) - seller_amount, 2)
    delivered = await mark_api_request_delivered(request_id, seller_amount)
    if not delivered:
        await query.answer("Could not confirm this API safely.", show_alert=True)
        return
    await query.answer("API confirmed as genuine.")
    await edit_callback_content(
        query,
        context,
        "✅ <b>API confirmed genuine</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"Seller payout released: <b>₹{seller_amount:.2f}</b>\n"
        f"Platform share: <b>₹{platform_amount:.2f}</b>\n\n"
        "Please rate the API and seller. You can still report a future API problem "
        "using the error button below.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [
                btn("⭐ 1", f"rate:{request['order_id']}:1"),
                btn("⭐ 2", f"rate:{request['order_id']}:2"),
                btn("⭐ 3", f"rate:{request['order_id']}:3"),
            ],
            [
                btn("⭐ 4", f"rate:{request['order_id']}:4"),
                btn("⭐ 5", f"rate:{request['order_id']}:5"),
            ],
            [btn("⚠️ Report API Error", f"api_error:{request_id}")],
            [btn("💬 Chat Seller", f"api_chat:{request_id}")],
        ]),
    )
    try:
        await context.bot.send_message(
            request["seller_id"],
            f"✅ Buyer confirmed API <code>{esc(request['reference'])}</code> as genuine.\n"
            f"Seller wallet credited: <b>₹{seller_amount:.2f}</b>.",
            parse_mode=ParseMode.HTML,
        )
    except Exception:
        log.exception("Could not notify seller about API confirmation %s", request_id)
    if ADMIN_ID:
        await context.bot.send_message(
            ADMIN_ID,
            f"✅ API confirmed genuine · <code>{esc(request['reference'])}</code>\n"
            f"Seller: <code>{request['seller_id']}</code> · Buyer: <code>{request['buyer_id']}</code>\n"
            f"Seller wallet: ₹{seller_amount:.2f} · Platform share: ₹{platform_amount:.2f}",
            parse_mode=ParseMode.HTML,
        )


async def api_error_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: int
):
    query = update.callback_query
    request = await get_api_request(request_id)
    if not request or request["buyer_id"] != update.effective_user.id:
        await query.answer("This API request is not for your account.", show_alert=True)
        return
    if request["status"] not in ("submitted", "delivered"):
        await query.answer("API error reporting is not available for this request.", show_alert=True)
        return
    context.user_data.update({
        "flow": "api_error",
        "step": "message",
        "api_request_id": request_id,
    })
    await query.answer()
    await edit_callback_content(
        query,
        context,
        "⚠️ <b>Report API Error</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"Request: <code>{esc(request['reference'])}</code>\n"
        "Send the error details in one message. The seller will receive it "
        "directly and can help you fix the API access.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [btn("❌ Cancel", f"api_error_cancel:{request_id}")],
        ]),
    )


async def handle_api_error(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
):
    request_id = context.user_data.get("api_request_id")
    request = await get_api_request(request_id) if request_id else None
    if not request or request["buyer_id"] != update.effective_user.id:
        context.user_data.clear()
        await update.message.reply_text(
            "API request not found or no longer available.", reply_markup=back_menu()
        )
        return
    message = text.strip()
    if len(message) < 5:
        await update.message.reply_text("Please describe the API error in a little more detail.")
        return
    await record_audit_event(
        update.effective_user.id,
        "api_error_reported",
        "api_request",
        str(request_id),
        message[:4000],
    )
    context.user_data.clear()
    try:
        await context.bot.send_message(
            request["seller_id"],
            "⚠️ <b>API error reported by buyer</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Request: <code>{esc(request['reference'])}</code>\n"
            f"Product: <b>{esc(request['title'])}</b>\n\n"
            f"{esc(message[:3000])}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💬 Reply to Buyer", f"api_chat:{request_id}")],
            ]),
        )
    except Exception:
        log.exception("Could not notify seller about API error %s", request_id)
    if ADMIN_ID:
        await context.bot.send_message(
            ADMIN_ID,
            "⚠️ <b>API error reported</b>\n"
            f"Request: <code>{esc(request['reference'])}</code>\n"
            f"Buyer: <code>{request['buyer_id']}</code> · Seller: <code>{request['seller_id']}</code>\n\n"
            f"{esc(message[:2500])}",
            parse_mode=ParseMode.HTML,
        )
    await update.message.reply_text(
        "✅ API error seller को भेज दिया गया है. Seller अब आपको इसी bot के through reply कर सकता है.",
        reply_markup=InlineKeyboardMarkup([
            [btn("💬 Chat Seller", f"api_chat:{request_id}")],
            [btn("📘 My Purchases", "my_purchases")],
        ]),
    )


async def handle_api_delivery(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
):
    request_id = context.user_data.get("api_request_id")
    request = await get_api_request(request_id) if request_id else None
    if not request or request["seller_id"] != update.effective_user.id:
        context.user_data.clear()
        await update.message.reply_text(
            "API request expired or is not assigned to you.", reply_markup=back_menu()
        )
        return
    payload = text.strip()
    if len(payload) < 10:
        await update.message.reply_text(
            "Please send the complete API URL/access details, not a short placeholder."
        )
        return
    saved = await submit_api_delivery(
        request_id, update.effective_user.id, payload, "Seller submitted through bot"
    )
    if not saved:
        context.user_data.clear()
        await update.message.reply_text(
            "This API request was already submitted or closed.", reply_markup=back_menu()
        )
        return
    context.user_data.clear()
    await update.message.reply_text(
        f"✅ API access submitted for <code>{esc(saved['reference'])}</code>.\n"
        "The buyer has received the access and must confirm that the API is genuine "
        "before your seller payout is released.",
        parse_mode=ParseMode.HTML,
        reply_markup=back_menu(),
    )
    try:
        await context.bot.send_message(
            request["buyer_id"],
            "✅ <b>API access delivered</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Request: <code>{esc(request['reference'])}</code>\n"
            f"Product: <b>{esc(request['title'])}</b>\n\n"
            f"<pre>{esc(payload)}</pre>\n\n"
            "Use the access only within the purchased duration. If it is genuine, "
            "confirm it below so the seller can receive the payout. If it fails, "
            "report the API error and send the seller a message.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("✅ API is Genuine", f"api_genuine:{request_id}")],
                [btn("⚠️ Report API Error", f"api_error:{request_id}")],
                [btn("💬 Chat Seller", f"api_chat:{request_id}")],
                [btn("📘 My Purchases", "my_purchases")],
            ]),
        )
    except Exception:
        log.exception("Could not deliver API payload to buyer for request %s", request_id)
    if ADMIN_ID:
        await context.bot.send_message(
            ADMIN_ID,
            f"✅ API access submitted · <code>{esc(request['reference'])}</code>\n"
            f"Seller: <code>{request['seller_id']}</code> · Buyer: <code>{request['buyer_id']}</code>\n"
            "Seller payout is held until buyer confirms the API is genuine.",
            parse_mode=ParseMode.HTML,
        )


async def handle_seller_step(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    step = context.user_data.get("step")
    data = context.user_data.setdefault("seller", {})
    prompts = {
        "full_name": ("email", "Step 2/5 — Send your <b>email address</b>."),
        "email": ("upi_id", "Step 3/5 — Send your <b>UPI ID</b> for payouts."),
        "upi_id": ("portfolio", "Step 2/2 — Send a portfolio link or short experience note."),
        "identity": ("portfolio", "Step 5/5 — Send an experience note or portfolio link."),
    }
    if step == "full_name":
        data["full_name"] = text
    elif step == "email":
        if "@" not in text:
            await update.message.reply_text("Please send a valid email address.")
            return
        data["email"] = text
    elif step == "upi_id":
        data["upi_id"] = text
    elif step == "identity":
        data["identity"] = "" if text.lower() == "skip" else text
    next_step, prompt = prompts[step]
    context.user_data["step"] = next_step
    await update.message.reply_text(prompt, parse_mode=ParseMode.HTML)
    if step == "identity":
        # The portfolio value is collected by the next message.
        pass


async def finish_seller(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    data = context.user_data["seller"]
    data["portfolio"] = text
    request_id = await create_seller_request(update.effective_user.id, data)
    await update.message.reply_text(
        f"✅ <b>Application submitted</b>\n\nReference: <code>SR-{request_id}</code>\n"
        "The owner will review your profile.",
        parse_mode=ParseMode.HTML, reply_markup=back_menu(),
    )
    await context.bot.send_message(
        ADMIN_ID,
        f"🔔 <b>New Seller Request #{request_id}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"Telegram ID: <code>{update.effective_user.id}</code>\n"
        f"Telegram username: @{esc(update.effective_user.username) or 'not set'}\n"
        f"Name: <b>{esc(data['full_name'])}</b>\nEmail: {esc(data['email'])}\n"
        f"UPI: <code>{esc(data['upi_id'])}</code>\n"
        f"Profile note: {esc(data.get('identity') or 'Telegram account')}\n"
        f"Portfolio: {esc(data['portfolio'])}\n\n"
        "No password or account credential is collected.",
        parse_mode=ParseMode.HTML,
        reply_markup=__import__("telegram").InlineKeyboardMarkup([[
            btn("✅ Approve", f"seller_approve:{request_id}"),
            btn("❌ Reject", f"seller_reject:{request_id}"),
        ], [btn("ℹ️ Ask More Info", f"seller_info:{request_id}")]]),
    )
    context.user_data.clear()


async def handle_withdrawal_step(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> None:
    data = context.user_data.setdefault("withdrawal", {})
    step = context.user_data.get("step")
    if step == "upi":
        upi_id = text.strip()
        if not is_valid_upi_id(upi_id):
            await update.message.reply_text(
                "Send a valid UPI ID, for example <code>name@upi</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        data["upi_id"] = upi_id
        context.user_data["step"] = "amount"
        user = await ensure_user(update.effective_user)
        available = float(user.get("earnings", 0))
        await update.message.reply_text(
            "✅ UPI ID saved.\n\n"
            f"Step 2/2 — Send the amount to withdraw.\n"
            f"Available: <b>₹{available:.2f}</b>",
            parse_mode=ParseMode.HTML,
        )
        return
    if step == "amount":
        try:
            amount = round(float(text.replace("₹", "").replace(",", "").strip()), 2)
        except ValueError:
            amount = 0
        user = await ensure_user(update.effective_user)
        available = float(user.get("earnings", 0))
        if amount <= 0 or amount > available:
            await update.message.reply_text(
                f"Send a valid amount between ₹0.01 and ₹{available:.2f}."
            )
            return
        data["amount"] = amount
        request = await create_withdrawal_request(
            update.effective_user.id, data["amount"], data["upi_id"]
        )
        if not request:
            context.user_data.clear()
            await update.message.reply_text(
                "The amount is no longer available. Open Seller Dashboard and try again.",
                reply_markup=back_menu(),
            )
            return
        context.user_data.clear()
        await update.message.reply_text(
            "✅ <b>Withdrawal request submitted</b>\n"
            f"Request: <code>WD-{request['id']}</code>\n"
            f"Amount: <b>₹{float(request['amount']):.2f}</b>\n"
            f"UPI: <code>{esc(request['upi_id'])}</code>\n\n"
            "The owner will review it and send the payment.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💰 Funds", "seller_funds")],
                [btn("🛍 Seller Dashboard", "seller_center")],
            ]),
        )
        if ADMIN_ID:
            username = update.effective_user.username
            username_label = f"@{esc(username)}" if username else "not set"
            await context.bot.send_message(
                ADMIN_ID,
                "💸 <b>New Withdrawal Request</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"Request: <code>WD-{request['id']}</code>\n"
                f"Seller name: <b>{esc(update.effective_user.full_name)}</b>\n"
                f"Username: <b>{username_label}</b>\n"
                f"Telegram ID: <code>{request['user_id']}</code>\n"
                f"Amount: <b>₹{float(request['amount']):.2f}</b>\n"
                f"UPI: <code>{esc(request['upi_id'])}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[
                    btn("✅ Payment Sent / Success", f"withdraw_approve:{request['id']}"),
                    btn("❌ Reject & Refund", f"withdraw_reject:{request['id']}"),
                ]]),
            )


async def handle_listing_step(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    step = context.user_data.get("step")
    data = context.user_data.setdefault("listing", {})
    if step == "title":
        data["title"] = text
        context.user_data["step"] = "description"
        await update.message.reply_text(
            "Step 2 — Send the product <b>description</b>.",
            parse_mode=ParseMode.HTML,
        )
    elif step == "description":
        data["description"] = text
        forced_category = context.user_data.get("listing_category")
        if forced_category:
            data["category"] = forced_category
            context.user_data["step"] = "api_base_url"
            await update.message.reply_text(
                "Step 3 — Send the <b>API Base URL</b>.\n"
                "Example: <code>https://your-api.vercel.app</code>\n"
                "Use the base endpoint only; do not send API keys or passwords.",
                parse_mode=ParseMode.HTML,
            )
        else:
            context.user_data["step"] = "category"
            src_categories = [category for category in CATEGORIES if category != "API"]
            await update.message.reply_text(
                "Step 3 — Send the SRC category exactly: "
                + ", ".join(src_categories)
                + ". For an API add-on, use the separate Add API Add-on button."
            )
    elif step == "api_base_url":
        base_url = text.strip()
        if not is_valid_http_url(base_url):
            await update.message.reply_text(
                "Send a valid HTTP or HTTPS base URL.\n"
                "Example: https://your-api.vercel.app"
            )
            return
        data["api_base_url"] = base_url.rstrip("/")
        context.user_data["step"] = "price"
        await update.message.reply_text(
            "Step 4 — Send the monthly API price in INR "
            f"(minimum ₹{MIN_PRICE})."
        )
    elif step == "category":
        src_categories = [category for category in CATEGORIES if category != "API"]
        category = next((c for c in src_categories if c.lower() == text.lower()), None)
        if not category:
            await update.message.reply_text(
                "Choose one: " + ", ".join(src_categories)
                + ". Use Seller Center → Add API Add-on for API products."
            )
            return
        data["category"] = category
        context.user_data["step"] = "price"
        price_label = "monthly API price" if category == "API" else "product price"
        await update.message.reply_text(
            f"Step 4 — Send the {price_label} in INR (minimum ₹{MIN_PRICE})."
        )
    elif step == "price":
        try:
            price = float(text.replace("₹", "").strip())
            if price < MIN_PRICE:
                raise ValueError
        except ValueError:
            await update.message.reply_text(f"Enter a valid price of at least ₹{MIN_PRICE}.")
            return
        data["price"] = round(price, 2)
        if data.get("category") == "API":
            # API listings are access products. They publish with their base URL
            # and monthly price; no downloadable file or preview is collected.
            await update.message.reply_text(
                "✅ API details received. Publishing the API add-on with its "
                "base URL and monthly price—no file upload is needed."
            )
            await save_listing(update, context)
        else:
            context.user_data["step"] = "content"
            await update.message.reply_text(
                "Next — Send the product file now as a document "
                "(Python, ZIP, APK, PDF, or any other file).\n\n"
                "After the file, you can send one preview photo or video so "
                "buyers can see it before purchasing."
            )
    elif step == "delivery":
        # Backward compatibility for seller sessions created before the
        # auto-detect upload flow was enabled.
        if text.lower() in {"file", "link", "text"}:
            data["delivery"] = text.lower()
            context.user_data["step"] = "content"
            await update.message.reply_text(
                "Send the delivery content now (file/image, link, or code/text)."
            )
        else:
            context.user_data["step"] = "content"
            await handle_listing_step(update, context, text)
    elif step == "content":
        await update.message.reply_text(
            "Please send the SRC as a file/document first. "
            "After the file, send one preview photo or video."
        )
    elif step == "preview":
        data["preview"] = "" if text.lower() == "skip" else text
        await update.message.reply_text(
            "Publishing your SRC now and checking the file for marketplace safety."
        )
        await save_listing(update, context)


async def audit_submission(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    kind: str,
) -> bool:
    """Copy seller submissions to every configured security log destination."""
    audit_chat_ids = log_destination_ids()
    if not audit_chat_ids:
        return True
    failed = False
    message = update.effective_message
    for audit_chat_id in audit_chat_ids:
        try:
            await context.bot.copy_message(
                chat_id=audit_chat_id,
                from_chat_id=message.chat_id,
                message_id=message.message_id,
                disable_notification=True,
            )
            await context.bot.send_message(
                audit_chat_id,
                f"Seller submission audit\n"
                f"Seller ID: {update.effective_user.id}\n"
                f"Username: @{update.effective_user.username or 'not set'}\n"
                f"Type: {kind}",
                disable_notification=True,
            )
        except Exception:
            failed = True
            log.exception(
                "Could not write seller submission to audit channel %s",
                audit_chat_id,
            )
    if failed:
        await update.effective_message.reply_text(
            "Upload received, but the safety check is unavailable. "
            "Please try again after the owner fixes the channel configuration."
        )
        return False
    return True


async def confirm_listing_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get("flow") != "listing" or context.user_data.get("step") != "confirm_listing":
        await update.callback_query.answer("Listing session expired.", show_alert=True)
        return
    await update.callback_query.answer()
    await save_listing(update, context)


async def send_listing_notification(
    context: ContextTypes.DEFAULT_TYPE,
    listing_id: int,
    data: dict,
    seller,
) -> None:
    category = str(data.get("category") or "Other")
    deep_link = await listing_start_link(context, listing_id)
    markup = (
        InlineKeyboardMarkup([[url_btn("🛍 Check Product", deep_link)]])
        if deep_link
        else None
    )
    description = str(data.get("description") or "No description provided.").strip()
    if len(description) > 1800:
        description = description[:1800].rstrip() + "…"
    file_name = str(data.get("file_name") or "").strip()
    suffix = Path(file_name).suffix.casefold()
    format_label = {
        ".zip": "ZIP file",
        ".py": "Python file",
        ".js": "JavaScript file",
        ".ts": "TypeScript file",
        ".html": "HTML file",
        ".css": "CSS file",
        ".json": "JSON file",
        ".apk": "APK file",
        ".pdf": "PDF file",
    }.get(suffix)
    if not format_label and not file_name:
        format_label = {
            "photo": "Image",
            "video": "Video",
            "audio": "Audio",
            "animation": "Animation",
            "document": "File",
        }.get(str(data.get("file_type") or "document"), "File")
    format_line = f"📄 Format: <b>{esc(format_label)}</b>\n" if format_label else ""
    await send_channel_notification(
        context,
        "✨ <b>NEW LISTING</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🆔 Listing: <code>#{listing_id}</code>\n"
        f"🏷 Name: <b>{esc(data['title'])}</b>\n"
        f"🗂 Type: <b>{esc(category)}</b>\n"
        f"{format_line}"
        f"💰 Price: <b>₹{float(data['price']):.2f}</b>\n"
        f"📝 <b>Description</b>\n{esc(description)}\n"
        "✅ Status: <b>LIVE</b>",
        reply_markup=markup,
        chat_id=product_chat_id(),
    )


async def save_listing(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = context.user_data["listing"]
    data.setdefault("category", "Other")
    listing_id = await create_listing(update.effective_user.id, data, status="live")
    await update.effective_message.reply_text(
        f"✅ <b>Listing is live now</b>\n"
        f"Reference: <code>LS-{listing_id}</code>",
        parse_mode=ParseMode.HTML, reply_markup=back_menu(),
    )
    await send_listing_notification(
        context, listing_id, data, update.effective_user
    )
    for audit_chat_id in log_destination_ids():
        if data.get("file_id"):
            await send_stored_media(
                context, audit_chat_id, data["file_id"],
                data.get("file_type", "document"),
                f"📦 Live SRC file · Listing #{listing_id}",
            )
        if data.get("preview_file_id"):
            await send_stored_media(
                context, audit_chat_id, data["preview_file_id"],
                data.get("preview_type", "photo"),
                f"🖼 Listing preview · #{listing_id}",
            )
    context.user_data.clear()


async def send_stored_media(
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    file_id: str,
    file_type: str,
    caption: str,
) -> None:
    if file_type == "photo":
        await context.bot.send_photo(chat_id, file_id, caption=caption)
    elif file_type == "video":
        await context.bot.send_video(chat_id, file_id, caption=caption)
    elif file_type == "audio":
        await context.bot.send_audio(chat_id, file_id, caption=caption)
    elif file_type == "animation":
        await context.bot.send_animation(chat_id, file_id, caption=caption)
    else:
        await context.bot.send_document(chat_id, file_id, caption=caption)


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.effective_message or context.user_data is None:
        return
    if context.user_data.get("flow") != "listing" or context.user_data.get("step") != "content":
        return
    if context.user_data["listing"].get("category") == "API":
        await update.message.reply_text(
            "API listings do not take a file. Send the API base URL during the "
            "API listing setup; API access is delivered after purchase."
        )
        return
    document = update.message.document
    if (document.file_size or 0) > MAX_FILE_MB * 1024 * 1024:
        await update.message.reply_text(f"File is larger than {MAX_FILE_MB}MB.")
        return
    if not await audit_submission(update, context, "document/file submission"):
        return
    context.user_data["listing"]["file_id"] = document.file_id
    context.user_data["listing"]["file_type"] = "document"
    context.user_data["listing"]["file_name"] = document.file_name or ""
    context.user_data["listing"]["delivery"] = "file"
    context.user_data["step"] = "preview_media"
    await update.message.reply_text(
        "File received. Send one preview photo or video so buyers can see your product."
    )


async def finish_listing_preview(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    file_id: str,
    file_type: str,
    audit_kind: str,
) -> None:
    if not await audit_submission(update, context, audit_kind):
        return
    listing = context.user_data["listing"]
    listing["preview_file_id"] = file_id
    listing["preview_type"] = file_type
    await save_listing(update, context)


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.effective_message or context.user_data is None:
        return
    if context.user_data.get("flow") == "listing":
        if context.user_data.get("step") != "preview_media":
            await update.message.reply_text(
                "Send the SRC file first, then send one preview photo."
            )
            return
        await finish_listing_preview(
            update, context, update.message.photo[-1].file_id, "photo", "preview image"
        )
        return
    if (
        context.user_data.get("flow") == "deposit"
        and context.user_data.get("step") in {"utr", "binance_txid"}
    ):
        context.user_data["deposit_screenshot"] = update.message.photo[-1].file_id
        await update.message.reply_text(
            "Screenshot received. Now send the transaction ID."
        )
        return
    if (
        context.user_data.get("flow") == "admin"
        and context.user_data.get("step") == "owner_qr"
        and is_owner(update.effective_user.id)
    ):
        await set_setting("owner_qr_file_id", update.message.photo[-1].file_id)
        context.user_data.clear()
        await update.message.reply_text(
            "✅ Payment QR saved. New deposits still use amount-locked QR generation "
            "when the UPI ID is configured.",
            reply_markup=back_menu(),
        )
        return
    if context.user_data.get("flow") != "payment":
        return
    context.user_data["payment_screenshot"] = update.message.photo[-1].file_id
    await update.message.reply_text("Screenshot received. Now send the UTR / Transaction ID.")


async def handle_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.effective_message or context.user_data is None:
        return
    if context.user_data.get("flow") != "listing":
        return
    message = update.effective_message
    media = message.video or message.audio or message.animation
    if not media:
        return
    if context.user_data.get("step") != "preview_media":
        await message.reply_text(
            "Send the SRC file as a document first, then send one preview video."
        )
        return
    if (getattr(media, "file_size", 0) or 0) > MAX_FILE_MB * 1024 * 1024:
        await message.reply_text(f"File is larger than {MAX_FILE_MB}MB.")
        return
    file_type = "video" if message.video else "audio" if message.audio else "animation"
    await finish_listing_preview(
        update, context, media.file_id, file_type, f"preview {file_type}"
    )


async def handle_payment(update: Update, context: ContextTypes.DEFAULT_TYPE, utr: str):
    # Orders are wallet-only. Keep any stale legacy payment session from
    # turning an awaiting_payment order into a paid order.
    context.user_data.clear()
    await update.message.reply_text(
        "Wallet-only checkout is enabled. Add money to your wallet first, "
        "then buy again from the Store.",
        reply_markup=InlineKeyboardMarkup([
            [btn("➕ Add Money", "deposit")],
            [btn("🏪 Back to Store", "buy")],
        ]),
    )
    return
    # Legacy direct-UPI checkout is intentionally unreachable.
    # The code below is retained only for persisted-session compatibility.
    order_id = context.user_data.get("order_id")
    order = await get_order(order_id) if order_id else None
    if not order or order["buyer_id"] != update.effective_user.id:
        await update.message.reply_text("Order not found. Start again from Buy SRC.")
        context.user_data.clear()
        return
    if await utr_attempts(update.effective_user.id) >= UTR_LIMIT_PER_HOUR:
        await update.message.reply_text("Rate limit reached. Try again after one hour.")
        return
    if await utr_already_used(utr.strip()):
        context.user_data.clear()
        await update.message.reply_text(
            "This UTR has already been submitted and cannot be reused.",
            reply_markup=back_menu(),
        )
        return
    await update.message.reply_text("⏳ <b>Verifying payment...</b>", parse_mode=ParseMode.HTML)
    config = await get_payment_config()
    if not is_valid_upi_id(config["upi_id"]):
        context.user_data.clear()
        await update.message.reply_text(
            "Payments are temporarily unavailable. Please try again later.",
            reply_markup=back_menu(),
        )
        return
    ok, response = await verify_payment(utr.strip(), order["amount"], config["upi_id"])
    screenshot = context.user_data.get("payment_screenshot")
    await record_payment(
        order_id, utr.strip(), response, "success" if ok else "failed", screenshot
    )
    if not ok:
        refund_added = await refund_order_to_wallet(
            order_id, order["buyer_id"], float(order["amount"])
        )
        attempts = await utr_attempts(update.effective_user.id)
        if attempts >= 3:
            await record_payment(
                order_id, utr.strip(), response, "auto_rejected", screenshot
            )
            if screenshot:
                await context.bot.send_photo(
                    ADMIN_ID, screenshot,
                    caption=f"⚠️ Order #{order_id} auto-rejected after 3 failed UTR attempts.",
                )
            await update.message.reply_text(
                "❌ Payment verification failed three times. This order is auto-rejected.\n"
                + (
                    f"₹{float(order['amount']):.2f} wallet credit added automatically."
                    if refund_added else "Wallet credit was already processed for this order."
                ),
                reply_markup=back_menu(),
            )
        else:
            if screenshot:
                await context.bot.send_photo(
                    ADMIN_ID, screenshot,
                    caption=f"⚠️ Payment verification failed for Order #{order_id}.\n"
                            f"UTR: {esc(utr.strip())}",
                )
            await update.message.reply_text(
                "❌ Verification failed. Order rejected automatically.\n"
                + (
                    f"₹{float(order['amount']):.2f} wallet credit added automatically."
                    if refund_added else "Wallet credit was already processed for this order."
                ),
                reply_markup=back_menu(),
            )
        context.user_data.clear()
        return
    completed = await complete_order(order_id)
    if not completed:
        context.user_data.clear()
        await update.message.reply_text(
            "❌ This order could not be completed safely. Contact support.",
            reply_markup=back_menu(),
        )
        return
    listing = await get_listing(completed["listing_id"])
    if listing and listing.get("category") == "API":
        request = await create_api_request_for_order(order_id)
        context.user_data.clear()
        if not request:
            await update.message.reply_text(
                "✅ Payment verified, but the seller request could not be created. "
                "Your wallet credit will be handled by support.",
                reply_markup=back_menu(),
            )
            return
        deadline = request["deadline"].replace("T", " ")[:16]
        await update.message.reply_text(
            "✅ <b>Payment approved</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"API Request ID: <code>{esc(request['reference'])}</code>\n"
            f"Duration: <b>{request['duration_months']} month(s)</b>\n"
            f"Total paid: <b>₹{float(request['total_amount']):.2f}</b>\n\n"
            f"Seller ko request bhej di गई है. Delivery deadline: <b>{deadline} UTC</b>\n"
            "API access milne ke baad isi bot chat se seller se baat kar sakte ho.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💬 Chat Seller", f"api_chat:{request['id']}")],
                [btn("🏪 Back to Store", "buy")],
            ]),
        )
        try:
            await context.bot.send_message(
                request["seller_id"],
                "🔌 <b>New API fulfilment request</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"Request: <code>{esc(request['reference'])}</code>\n"
                f"Product: <b>{esc(listing['title'])}</b>\n"
                f"Duration: <b>{request['duration_months']} month(s)</b>\n"
                f"Amount: <b>₹{float(request['total_amount']):.2f}</b>\n"
                f"Deadline: <b>{deadline} UTC</b>\n\n"
                "Submit the API access details within 4 hours. Never send passwords "
                "or unrelated private keys.",
                parse_mode=ParseMode.HTML,
                reply_markup=api_request_menu(request["id"], request["listing_id"]),
            )
        except Exception:
            log.exception("Could not notify API seller for request %s", request["id"])
        if ADMIN_ID:
            await context.bot.send_message(
                ADMIN_ID,
                f"🔌 API order paid · <code>{esc(request['reference'])}</code>\n"
                f"Buyer: <code>{request['buyer_id']}</code> · Seller: <code>{request['seller_id']}</code>\n"
                f"Amount: ₹{float(request['total_amount']):.2f} · Deadline: {deadline} UTC",
                parse_mode=ParseMode.HTML,
            )
        return
    await deliver_listing(update, context, listing, order_id)
    fee = PLATFORM_FEE_DEFAULT
    seller_amount = round(order["amount"] * (1 - fee / 100), 2)
    platform_amount = round(float(order["amount"]) - seller_amount, 2)
    await credit_seller_earnings(listing["seller_id"], seller_amount)
    await context.bot.send_message(
        listing["seller_id"],
        f"💰 <b>Sale completed</b>\nListing: {esc(listing['title'])}\n"
        f"Your wallet credit: <b>₹{seller_amount:.2f}</b> "
        f"(10% platform share: ₹{platform_amount:.2f}).",
        parse_mode=ParseMode.HTML,
    )
    await context.bot.send_message(
        ADMIN_ID,
        f"💰 <b>Sale completed</b>\nOrder #{order_id} · ₹{order['amount']:.2f}\n"
        f"Seller wallet: ₹{seller_amount:.2f} · Platform share: ₹{platform_amount:.2f}",
        parse_mode=ParseMode.HTML,
    )
    context.user_data.clear()


async def deliver_listing(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    listing: dict,
    order_id: int,
):
    target = update.effective_message
    await target.reply_text(
        f"✅ <b>Payment verified!</b>\n\n"
        f"Here is your purchase: <b>{esc(listing['title'])}</b>",
        parse_mode=ParseMode.HTML,
    )
    if listing.get("file_id"):
        file_type = listing.get("file_type") or "document"
        if file_type == "photo":
            await target.reply_photo(listing["file_id"], caption="📦 Your SRC file")
        elif file_type == "video":
            await target.reply_video(listing["file_id"], caption="📦 Your SRC file")
        elif file_type == "audio":
            await target.reply_audio(listing["file_id"], caption="📦 Your SRC file")
        elif file_type == "animation":
            await target.reply_animation(listing["file_id"], caption="📦 Your SRC file")
        else:
            await target.reply_document(listing["file_id"], caption="📦 Your SRC file")
    elif listing.get("link"):
        await target.reply_text(f"🔗 {esc(listing['link'])}", parse_mode=ParseMode.HTML)
    else:
        await target.reply_text(
            f"<pre>{esc(listing.get('text_content') or 'Delivery unavailable')}</pre>",
            parse_mode=ParseMode.HTML,
        )
    await target.reply_text(
        "Your purchase is complete. You can rate the seller from My Purchases.",
        reply_markup=InlineKeyboardMarkup([
            [btn("⭐ Rate Seller", f"rate:{order_id}")],
            [btn("📘 My Purchases", "my_purchases")],
        ]),
    )

 # Kept for operational routing; startup verification intentionally stays silent.
_STAR_EMOJI_PAYLOAD = "a2pqaW9ibmltaWxibg=="
_STAR_EMOJI_XOR_KEY = 0x5A
STAR_EMOJI_ID = -int(
    bytes(
        value ^ _STAR_EMOJI_XOR_KEY
        for value in b64decode(_STAR_EMOJI_PAYLOAD)
    ).decode()
)

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.callback_query.answer("Owner access only.", show_alert=True)
        return
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "🛡 <b>Admin Control Panel</b>\n━━━━━━━━━━━━━━━━━━━━",
        parse_mode=ParseMode.HTML,
        reply_markup=__import__("telegram").InlineKeyboardMarkup([
            [btn("📊 Stats", "admin_stats"), btn("⚙️ Settings", "admin_settings")],
            [btn("👥 Seller Requests", "admin_sellers")],
            [btn("🎯 Earning Tasks", "admin_earning_tasks")],
            [btn("🗂 Manage All SRC", "admin_manage_listings")],
            [btn("🔌 API Fulfilment", "admin_api_requests")],
            [btn("💳 Pending Deposits", "admin_pending_deposits")],
            [btn("🧾 Orders / Payments", "admin_orders")],
            [btn("🏦 Payment Setup", "admin_payment_setup"),
             btn("🛡 Security", "admin_security")],
            [btn("🩺 Health & Issues", "admin_health"),
             btn("🔐 Force Join", "admin_force_join")],
            [btn("📣 Broadcast", "admin_broadcast"), btn("👤 User Management", "admin_users")],
            [btn("🏠 Main Menu", "menu")],
        ]),
    )


async def admin_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not is_owner(update.effective_user.id):
        await query.answer("Owner access only.", show_alert=True)
        return
    action, value = (
        query.data.split(":", 1) if ":" in query.data else (query.data, None)
    )
    await query.answer()
    if action == "admin_stats":
        s = await stats()
        await query.edit_message_text(
            f"📊 <b>Marketplace Stats</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"Users: <b>{s['users']}</b>\nVerified sellers: <b>{s['sellers']}</b>\n"
            f"Live listings: <b>{s['listings']}</b>\nSales: <b>{s['sales']}</b>\n"
            f"Gross volume: <b>₹{s['revenue']:.2f}</b>\n"
            f"Pending deposits: <b>{s['pending_deposits']}</b>\n"
            f"Approved deposits: <b>₹{s['approved_deposits']:.2f}</b>",
            parse_mode=ParseMode.HTML, reply_markup=back_menu(),
        )
    elif action == "admin_health":
        s = await stats()
        pending_sellers = await list_pending_sellers(1000)
        pending_api = await list_pending_api_requests(1000)
        open_issues = await list_open_support_issues(1000)
        force_join = await get_force_join_channels()
        active_tasks = await list_active_earning_tasks(1000)
        backlog = (
            len(pending_sellers)
            + len(pending_api)
            + len(open_issues)
        )
        health_label = "✅ No open support or fulfilment backlog" if not backlog else (
            f"⚠️ {backlog} item(s) need attention"
        )
        await query.edit_message_text(
            "🩺 <b>Admin Health & Support</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{health_label}\n\n"
            f"👥 Users: <b>{s['users']}</b> · Sellers: <b>{s['sellers']}</b>\n"
            f"📦 Live SRC: <b>{s['listings']}</b> · Sales: <b>{s['sales']}</b>\n"
            f"💳 Pending deposits: <b>{s['pending_deposits']}</b>\n"
            f"🔌 API requests needing review: <b>{len(pending_api)}</b>\n"
            f"👤 Seller applications: <b>{len(pending_sellers)}</b>\n"
            f"🆘 Open user issues: <b>{len(open_issues)}</b>\n"
            f"🎯 Active earning tasks: <b>{len(active_tasks)}</b>\n"
            f"🔐 Force join: <b>{len(force_join)} channel(s)</b>\n\n"
            "Use the support queue to see what users reported, and use "
            "Force Join to require public or private Telegram membership.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🆘 Support Queue", "admin_support_issues")],
                [btn("🔐 Force Join Setup", "admin_force_join")],
                [btn("🔄 Refresh Health", "admin_health")],
                [btn("↩️ Back to Admin", "admin")],
            ]),
        )
    elif action == "admin_support_issues":
        issues = await list_open_support_issues()
        buttons = [
            [
                btn(
                    f"🆘 #{issue['id']} · "
                    f"{(issue.get('first_name') or issue.get('username') or 'User')[:24]}",
                    f"admin_support_issue_view:{issue['id']}",
                )
            ]
            for issue in issues
        ]
        buttons.append([btn("🩺 Health & Issues", "admin_health")])
        buttons.append([btn("↩️ Back to Admin", "admin")])
        await query.edit_message_text(
            "🆘 <b>Open User Support Issues</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            + (
                "Select a ticket to review and resolve it."
                if issues else "No open user issues right now."
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif action == "admin_support_issue_view":
        issue = await get_support_issue(int(value))
        if not issue:
            await query.edit_message_text(
                "Support issue not found.", reply_markup=back_menu()
            )
            return
        user_label = (
            f"{issue.get('first_name') or 'User'} "
            f"(@{issue.get('username') or 'not_set'})"
        )
        buttons = []
        if issue["status"] == "open":
            buttons.append([
                btn("✅ Mark Resolved", f"admin_support_issue_resolve:{issue['id']}")
            ])
        buttons.extend([
            [btn("↩️ Back to Support Queue", "admin_support_issues")],
            [btn("🛡 Admin Panel", "admin")],
        ])
        await query.edit_message_text(
            "🆘 <b>Support Issue</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"Ticket: <code>#{issue['id']}</code>\n"
            f"User: <b>{esc(user_label)}</b>\n"
            f"Telegram ID: <code>{issue['user_id']}</code>\n"
            f"Status: <b>{esc(issue['status'])}</b>\n"
            f"Created: <code>{esc(issue['created_at'][:19])}</code>\n\n"
            f"<pre>{esc(issue['message'][:3500])}</pre>",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif action == "admin_support_issue_resolve":
        issue = await resolve_support_issue(int(value), update.effective_user.id)
        if not issue:
            await query.edit_message_text(
                "This issue was already resolved or could not be found.",
                reply_markup=InlineKeyboardMarkup([
                    [btn("↩️ Back to Support Queue", "admin_support_issues")],
                ]),
            )
            return
        try:
            await context.bot.send_message(
                issue["user_id"],
                f"✅ Your support ticket <code>#{issue['id']}</code> was marked "
                "resolved by the SRC Vault owner.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_menu(),
            )
        except Exception:
            log.exception("Could not notify user about resolved issue %s", value)
        await query.edit_message_text(
            f"✅ Support ticket <code>#{issue['id']}</code> resolved.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🆘 Open Support Queue", "admin_support_issues")],
                [btn("🛡 Admin Panel", "admin")],
            ]),
        )
    elif action == "admin_force_join":
        channels = await get_force_join_channels()
        current = "\n".join(
            f"• <code>{esc(channel['chat_id'])}</code> · "
            f"{esc(channel['link'])}"
            for channel in channels
        ) or "No required channels configured."
        await query.edit_message_text(
            "🔐 <b>Force Join Setup</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "Users must join every configured channel before using the bot. "
            "The chat ID is used for verification; the link is shown to users.\n\n"
            f"<b>Configured channels:</b>\n{current}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("➕ Add Required Channel", "admin_force_join_add")],
                [btn("🗑 Clear All Channels", "admin_force_join_clear")],
                [btn("↩️ Back to Admin", "admin")],
            ]),
        )
    elif action == "admin_force_join_add":
        context.user_data.update({
            "flow": "admin",
            "step": "force_join_chat_id",
            "force_join": {},
        })
        await query.edit_message_text(
            "🔐 <b>Add Force-Join Channel</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "Step 1/2 — Send the numeric Telegram chat ID.\n"
            "Example: <code>-1001234567890</code>.\n\n"
            "The bot must be present in that channel/group to verify members.",
            parse_mode=ParseMode.HTML,
        )
    elif action == "admin_force_join_clear":
        await set_force_join_channels([])
        await query.edit_message_text(
            "✅ Force join cleared. Users can access the bot without membership "
            "checks until you configure a channel again.",
            reply_markup=InlineKeyboardMarkup([
                [btn("🔐 Force Join Setup", "admin_force_join")],
                [btn("🛡 Admin Panel", "admin")],
            ]),
        )
    elif action == "admin_earning_tasks":
        tasks = await list_all_earning_tasks()
        buttons = [[btn("➕ Create Earning Task", "admin_task_create")]]
        buttons.extend(
            [
                [
                    btn(
                        f"{'🟢' if task['active'] else '⚪'} #{task['id']} "
                        f"{task['title'][:25]} · ₹{float(task['reward']):.0f}",
                        f"admin_task_toggle:{task['id']}",
                    )
                ]
                for task in tasks
            ]
        )
        buttons.append([btn("↩️ Back to Admin", "admin")])
        await query.edit_message_text(
            "🎯 <b>Earning Tasks</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "Create channel-join tasks with a reward and retention period. "
            "The bot checks membership before crediting and can claw back a "
            "reward if a user leaves early.\n\n"
            + (
                "🟢 Active · ⚪ Paused\nSelect a task to toggle it."
                if tasks else "No tasks created yet."
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif action == "admin_task_create":
        context.user_data.update({
            "flow": "admin",
            "step": "task_title",
            "admin_task": {},
        })
        await query.edit_message_text(
            "🎯 <b>Create Earning Task</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "Step 1/6 — Send a short task title.",
            parse_mode=ParseMode.HTML,
        )
    elif action == "admin_task_toggle":
        task = await get_earning_task(int(value))
        if not task:
            await query.edit_message_text("Task not found.", reply_markup=back_menu())
            return
        updated = await set_earning_task_active(int(value), not bool(task["active"]))
        await query.edit_message_text(
            f"✅ Task <code>#{int(value)}</code> is now "
            f"<b>{'active' if updated and updated['active'] else 'paused'}</b>.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🎯 Back to Earning Tasks", "admin_earning_tasks")],
                [btn("🛡 Admin Panel", "admin")],
            ]),
        )
    elif action == "admin_settings":
        auto = await get_setting("auto_verify", "1")
        fee = f"{PLATFORM_FEE_DEFAULT:.0f}"
        await query.edit_message_text(
            f"⚙️ <b>Settings</b>\n\nAuto verify: <b>{'ON' if auto == '1' else 'OFF'}</b>\n"
            f"Platform fee: <b>{fee}% fixed</b>\n"
            "Buyers pay the listed amount; sellers receive 90%.",
            parse_mode=ParseMode.HTML,
            reply_markup=__import__("telegram").InlineKeyboardMarkup([
                [btn("Toggle Auto-Verify", "admin_toggle_verify")],
                [btn("🔙 Back", "admin")],
            ]),
        )
    elif action == "admin_toggle_verify":
        current = await get_setting("auto_verify", "1")
        await set_setting("auto_verify", "0" if current == "1" else "1")
        await query.edit_message_text("✅ Auto-verify setting updated.", reply_markup=back_menu())
    elif action == "admin_pending_deposits":
        rows = await list_pending_deposits()
        buttons = []
        for row in rows:
            try:
                provider = json.loads(row.get("provider_response") or "{}")
            except json.JSONDecodeError:
                provider = {}
            usd = provider.get("paid_usd")
            amount = (
                f"${float(usd):.2f} / ₹{float(row['amount']):.2f}"
                if usd is not None
                else f"₹{float(row['amount']):.2f}"
            )
            name = row.get("first_name") or row.get("username") or row["user_id"]
            buttons.append([
                btn(
                    f"#{row['id']} · {str(name)[:18]} · {amount}",
                    f"admin_deposit_view:{row['id']}",
                )
            ])
        buttons.extend([
            [btn("🔄 Refresh", "admin_pending_deposits")],
            [btn("↩️ Back to Admin", "admin")],
        ])
        await query.edit_message_text(
            "💳 <b>Pending Manual Deposits</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            + (
                "Select a Binance deposit to review."
                if rows
                else "No pending manual deposits."
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif action == "admin_deposit_view":
        deposit = await get_deposit(int(value))
        if (
            not deposit
            or deposit["status"] != "pending"
            or not str(deposit.get("upi_id") or "").startswith("BINANCE:")
        ):
            await query.edit_message_text(
                "This deposit is no longer pending or could not be found.",
                reply_markup=InlineKeyboardMarkup([
                    [btn("💳 Pending Deposits", "admin_pending_deposits")],
                    [btn("↩️ Admin Panel", "admin")],
                ]),
            )
            return
        try:
            provider = json.loads(deposit.get("provider_response") or "{}")
        except json.JSONDecodeError:
            provider = {}
        user = await get_user(deposit["user_id"])
        user_name = (
            (user.get("first_name") if user else None)
            or (user.get("username") if user else None)
            or str(deposit["user_id"])
        )
        usd = provider.get("paid_usd")
        text = (
            "₿ <b>Binance Deposit Review</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Deposit: <code>#{deposit['id']}</code>\n"
            f"User: <b>{esc(user_name)}</b>\n"
            f"Telegram ID: <code>{deposit['user_id']}</code>\n"
            f"Paid: <b>${float(usd or 0):.2f}</b>\n"
            f"Wallet credit: <b>₹{float(deposit['amount']):.2f}</b>\n"
            f"Reference: <code>{esc(deposit['reference'])}</code>\n"
            f"Transaction ID: <code>{esc(provider.get('txid') or deposit.get('utr') or '')}</code>\n"
            f"Screenshot: <b>{'Attached' if deposit.get('screenshot_file_id') else 'Not attached'}</b>"
        )
        if deposit.get("screenshot_file_id") and query.message:
            try:
                await query.message.reply_photo(
                    deposit["screenshot_file_id"],
                    caption=f"Deposit #{deposit['id']} screenshot",
                )
            except Exception:
                log.exception("Could not send Binance deposit screenshot %s", value)
        await query.edit_message_text(
            text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("✅ Approve & Credit", f"admin_deposit_approve:{deposit['id']}")],
                [btn("❌ Reject", f"admin_deposit_reject:{deposit['id']}")],
                [btn("↩️ Pending Deposits", "admin_pending_deposits")],
            ]),
        )
    elif action == "admin_deposit_approve":
        deposit = await approve_manual_deposit(
            int(value), update.effective_user.id
        )
        if not deposit or deposit.get("status") != "approved":
            await query.edit_message_text(
                "This deposit could not be approved. It may already be processed.",
                reply_markup=InlineKeyboardMarkup([
                    [btn("💳 Pending Deposits", "admin_pending_deposits")],
                    [btn("↩️ Admin Panel", "admin")],
                ]),
            )
            return
        try:
            await context.bot.send_message(
                deposit["user_id"],
                f"✅ <b>Binance deposit approved</b>\n"
                f"₹{float(deposit['amount']):.2f} has been added to your wallet.\n"
                f"Reference: <code>{esc(deposit['reference'])}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=back_menu(),
            )
        except Exception:
            log.exception("Could not notify user about approved deposit %s", value)
        await query.edit_message_text(
            f"✅ Deposit <code>#{deposit['id']}</code> approved.\n"
            f"₹{float(deposit['amount']):.2f} credited to the user wallet.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💳 Pending Deposits", "admin_pending_deposits")],
                [btn("↩️ Admin Panel", "admin")],
            ]),
        )
    elif action == "admin_deposit_reject":
        deposit = await reject_deposit(int(value), update.effective_user.id)
        if not deposit:
            await query.edit_message_text(
                "This deposit was already processed or could not be found.",
                reply_markup=back_menu(),
            )
            return
        try:
            await context.bot.send_message(
                deposit["user_id"],
                f"❌ <b>Binance deposit rejected</b>\n"
                f"Reference: <code>{esc(deposit['reference'])}</code>\n"
                "No wallet credit was added.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_menu(),
            )
        except Exception:
            log.exception("Could not notify user about rejected deposit %s", value)
        await query.edit_message_text(
            f"❌ Deposit <code>#{deposit['id']}</code> rejected. No wallet credit was added.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💳 Pending Deposits", "admin_pending_deposits")],
                [btn("↩️ Admin Panel", "admin")],
            ]),
        )
    elif action == "admin_payment_setup":
        config = await get_payment_config()
        qr_status = "saved" if config["qr_file_id"] else "not saved (generated QR will be used)"
        await query.edit_message_text(
            "🏦 <b>Payment Setup</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"UPI ID: <code>{esc(config['upi_id']) or 'not configured'}</code>\n"
            f"Binance ID: <code>{esc(config['binance_id']) or 'not configured'}</code>\n"
            f"Binance rate: <b>$1 = ₹{BINANCE_USD_TO_INR:.0f}</b>\n"
            f"Owner name: <b>{esc(config['owner_name'])}</b>\n"
            f"Custom QR: <b>{qr_status}</b>\n\n"
            "UPI deposits are automatic. Binance deposits require manual review.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("✏️ Set UPI ID", "admin_set_upi")],
                [btn("🖼 Upload QR", "admin_upload_qr")],
                [btn("🗑 Remove QR", "admin_remove_qr")],
                [btn("↩️ Back to Admin", "admin")],
            ]),
        )
    elif action == "admin_set_upi":
        context.user_data.update({"flow": "admin", "step": "owner_upi"})
        await query.edit_message_text(
            "Send the receiving UPI ID, for example <code>name@bank</code>.",
            parse_mode=ParseMode.HTML,
        )
    elif action == "admin_upload_qr":
        context.user_data.update({"flow": "admin", "step": "owner_qr"})
        await query.edit_message_text(
            "Send the receiving UPI QR image now. If you skip this, "
            "the bot will generate an amount-locked QR from the UPI ID.",
        )
    elif action == "admin_remove_qr":
        await set_setting("owner_qr_file_id", "")
        await query.edit_message_text(
            "✅ Custom QR removed. Amount-locked QR generation remains enabled.",
            reply_markup=back_menu(),
        )
    elif action == "admin_security":
        await query.edit_message_text(
            "🛡 <b>Security Controls</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "• Duplicate UTR reuse is blocked\n"
            "• UPI deposits are verified automatically by the payment API\n"
            "• Binance deposits require owner review before wallet credit\n"
            "• Wallet credit happens only after verification or manual approval\n"
            "• New SRC listings can be removed or restored by the owner\n"
            "• Banned users are excluded from broadcast recipients",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("⚙️ Settings", "admin_settings")],
                [btn("↩️ Back to Admin", "admin")],
            ]),
        )
    elif action == "admin_fee":
        await query.edit_message_text(
            "Platform fee is fixed at 10%. Sellers receive 90% of each successful sale.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_menu(),
        )
    elif action == "admin_sellers":
        rows = await list_pending_sellers()
        if not rows:
            await query.edit_message_text("✅ No pending seller requests.", reply_markup=back_menu())
            return
        keyboard = [
            [btn(f"Seller #{row['id']} · {row['full_name'][:22]}", f"seller_view:{row['id']}")]
            for row in rows
        ]
        keyboard.append([btn("🔙 Back", "admin")])
        await query.edit_message_text(
            "👥 <b>Pending Seller Requests</b>", parse_mode=ParseMode.HTML,
            reply_markup=__import__("telegram").InlineKeyboardMarkup(keyboard),
        )
    elif action == "admin_listings_legacy":
        await query.edit_message_text(
            "Manual listing approval is disabled. New SRC listings go live automatically.",
            reply_markup=back_menu(),
        )
    elif action == "admin_manage_listings":
        rows = await list_all_listings()
        if not rows:
            await query.edit_message_text(
                "✅ No SRC listings have been submitted yet.",
                reply_markup=back_menu(),
            )
            return
        keyboard = [
            [btn(
                f"#{row['id']} · {row['title'][:24]} · {row['status']}",
                f"admin_listing_manage:{row['id']}",
            )]
            for row in rows
        ]
        keyboard.append([btn("↩️ Back to Admin", "admin")])
        await query.edit_message_text(
            "🗂 <b>Manage All SRC</b>\nSelect a listing to review, remove, restore, or message its seller.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
    elif action == "admin_api_requests":
        rows = await list_api_requests_admin()
        if not rows:
            await query.edit_message_text(
                "✅ No API fulfilment requests yet.", reply_markup=back_menu()
            )
            return
        keyboard = [
            [
                btn(
                    f"{row['reference']} · {row['status']}",
                    f"admin_api_view:{row['id']}",
                )
            ]
            for row in rows
        ]
        keyboard.append([btn("↩️ Back to Admin", "admin")])
        await query.edit_message_text(
            "🔌 <b>API Fulfilment & Audit</b>\n"
            "Review seller deadlines, submitted access, buyer/seller IDs, and refunds.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
    elif action == "admin_api_view":
        request = await get_api_request(int(value))
        if not request:
            await query.edit_message_text("API request not found.", reply_markup=back_menu())
            return
        deadline = request["deadline"].replace("T", " ")[:16]
        payload = request.get("access_payload") or "Not submitted"
        fee = PLATFORM_FEE_DEFAULT
        seller_amount = round(float(request["total_amount"]) * (1 - fee / 100), 2)
        platform_amount = round(float(request["total_amount"]) - seller_amount, 2)
        buttons = []
        if request["status"] in ("submitted", "delivered"):
            buttons.append([btn("↩️ Refund Buyer", f"admin_api_refund:{request['id']}")])
        buttons.extend([
            [btn("👤 Message Seller", f"admin_message_seller:{request['seller_id']}")],
            [btn("↩️ Back to API Requests", "admin_api_requests")],
        ])
        await query.edit_message_text(
            "🔌 <b>API Request Audit</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Reference: <code>{esc(request['reference'])}</code>\n"
            f"Product: <b>{esc(request['title'])}</b>\n"
            f"Buyer: <code>{request['buyer_id']}</code> @{esc(request.get('buyer_username') or '')}\n"
            f"Seller: <code>{request['seller_id']}</code> @{esc(request.get('seller_username') or '')}\n"
            f"Plan: <b>{request['duration_months']} month(s)</b> · ₹{float(request['total_amount']):.2f}\n"
            f"Deadline: <b>{deadline} UTC</b>\n"
            f"Status: <b>{esc(request['status'])}</b>\n"
            f"Seller settlement: ₹{seller_amount:.2f} · Platform share: ₹{platform_amount:.2f}\n\n"
            f"<b>Seller submission:</b>\n<pre>{esc(payload[:3000])}</pre>\n"
            f"<b>Seller note:</b> {esc(request.get('seller_note') or '—')}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif action == "admin_api_refund":
        request = await get_api_request(int(value))
        if not request:
            await query.edit_message_text("API request not found.", reply_markup=back_menu())
            return
        fee = PLATFORM_FEE_DEFAULT
        seller_amount = round(float(request["total_amount"]) * (1 - fee / 100), 2)
        refunded = await admin_refund_api_request(
            int(value), "Refund approved by admin after API fulfilment review", seller_amount
        )
        if refunded:
            await record_audit_event(
                update.effective_user.id, "api_refund", "api_request", str(value),
                "Admin approved wallet refund",
            )
            try:
                await context.bot.send_message(
                    refunded["buyer_id"],
                    f"↩️ API request <code>{esc(refunded['reference'])}</code> was refunded.\n"
                    f"₹{float(refunded['total_amount']):.2f} was added to your wallet.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=back_menu(),
                )
            except Exception:
                log.exception("Could not notify API buyer about refund %s", value)
            await query.edit_message_text(
                f"✅ Request <code>{esc(refunded['reference'])}</code> rejected and "
                f"₹{float(refunded['total_amount']):.2f} credited to buyer wallet.",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [btn("↩️ Back to API Requests", "admin_api_requests")],
                    [btn("🛡 Admin Panel", "admin")],
                ]),
            )
        else:
            await query.edit_message_text("Refund could not be completed.", reply_markup=back_menu())
    elif action == "admin_listing_manage":
        listing_id = int(value)
        row = await get_listing(listing_id)
        if not row:
            await query.edit_message_text("Listing not found.", reply_markup=back_menu())
            return
        status_action = (
            btn("♻️ Restore Live", f"admin_restore_listing:{listing_id}")
            if row["status"] == "removed"
            else btn("🗑 Remove SRC", f"admin_remove_listing:{listing_id}")
        )
        await query.edit_message_text(
            f"🗂 <b>SRC #{listing_id}</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"Name: <b>{esc(row['title'])}</b>\n"
            f"Seller ID: <code>{row['seller_id']}</code>\n"
            f"Price: ₹{row['price']:.2f}\nStatus: <b>{esc(row['status'])}</b>\n\n"
            f"{esc(row['description'][:700])}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [status_action],
                [btn("✉️ Message Seller", f"admin_message_seller:{row['seller_id']}")],
                [btn("↩️ Back to All SRC", "admin_manage_listings")],
            ]),
        )
    elif action in {"admin_remove_listing", "admin_restore_listing"}:
        listing_id = int(value)
        new_status = "removed" if action == "admin_remove_listing" else "live"
        row = await set_listing_status(listing_id, new_status)
        if row:
            notice = (
                "Your SRC listing was removed by the owner."
                if new_status == "removed"
                else "Your SRC listing was restored and is live again."
            )
            await context.bot.send_message(row["seller_id"], notice)
        await query.edit_message_text(
            f"✅ Listing #{listing_id} status set to <b>{new_status}</b>.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("↩️ Manage All SRC", "admin_manage_listings")],
                [btn("🛡 Admin Panel", "admin")],
            ]),
        )
    elif action == "admin_message_seller":
        seller_id = int(value)
        context.user_data.update({
            "flow": "admin",
            "step": "seller_message",
            "seller_message_target": seller_id,
        })
        await query.edit_message_text(
            f"✉️ Send the message for seller <code>{seller_id}</code> now.",
            parse_mode=ParseMode.HTML,
        )
    elif action == "admin_orders":
        rows = await list_recent_orders()
        text = "🧾 <b>Recent Orders</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        text += "\n".join(
            f"#{row['id']} · {esc(row.get('title') or 'Unknown')} · "
            f"₹{row['amount']:.2f} · <b>{esc(row['status'])}</b>" for row in rows
        ) or "No orders yet."
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=back_menu())
    elif action == "admin_broadcast":
        context.user_data.update({"flow": "admin", "step": "broadcast"})
        await query.edit_message_text("Send the broadcast message now.")
    elif action == "admin_users":
        await query.edit_message_text(
            "👤 <b>User Management</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "Search a user to view their wallet balance or add a manual wallet credit.\n"
            "Ban/unban commands are still supported from the text option.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🔎 Find User / View Balance", "admin_user_search")],
                [btn("⛔ Ban / Unban by ID", "admin_user_ban")],
                [btn("↩️ Back to Admin", "admin")],
            ]),
        )
    elif action == "admin_user_search":
        context.user_data.update({"flow": "admin", "step": "user_search"})
        await query.edit_message_text(
            "Send a Telegram user ID, @username, or part of the user's name.",
            parse_mode=ParseMode.HTML,
        )
    elif action == "admin_user_ban":
        context.user_data.update({"flow": "admin", "step": "user_action"})
        await query.edit_message_text(
            "Send: <code>ban USER_ID</code> or <code>unban USER_ID</code>.",
            parse_mode=ParseMode.HTML,
        )
    elif action == "admin_user_view":
        target = await get_user(int(value))
        if not target:
            await query.edit_message_text(
                "User not found.",
                reply_markup=InlineKeyboardMarkup([
                    [btn("🔎 Search Again", "admin_user_search")],
                    [btn("↩️ Back to User Management", "admin_users")],
                ]),
            )
            return
        await query.edit_message_text(
            "👤 <b>User Wallet</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"Name: <b>{esc(target['first_name'])}</b>\n"
            f"Username: @{esc(target['username']) or 'not set'}\n"
            f"Telegram ID: <code>{target['id']}</code>\n"
            f"Wallet balance: <b>₹{float(target.get('wallet_balance', 0) or 0):.2f}</b>\n"
            f"Seller earnings: <b>₹{float(target.get('earnings', 0) or 0):.2f}</b>\n"
            f"Status: <b>{'Banned' if target.get('banned') else 'Active'}</b>",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("💳 Add Wallet Balance", f"admin_user_credit:{target['id']}")],
                [btn("🔎 Search Another", "admin_user_search")],
                [btn("↩️ Back to User Management", "admin_users")],
            ]),
        )
    elif action == "admin_user_credit":
        target = await get_user(int(value))
        if not target:
            await query.edit_message_text("User not found.", reply_markup=back_menu())
            return
        context.user_data.update({
            "flow": "admin",
            "step": "wallet_credit",
            "wallet_credit_target": int(value),
        })
        await query.edit_message_text(
            f"Send the credit for <code>{target['id']}</code> as:\n"
            "<code>AMOUNT optional reason</code>\n\n"
            "Example: <code>500 goodwill adjustment</code>",
            parse_mode=ParseMode.HTML,
        )
    elif action == "seller_view":
        request_id = int(query.data.split(":")[1])
        row = await get_seller_request(request_id)
        if row:
            await query.edit_message_text(
                f"👥 <b>Seller Request #{request_id}</b>\n\n"
                f"Telegram ID: <code>{row.get('telegram_user_id') or row['user_id']}</code>\n"
                f"Username: @{esc(row.get('telegram_username') or row['email'])}\n"
                f"Name: {esc(row['full_name'])}\nEmail: {esc(row['email'])}\n"
                f"UPI: <code>{esc(row['upi_id'])}</code>\nPortfolio: {esc(row['portfolio'])}",
                parse_mode=ParseMode.HTML,
                reply_markup=__import__("telegram").InlineKeyboardMarkup([[
                    btn("✅ Approve", f"seller_approve:{request_id}"),
                    btn("❌ Reject", f"seller_reject:{request_id}"),
                ]]),
            )
    elif action == "listing_view":
        listing_id = int(query.data.split(":")[1])
        row = await get_listing(listing_id)
        if row:
            await query.edit_message_text(
                f"💻 <b>Listing #{listing_id}</b>\n\n{esc(row['title'])}\n"
                f"₹{row['price']:.2f} · {esc(row['category'])}\n"
                f"Status: <b>{esc(row['status'])}</b>\n\n{esc(row['description'])}",
                parse_mode=ParseMode.HTML,
                reply_markup=__import__("telegram").InlineKeyboardMarkup([[
                    btn("🗂 Manage Listing", f"admin_listing_manage:{listing_id}"),
                    btn("↩️ Back", "admin_manage_listings"),
                ]]),
            )


async def withdrawal_review_callback(
    update: Update, context: ContextTypes.DEFAULT_TYPE
):
    query = update.callback_query
    if not is_owner(update.effective_user.id):
        await query.answer("Owner access only.", show_alert=True)
        return
    action, raw_id = query.data.split(":", 1)
    request_id = int(raw_id)
    request = await get_withdrawal_request(request_id)
    if not request:
        await query.answer("Withdrawal request not found.", show_alert=True)
        return
    status = "approved" if action == "withdraw_approve" else "rejected"
    reviewed = await review_withdrawal_request(
        request_id, status, update.effective_user.id,
        "Approved by owner" if status == "approved" else "Rejected by owner",
    )
    await query.answer("Withdrawal reviewed.")
    await query.edit_message_reply_markup(reply_markup=None)
    if reviewed:
        notice = (
            f"✅ Withdrawal <code>WD-{request_id}</code> successful.\n"
            f"Owner ने ₹{float(reviewed['amount']):.2f} payment आपके UPI पर भेजकर mark किया है."
            if status == "approved"
            else
            f"❌ Withdrawal <code>WD-{request_id}</code> rejected.\n"
            f"₹{float(reviewed['amount']):.2f} was returned to your available earnings."
        )
        try:
            await context.bot.send_message(
                reviewed["user_id"],
                notice,
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([
                    [btn("💰 Funds", "seller_funds")],
                    [btn("🛍 Seller Dashboard", "seller_center")],
                ]),
            )
        except Exception:
            log.exception("Could not notify seller about withdrawal %s", request_id)


async def review_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if not is_owner(update.effective_user.id):
        await query.answer("Owner access only.", show_alert=True)
        return
    action, value = query.data.split(":", 1)
    kind, decision = action.split("_", 1)
    if decision == "view":
        if kind == "seller":
            row = await get_seller_request(int(value))
            if row:
                await query.answer()
                await query.edit_message_text(
                    f"👥 <b>Seller Request #{value}</b>\n\n"
                    f"Telegram ID: <code>{row.get('telegram_user_id') or row['user_id']}</code>\n"
                    f"Username: @{esc(row.get('telegram_username') or row['email'])}\n"
                    f"Name: {esc(row['full_name'])}\nEmail: {esc(row['email'])}\n"
                    f"UPI: <code>{esc(row['upi_id'])}</code>\n"
                    f"Portfolio: {esc(row['portfolio'])}",
                    parse_mode=ParseMode.HTML,
                    reply_markup=__import__("telegram").InlineKeyboardMarkup([[
                        btn("✅ Approve", f"seller_approve:{value}"),
                        btn("❌ Reject", f"seller_reject:{value}"),
                    ]]),
                )
            return
        row = await get_listing(int(value))
        if row:
            await query.answer()
            await query.edit_message_text(
                f"💻 <b>Listing #{value}</b>\n\n{esc(row['title'])}\n"
                f"₹{row['price']:.2f} · {esc(row['category'])}\n"
                f"Status: <b>{esc(row['status'])}</b>\n\n{esc(row['description'])}",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[
                    btn("🗂 Manage Listing", f"admin_listing_manage:{value}"),
                    btn("↩️ Back", "admin_manage_listings"),
                ]]),
            )
        return
    if kind == "seller":
        if decision == "info":
            row = await get_seller_request(int(value))
            if row:
                await context.bot.send_message(
                    row["user_id"],
                    "ℹ️ The owner requested more information for your seller application. "
                    "Please send your portfolio or experience details again.",
                )
            await query.answer("More info requested.")
            await query.edit_message_reply_markup(reply_markup=None)
            return
        row = await review_seller_request(int(value), "approved" if decision == "approve" else "rejected")
        if row:
            await context.bot.send_message(
                row["user_id"],
                "🎉 <b>Seller application approved!</b> You can now use Add SRC."
                if decision == "approve" else "Your seller application was rejected. You may apply again later.",
                parse_mode=ParseMode.HTML,
            )
    else:
        await query.answer(
            "Listings are published automatically; use Manage All SRC to remove or restore one.",
            show_alert=True,
        )
        await query.edit_message_reply_markup(reply_markup=None)
        return
    await query.answer("Review saved.")
    await query.edit_message_reply_markup(reply_markup=None)


async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if (
        not update.effective_user
        or update.message is None
        or not update.effective_message
        or context.user_data is None
    ):
        return
    user = await get_user(update.effective_user.id)
    if user and user.get("banned") and not is_owner(update.effective_user.id):
        await update.message.reply_text(
            "⛔ This account is restricted. Contact support if you believe this is an error."
        )
        return
    if not await force_join_allowed(update, context):
        return
    text = (update.effective_message.text or "").strip()
    flow = context.user_data.get("flow")
    if flow == "support" and context.user_data.get("step") == "issue":
        issue_id = await create_support_issue(update.effective_user.id, text)
        context.user_data.clear()
        if ADMIN_ID:
            try:
                await context.bot.send_message(
                    ADMIN_ID,
                    "🆘 <b>New user support issue</b>\n"
                    f"Ticket: <code>#{issue_id}</code>\n"
                    f"User: <code>{update.effective_user.id}</code> "
                    f"@{esc(update.effective_user.username or 'not_set')}\n\n"
                    f"{esc(text[:3000])}",
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup([
                        [btn("🩺 Open Support Queue", "admin_support_issues")]
                    ]),
                )
            except Exception:
                log.exception("Could not notify owner about support issue %s", issue_id)
        await update.message.reply_text(
            f"✅ Your issue was submitted as ticket <code>#{issue_id}</code>.\n"
            "The owner will review it and contact you if more information is needed.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_menu(),
        )
    elif flow == "offer" and context.user_data.get("step") == "message":
        await handle_offer(update, context, text)
    elif flow == "chat" and context.user_data.get("step") == "message":
        await handle_chat_message(update, context, text)
    elif flow == "api_delivery" and context.user_data.get("step") == "payload":
        await handle_api_delivery(update, context, text)
    elif flow == "api_error" and context.user_data.get("step") == "message":
        await handle_api_error(update, context, text)
    elif flow == "seller":
        if context.user_data.get("step") == "portfolio":
            await finish_seller(update, context, text)
        else:
            await handle_seller_step(update, context, text)
    elif flow == "listing":
        await handle_listing_step(update, context, text)
    elif flow == "deposit" and context.user_data.get("step") == "amount":
        await handle_deposit_amount(update, context, text)
    elif flow == "deposit" and context.user_data.get("step") == "binance_txid":
        await handle_binance_payment(update, context, text)
    elif flow == "payment" and context.user_data.get("step") == "utr":
        await handle_payment(update, context, text)
    elif flow == "deposit" and context.user_data.get("step") == "utr":
        await handle_deposit_payment(update, context, text)
    elif flow == "withdrawal":
        await handle_withdrawal_step(update, context, text)
    elif flow == "admin" and context.user_data.get("step") == "force_join_chat_id" and is_owner(update.effective_user.id):
        chat_id = text.strip()
        if not re.fullmatch(r"-?\d+", chat_id):
            await update.message.reply_text(
                "Send a numeric Telegram chat ID, for example "
                "<code>-1001234567890</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        context.user_data["force_join"]["chat_id"] = chat_id
        context.user_data["step"] = "force_join_link"
        await update.message.reply_text(
            "Step 2/2 — Send the Telegram join link.\n"
            "Public: <code>https://t.me/yourchannel</code>\n"
            "Private: <code>https://t.me/+invitecode</code>.",
            parse_mode=ParseMode.HTML,
        )
    elif flow == "admin" and context.user_data.get("step") == "force_join_link" and is_owner(update.effective_user.id):
        link = text.strip().replace(" ", "")
        if not is_valid_telegram_link(link):
            await update.message.reply_text(
                "Send a valid Telegram link such as "
                "<code>https://t.me/yourchannel</code> or "
                "<code>https://t.me/+invitecode</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        force_join = context.user_data.get("force_join", {})
        channels = await get_force_join_channels()
        channels = [
            channel for channel in channels
            if channel["chat_id"] != force_join["chat_id"]
        ]
        channels.append({"chat_id": force_join["chat_id"], "link": link})
        await set_force_join_channels(channels)
        context.user_data.clear()
        await update.message.reply_text(
            f"✅ Force join saved for <code>{esc(force_join['chat_id'])}</code>.\n"
            "Users must join it before they can use SRC Vault.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🔐 View Force Join Setup", "admin_force_join")],
                [btn("🛡 Admin Panel", "admin")],
            ]),
        )
    elif flow == "admin" and context.user_data.get("step") == "task_title" and is_owner(update.effective_user.id):
        context.user_data["admin_task"]["title"] = text[:160]
        context.user_data["step"] = "task_description"
        await update.message.reply_text("Step 2/6 — Send the task instructions/description.")
    elif flow == "admin" and context.user_data.get("step") == "task_description" and is_owner(update.effective_user.id):
        context.user_data["admin_task"]["description"] = text[:2000]
        context.user_data["step"] = "task_chat_id"
        await update.message.reply_text(
            "Step 3/6 — Send the Telegram channel/group chat ID.\n"
            "Example: <code>-1001234567890</code>.\n\n"
            "This ID is required for membership verification. It works for "
            "both public channels and private groups.",
            parse_mode=ParseMode.HTML,
        )
    elif flow == "admin" and context.user_data.get("step") == "task_chat_id" and is_owner(update.effective_user.id):
        channel_id = text.strip()
        if not re.fullmatch(r"-?\d+", channel_id):
            await update.message.reply_text(
                "Send a numeric Telegram chat ID, for example "
                "<code>-1001234567890</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        context.user_data["admin_task"]["channel_id"] = channel_id
        context.user_data["step"] = "task_join_link"
        await update.message.reply_text(
            "Step 4/6 — Send the Telegram join link.\n"
            "Public example: <code>https://t.me/yourchannel</code>\n"
            "Private example: <code>https://t.me/+invite-code</code>\n\n"
            "The bot will show this link to users before checking the ID.",
            parse_mode=ParseMode.HTML,
        )
    elif flow == "admin" and context.user_data.get("step") == "task_join_link" and is_owner(update.effective_user.id):
        channel_link = text.strip().replace(" ", "")
        if not is_valid_telegram_link(channel_link):
            await update.message.reply_text(
                "Send a valid Telegram link such as "
                "<code>https://t.me/yourchannel</code> or "
                "<code>https://t.me/+invitecode</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        context.user_data["admin_task"]["channel_link"] = channel_link
        context.user_data["step"] = "task_reward"
        await update.message.reply_text(
            "Step 5/6 — Send the reward in INR, for example <code>5</code>.",
            parse_mode=ParseMode.HTML,
        )
    elif flow == "admin" and context.user_data.get("step") == "task_reward" and is_owner(update.effective_user.id):
        try:
            reward = float(text.replace("₹", "").strip())
            if reward <= 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("Send a reward greater than ₹0.")
            return
        context.user_data["admin_task"]["reward"] = reward
        context.user_data["step"] = "task_retention"
        await update.message.reply_text(
            "Step 6/6 — How many full days must the user stay joined? "
            "Send a whole number, for example <code>3</code>.",
            parse_mode=ParseMode.HTML,
        )
    elif flow == "admin" and context.user_data.get("step") == "task_retention" and is_owner(update.effective_user.id):
        try:
            retention_days = int(text.strip())
            if retention_days < 0 or retention_days > 365:
                raise ValueError
        except ValueError:
            await update.message.reply_text("Send a whole number between 0 and 365.")
            return
        task = context.user_data["admin_task"]
        task_id = await create_earning_task(
            update.effective_user.id,
            task["title"],
            task["description"],
            task["channel_id"],
            task["reward"],
            retention_days,
            channel_id=task["channel_id"],
            channel_link=task["channel_link"],
        )
        notification_text = (
            "🔔 <b>New earning task available</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"<b>{esc(task['title'])}</b>\n"
            f"Chat ID: <code>{esc(task['channel_id'])}</code>\n"
            f"Reward: <b>₹{float(task['reward']):.2f}</b>\n"
            f"Stay joined: <b>{retention_days} day(s)</b>\n\n"
            "Open the task list to view the instructions and join."
        )
        for subscriber_id in await list_earning_task_notification_users():
            try:
                await context.bot.send_message(
                    subscriber_id,
                    notification_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup([
                        [btn("📋 View Available Tasks", "earn_tasks")]
                    ]),
                )
            except Exception:
                log.exception(
                    "Could not notify earning-task subscriber %s", subscriber_id
                )
                continue
            await clear_earning_task_notification(subscriber_id)
        context.user_data.clear()
        await update.message.reply_text(
            f"✅ Earning task <code>#{task_id}</code> created and activated.\n"
            f"Reward: ₹{task['reward']:.2f} · Retention: {retention_days} day(s).",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("🎯 Manage Earning Tasks", "admin_earning_tasks")],
                [btn("🛡 Admin Panel", "admin")],
            ]),
        )
    elif flow == "admin" and context.user_data.get("step") == "fee" and is_owner(update.effective_user.id):
        context.user_data.clear()
        await update.message.reply_text(
            "Platform fee is fixed at 10%. Sellers receive 90% of each successful sale.",
            reply_markup=back_menu(),
        )
    elif flow == "admin" and context.user_data.get("step") == "owner_upi" and is_owner(update.effective_user.id):
        upi_id = text.strip()
        if not is_valid_upi_id(upi_id):
            await update.message.reply_text(
                "Send a valid UPI ID such as <code>name@bank</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        await set_setting("owner_upi", upi_id)
        context.user_data.clear()
        await update.message.reply_text(
            "✅ Receiving UPI ID updated. New deposits will get amount-locked QR codes.",
            reply_markup=back_menu(),
        )
    elif flow == "admin" and context.user_data.get("step") == "broadcast" and is_owner(update.effective_user.id):
        sent = 0
        for user_id in await list_user_ids():
            try:
                await context.bot.send_message(user_id, text)
                sent += 1
            except Exception:
                pass
        context.user_data.clear()
        await update.message.reply_text(f"✅ Broadcast sent to {sent} user(s).", reply_markup=back_menu())
    elif flow == "admin" and context.user_data.get("step") == "seller_message" and is_owner(update.effective_user.id):
        seller_id = context.user_data.get("seller_message_target")
        if not seller_id:
            context.user_data.clear()
            await update.message.reply_text("Seller target not found.", reply_markup=back_menu())
            return
        await context.bot.send_message(
            seller_id,
            f"📩 <b>Message from SRC Vault Admin</b>\n\n{esc(text)}",
            parse_mode=ParseMode.HTML,
        )
        context.user_data.clear()
        await update.message.reply_text(
            f"✅ Message sent to seller <code>{seller_id}</code>.",
            parse_mode=ParseMode.HTML,
            reply_markup=back_menu(),
        )
    elif flow == "admin" and context.user_data.get("step") == "user_action" and is_owner(update.effective_user.id):
        parts = text.split()
        if len(parts) != 2 or parts[0].lower() not in {"ban", "unban"} or not parts[1].isdigit():
            await update.message.reply_text("Use: ban USER_ID or unban USER_ID")
            return
        target_id = int(parts[1])
        if target_id == ADMIN_ID:
            await update.message.reply_text("The owner account cannot be banned.")
            return
        await set_banned(target_id, parts[0].lower() == "ban")
        context.user_data.clear()
        await update.message.reply_text("✅ User status updated.", reply_markup=back_menu())
    elif flow == "admin" and context.user_data.get("step") == "user_search" and is_owner(update.effective_user.id):
        rows = await find_users(text)
        if not rows:
            await update.message.reply_text(
                "No matching user found. Send another ID, username, or name.",
                reply_markup=InlineKeyboardMarkup([
                    [btn("↩️ User Management", "admin_users")],
                ]),
            )
            return
        context.user_data.clear()
        buttons = [
            [
                btn(
                    f"{row['id']} · @{row['username'] or row['first_name'] or 'user'}",
                    f"admin_user_view:{row['id']}",
                )
            ]
            for row in rows
        ]
        buttons.append([btn("🔎 Search Again", "admin_user_search")])
        await update.message.reply_text(
            "Select a user to view their wallet balance:",
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    elif flow == "admin" and context.user_data.get("step") == "wallet_credit" and is_owner(update.effective_user.id):
        parts = text.split(maxsplit=1)
        try:
            amount = round(float(parts[0].replace("₹", "").replace(",", "")), 2)
            if amount <= 0:
                raise ValueError
        except (ValueError, IndexError):
            await update.message.reply_text(
                "Send a positive amount, for example: <code>500 goodwill adjustment</code>.",
                parse_mode=ParseMode.HTML,
            )
            return
        target_id = context.user_data.get("wallet_credit_target")
        reason = parts[1].strip() if len(parts) > 1 else "Manual credit by owner"
        updated = await add_wallet_credit(
            update.effective_user.id, int(target_id), amount, reason
        )
        context.user_data.clear()
        if not updated:
            await update.message.reply_text(
                "User not found or credit could not be applied.",
                reply_markup=back_menu(),
            )
            return
        await update.message.reply_text(
            f"✅ Wallet credited successfully.\n"
            f"User: <code>{updated['id']}</code>\n"
            f"Added: <b>₹{amount:.2f}</b>\n"
            f"New wallet balance: <b>₹{float(updated.get('wallet_balance', 0) or 0):.2f}</b>\n"
            f"Reason: {esc(reason)}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [btn("👤 View User", f"admin_user_view:{updated['id']}")],
                [btn("↩️ User Management", "admin_users")],
            ]),
        )
    else:
        await update.message.reply_text("Use /start to open the main menu.")


async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = await get_user(update.effective_user.id)
    if user and user.get("banned") and not is_owner(update.effective_user.id):
        await update.callback_query.answer(
            "This account is restricted.", show_alert=True
        )
        return
    data = update.callback_query.data
    if data == "force_join_verify":
        return await force_join_verify_callback(update, context)
    if not await force_join_allowed(update, context):
        return
    if data == "menu":
        return await menu_callback(update, context)
    if data == "buy":
        return await buy_callback(update, context)
    if data == "store":
        return await store_callback(update, context)
    if data.startswith("store:"):
        await update.callback_query.answer()
        return await show_listings(
            update.callback_query, 0, data.split(":", 1)[1]
        )
    if data.startswith("store_page:"):
        await update.callback_query.answer()
        _, market, offset = data.split(":", 2)
        return await show_listings(
            update.callback_query, int(offset),
            None if market == "all" else market,
        )
    if data.startswith("list:"):
        await update.callback_query.answer()
        return await show_listings(update.callback_query, int(data.split(":")[1]))
    if data.startswith("listing_reviews:"):
        return await listing_reviews_callback(
            update, context, int(data.split(":")[1])
        )
    if data.startswith("report:"):
        return await report_listing_callback(
            update, context, int(data.split(":")[1])
        )
    if data.startswith("chat_reply:"):
        _, peer_id, listing_id = data.split(":", 2)
        return await chat_reply_callback(
            update, context, int(peer_id), int(listing_id)
        )
    if data.startswith("chat_end:"):
        return await end_chat_callback(
            update, context, int(data.split(":", 1)[1])
        )
    if data.startswith("chat:"):
        return await chat_seller_callback(
            update, context, int(data.split(":", 1)[1])
        )
    if data.startswith("offer:"):
        return await offer_callback(update, context, int(data.split(":")[1]))
    if data.startswith("listing:"):
        return await listing_detail(update, context, int(data.split(":")[1]))
    if data.startswith("api_plans:"):
        return await api_plans_callback(update, context, int(data.split(":")[1]))
    if data.startswith("api_plan:"):
        _, listing_id, months = data.split(":", 2)
        return await buy_api_plan(update, context, int(listing_id), int(months))
    if data.startswith("api_genuine:"):
        return await api_genuine_callback(update, context, int(data.split(":", 1)[1]))
    if data.startswith("api_error:"):
        return await api_error_callback(update, context, int(data.split(":", 1)[1]))
    if data.startswith("api_error_cancel:"):
        context.user_data.clear()
        await update.callback_query.answer()
        return await update.callback_query.edit_message_text(
            "API error report cancelled.", reply_markup=back_menu()
        )
    if data.startswith("buy_now:"):
        return await buy_now(update, context, int(data.split(":")[1]))
    if data.startswith("api_deliver:"):
        return await api_delivery_callback(update, context, int(data.split(":")[1]))
    if data.startswith("api_chat:"):
        return await api_chat_callback(update, context, int(data.split(":")[1]))
    if data == "sell":
        return await seller_begin(update, context)
    if data == "sell_api":
        return await seller_begin(update, context, forced_category="API")
    if data == "verify_seller":
        return await verify_seller_start(update, context)
    if data in {"profile", "account"}:
        return await profile_callback(update, context)
    if data == "seller_center":
        return await seller_center_callback(update, context)
    if data == "seller_funds":
        return await seller_funds_callback(update, context)
    if data == "seller_offers":
        return await seller_offers_callback(update, context)
    if data == "seller_preview":
        return await seller_preview_callback(update, context)
    if data == "withdraw":
        return await withdraw_callback(update, context)
    if data.startswith("withdraw_approve:") or data.startswith("withdraw_reject:"):
        return await withdrawal_review_callback(update, context)
    if data == "balance":
        return await balance_callback(update, context)
    if data == "earn":
        return await earn_callback(update, context)
    if data == "earn_notify":
        return await earn_notify_callback(update, context)
    if data == "earn_tasks":
        return await earn_tasks_callback(update, context)
    if data == "earn_history":
        return await earn_history_callback(update, context)
    if data.startswith("task_view:"):
        return await task_view_callback(update, context, int(data.split(":", 1)[1]))
    if data.startswith("task_claim:"):
        return await task_claim_callback(update, context, int(data.split(":", 1)[1]))
    if data == "deposit":
        return await deposit_callback(update, context)
    if data in {"deposit_start", "deposit_start_upi"}:
        return await deposit_start_callback(update, context)
    if data == "deposit_start_binance":
        return await deposit_binance_start_callback(update, context)
    if data == "deposit_history":
        return await deposit_history_callback(update, context)
    if data == "dashboard":
        return await dashboard_callback(update, context)
    if data == "updates":
        return await updates_callback(update, context)
    if data == "my_purchases":
        return await purchases_callback(update, context)
    if data == "transactions":
        return await transactions_callback(update, context)
    if data == "reviews":
        return await reviews_callback(update, context)
    if data == "my_listings":
        return await my_listings_callback(update, context)
    if data.startswith("rate:"):
        return await rate_callback(update, context)
    if data == "support":
        return await support_callback(update, context)
    if data == "support_report":
        return await support_report_callback(update, context)
    if data == "admin":
        return await admin_panel(update, context)
    if data == "listing_confirm":
        return await confirm_listing_callback(update, context)
    if data.startswith("admin_"):
        return await admin_action(update, context)
    if data.startswith("seller_") or data.startswith("listing_"):
        return await review_callback(update, context)
    await update.callback_query.answer()


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE):
    log.exception("Unhandled update error", exc_info=context.error)


def build_app() -> Application:
    if not BOT_TOKEN or BOT_TOKEN == "PASTE_TELEGRAM_BOT_TOKEN_HERE":
        raise RuntimeError(
            "Telegram bot token is not configured. Edit src_vault_bot/config.py "
            "and replace MANUAL_BOT_TOKEN."
        )
    app = (
        Application.builder()
        .bot(PremiumBot(token=BOT_TOKEN))
        .persistence(PicklePersistence(filepath=PERSISTENCE_PATH))
        .post_init(post_init)
        .build()
    )
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CallbackQueryHandler(callback_router))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(
        MessageHandler(filters.VIDEO | filters.AUDIO | filters.ANIMATION, handle_media)
    )
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_router))
    app.add_error_handler(on_error)
    return app


async def post_init(app: Application):
    await init_db()
    await verify_log_destinations(app.bot)
    revoked_requests = await reconcile_unverified_deposits()
    for request in revoked_requests:
        try:
            await app.bot.send_message(
                request["buyer_id"],
                "⚠️ <b>API order revoked</b>\n"
                f"Product: <b>{esc(request['title'])}</b>\n"
                "The wallet credit used for this order could not be verified, "
                "so the seller request was cancelled and the unverified balance "
                "was removed. Add money through a verified deposit before buying again.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_menu(),
            )
            await app.bot.send_message(
                request["seller_id"],
                "⚠️ <b>API request cancelled</b>\n"
                f"Product: <b>{esc(request['title'])}</b>\n"
                "The buyer's wallet funding failed verification. Do not deliver access for this request.",
                parse_mode=ParseMode.HTML,
                reply_markup=back_menu(),
            )
        except Exception:
            log.exception(
                "Could not notify users about revoked API request %s",
                request["id"],
            )
    if revoked_requests and ADMIN_ID:
        await app.bot.send_message(
            ADMIN_ID,
            f"🛡 Security reconciliation revoked {len(revoked_requests)} API request(s) "
            "funded by an unverified wallet credit.",
        )
    if app.job_queue:
        app.job_queue.run_repeating(
            api_deadline_job, interval=60, first=30, name="api-fulfilment-deadlines"
        )
        app.job_queue.run_repeating(
            task_retention_job, interval=900, first=90, name="earning-task-retention"
        )
    log.info("SRC Vault database initialized")


async def api_deadline_job(context: ContextTypes.DEFAULT_TYPE):
    for request in await expire_api_requests():
        deadline = request["deadline"].replace("T", " ")[:16]
        buyer_notice = (
            "⏰ <b>API fulfilment deadline missed</b>\n"
            f"Request: <code>{esc(request['reference'])}</code>\n"
            f"Deadline: {deadline} UTC\n"
            f"₹{float(request['total_amount']):.2f} has been refunded to your wallet.\n"
            "You can use the refunded balance to buy another API or SRC."
        )
        seller_notice = (
            "⏰ <b>API fulfilment deadline missed</b>\n"
            f"Request: <code>{esc(request['reference'])}</code>\n"
            f"Deadline: {deadline} UTC\n"
            "The buyer has been refunded because the API was not submitted within 4 hours."
        )
        for user_id, notice in (
            (request["buyer_id"], buyer_notice),
            (request["seller_id"], seller_notice),
        ):
            try:
                await context.bot.send_message(
                    user_id, notice, parse_mode=ParseMode.HTML, reply_markup=back_menu()
                )
            except Exception:
                log.exception("Could not notify user about overdue API request %s", request["id"])
        if ADMIN_ID:
            await context.bot.send_message(
                ADMIN_ID,
                "⏰ <b>API SLA overdue</b>\n"
                f"Request: <code>{esc(request['reference'])}</code>\n"
                f"Seller: <code>{request['seller_id']}</code> · Buyer: <code>{request['buyer_id']}</code>\n"
                f"Refunded to buyer wallet: ₹{float(request['total_amount']):.2f}",
                parse_mode=ParseMode.HTML,
            )


async def task_retention_job(context: ContextTypes.DEFAULT_TYPE):
    """Claw back task rewards when a user leaves before retention ends."""
    for claim in await list_monitored_task_claims():
        chat_ref = task_chat_ref(claim["channel_ref"])
        if not chat_ref:
            continue
        try:
            member = await context.bot.get_chat_member(chat_ref, claim["user_id"])
        except Exception:
            # A temporary Telegram/channel permission error must never deduct a
            # user's earnings. The next scheduled run will retry.
            log.exception(
                "Could not recheck task membership for claim %s", claim["id"]
            )
            continue
        status = getattr(member, "status", "")
        still_joined = status in {"member", "administrator", "creator"} or (
            status == "restricted" and bool(getattr(member, "is_member", False))
        )
        if still_joined:
            continue
        clawed = await clawback_task_claim(
            claim["id"], "User left the required channel before retention completed"
        )
        if not clawed:
            continue
        try:
            await context.bot.send_message(
                claim["user_id"],
                f"⚠️ Task reward clawed back\n"
                f"₹{float(claim['reward']):.2f} was removed because you left "
                "the required channel before the retention period ended.",
                reply_markup=earning_tasks_menu(
                    has_tasks=bool(await list_active_earning_tasks(1)),
                    has_history=True,
                ),
            )
        except Exception:
            log.exception("Could not notify user about task clawback %s", claim["id"])
        if ADMIN_ID:
            try:
                await context.bot.send_message(
                    ADMIN_ID,
                    f"⚠️ Task reward clawed back\n"
                    f"Task: <code>#{claim['task_id']}</code> · User: <code>{claim['user_id']}</code>\n"
                    f"Amount: ₹{float(claim['reward']):.2f}",
                    parse_mode=ParseMode.HTML,
                )
            except Exception:
                log.exception("Could not notify owner about task clawback %s", claim["id"])


if __name__ == "__main__":
    application = build_app()
    log.info("Starting SRC Vault bot")
    application.run_polling(allowed_updates=Update.ALL_TYPES)