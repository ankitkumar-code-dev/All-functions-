import requests
import random
import json
import urllib3
from flask import Flask, request, jsonify
from flask_cors import CORS
from concurrent.futures import ThreadPoolExecutor

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
CORS(app)

BASE_URL = "https://api.vahan.pro"
API_KEY = "MaEHqzXzdWrCEROLWS6TS"

HEADERS_BASE = {
    "accept": "application/json, text/plain, */*",
    "accept-type": "application/json",
    "x-api-mobile-key": API_KEY,
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip",
    "User-Agent": "okhttp/4.11.0",
}

SMC_URL = "https://www.smcinsurance.com/central/centralcall/CallReqWithHeader"

SMC_HEADERS = {
    "content-type": "application/json;charset=UTF-8",
    "accept": "application/json, text/plain, */*",
    "origin": "https://www.smcinsurance.com",
    "referer": "https://www.smcinsurance.com/rto/vehicle-owner-details",
    "x-requested-with": "XMLHttpRequest",
    "user-agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/148.0.0.0 Safari/537.36"
    ),
    "cookie": (
        "_gcl_au=1.1.1438248880.1779788708; "
        "_gid=GA1.2.1153916911.1779959297; "
        "_ga=GA1.2.1149128124.1779788709; "
        "MCBC=0VqWZYKix5Xvpi%2BqafMsmM8VEAsoffaCxor1evU5WsU%3D%3A"
        "62f9089e5fd48fc8ff5e8cc44401651e9ae1df4b992a8a046081f29f60afc6ea"
    )
}

ACKO_HEADERS = {
    "User-Agent": "Dart/3.9 (dart:io)",
    "Accept": "application/json",
    "content-type": "application/json",
    "Accept-Encoding": "gzip",
    "app_version": "12.2.6",
    "enable_app_cache_bust": "true",
    "platform": "android",
    "x-platform": "android",
    "build_number": "356",
    "app-d2c-device-id": "54a3d0e6d598ebb3",
    "app-d2c-tracker-id": "7dcfa2d2-bfed-4faa-ad7f-6ad5013b861c",
    "app-d2c-refresh-token": (
        "eyJhbGciOiJIUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIwZmVmYzE3Yi03OGUwLTRkZjUtOGI4OC1iZmVmNDlkMGRkZTgifQ"
        ".eyJpYXQiOjE3NzgwODUxOTQsImp0aSI6ImM2OWI2ZmE3LTY5OWQtNDFhNy1hN2FjLTVjYmRiZDQ4N2ZlZCIsImlzcyI6Imh0dHBzOi8v"
        "Y2VudHJhbC1hdXRoLXByb2QuaW50ZXJuYWwubGl2ZS5hY2tvLmNvbS9yZWFsbXMvYWNrbyIsImF1ZCI6Imh0dHBzOi8vY2VudHJhbC1hdXRo"
        "LXByb2QuaW50ZXJuYWwubGl2ZS5hY2tvLmNvbS9yZWFsbXMvYWNrbyIsInN1YiI6Ilk2cWdjMGY5RW5mRzVzSEdWQlFZWVEiLCJ0eXAiOiJP"
        "ZmZsaW5lIiwiYXpwIjoiYWNrb19hcHAiLCJzZXNzaW9uX3N0YXRlIjoiOWQ2YWQ2MzgtZTQzYS00MTgzLWE2NDMtMTYwZmMyMDM1OTM2Iiwi"
        "c2NvcGUiOiJvZmZsaW5lX2FjY2VzcyIsInNpZCI6IjlkNmFkNjM4LWU0M2EtNDE4My1hNjQzLTE2MGZjMjAzNTkzNiJ9"
        ".cBSgTKy1xp78lgIbJfq-hNdXzg9UxaFDjZXsZ4c9mcY"
    ),
    "app-d2c-access-token": (
        "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJFUHhtZUwzV0hDLTVsNTQ1VHNld2kwYTU3SFRlZy0ySXpmZk9zM0hOUEhNIn0"
        ".eyJleHAiOjE3NzgyNTc5OTQsImlhdCI6MTc3ODA4NTE5NCwiYXV0aF90aW1lIjoxNzc2OTYyNDI2LCJqdGkiOiI3ZWVkM2ExNi0yNDE3LTRjNmIt"
        "YmNlZC00NjAzMzhmOTI4YTkiLCJpc3MiOiJodHRwczovL2NlbnRyYWwtYXV0aC1wcm9kLmludGVybmFsLmxpdmUuYWNrby5jb20vcmVhbG1zL2Fja28i"
        "LCJzdWIiOiJZNnFnYzBmOUVuZkc1c0hHVkJRWVlRIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYWNrb19hcHAiLCJzZXNzaW9uX3N0YXRlIjoiOWQ2YWQ2"
        "MzgtZTQzYS00MTgzLWE2NDMtMTYwZmMyMDM1OTM2Iiwic2NvcGUiOiJvZmZsaW5lX2FjY2VzcyIsInNpZCI6IjlkNmFkNjM4LWU0M2EtNDE4My1hNjQz"
        "LTE2MGZjMjAzNTkzNiIsIm1pZ3JhdGlvbl9rZXlzIjp7ImFja29kcml2ZV9pZCI6IjM5MDU5MTEiLCJ1c2VyX2lkIjoiMjEzNjcyNzgwIn19"
        ".U-mEEXDW5pNoQ9gNg25C10QwSoXlbUXZCjfU2sVs98AaL4k6D5ClyF-15CpUCXIlDgYuHP4nA1dIdHdrwvSslpkYYEVdyn6s-mbeH5EDituFYgb_"
        "AOEhsxF708SAaqmoMsPyf4fIYY7D3Ulu0KDXf18m7dX_5WFbcjkW-7V2XEQ4BM80DYEZby74-zwq7FumMzXnTp4k76o4zxhM4w0q5cpW97Uniw7fDI"
        "87JvbBIbKI_dFbeKsbvjtldPH4Q6y7-D4faDMB_Tw84hXoHYAiAVVQe73ueQ57H37knRcZGifrn8CfE5oNRGD4yzaB1W0kjs8QitLFwvsIncPWwMjlNw"
    )
}

session = requests.Session()
session.verify = False
session.headers.update({"Connection": "Keep-Alive"})

executor = ThreadPoolExecutor(max_workers=10)


def generate_random_phone():
    first = random.choice(["6", "7", "8", "9"])
    rest = "".join([str(random.randint(0, 9)) for _ in range(9)])
    return first + rest


def get_fresh_token():
    phone = generate_random_phone()
    headers = {**HEADERS_BASE, "authorization": "", "Content-Type": "application/json"}
    payload = {"phoneNumber": phone}

    try:
        resp = session.post(
            f"{BASE_URL}/user/checkPhoneExist",
            headers=headers,
            json=payload,
            timeout=10,
        )
        data = resp.json()

        if data.get("statusCode") == 200 and data.get("data", {}).get("accessToken"):
            return data["data"]["accessToken"]
        else:
            return None
    except:
        return None


def search_vehicle(search_number, search_type):
    token = get_fresh_token()
    if not token:
        return None

    headers = {**HEADERS_BASE, "authorization": f"Bearer {token}"}
    params = {
        "type": search_type,
        "vehicleNumber": search_number,
        "userType": 1,
    }

    try:
        resp = session.get(
            f"{BASE_URL}/user/searchVehicle",
            headers=headers,
            params=params,
            timeout=10,
        )
        data = resp.json()

        if data.get("statusCode") == 200 and data.get("data"):
            return data["data"]
        else:
            return None
    except:
        return None


def fetch_smc(reg_no):
    payload = {
        "URL": "GetVaahanDetailsByVehicleNo",
        "Props": [reg_no],
        "Token": ""
    }
    try:
        resp = session.post(SMC_URL, headers=SMC_HEADERS, json=payload, timeout=20)
        data = resp.json()

        if data.get("statusCode") != 200:
            return None

        vehicle = data.get("response", {})
        vehicle.pop("transKey", None)
        return vehicle
    except:
        return None


def fetch_acko(reg_no):
    url = (
        "https://www.acko.com/api/sdui/central/auto-asset/vas/asset-header"
        f"?registration_number={reg_no}"
        "&source=vas_rto"
        "&include_vehicle_search_response=true"
    )
    try:
        resp = session.get(url, headers=ACKO_HEADERS, timeout=20)
        data = resp.json()
        return data.get("data", {}).get("searchApiData")
    except:
        return None


@app.route('/', methods=['GET'])
def home():
    return jsonify({
        "message": "VEHICLE API WORKING"
    })


@app.route('/engine', methods=['GET'])
def engine_lookup():
    engine_number = request.args.get('number', '').strip().upper()

    if not engine_number:
        return jsonify({"message": "VEHICLE API WORKING"})

    vehicle_data = search_vehicle(engine_number, 3)

    if not vehicle_data:
        return jsonify({"message": "VEHICLE API WORKING"})

    reg_no = vehicle_data.get("rc_regn_no")

    if not reg_no:
        return jsonify(vehicle_data)

    smc_future = executor.submit(fetch_smc, reg_no)
    acko_future = executor.submit(fetch_acko, reg_no)

    smc_data = smc_future.result()
    acko_data = acko_future.result()

    if smc_data:
        if acko_data:
            smc_data["owner"] = acko_data.get("owner_name") or smc_data.get("owner")
            smc_data["permAddress"] = acko_data.get("permanent_address") or smc_data.get("permAddress")
            smc_data["presentAddress"] = acko_data.get("present_address") or smc_data.get("presentAddress")
            smc_data["regAuthority"] = acko_data.get("registration_address") or smc_data.get("regAuthority")

        smc_data["Vehicle_No"] = reg_no
        return jsonify(smc_data)
    else:
        return jsonify(vehicle_data)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=True)