from flask import Flask, request, jsonify
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64, json, time, binascii
import requests

app = Flask(__name__)

BASE = "https://delhigw.napix.gov.in/nic/parivahan"

COMMON_HEADERS = {
    'User-Agent': "okhttp/4.9.2",
    'Connection': "Keep-Alive",
    'Accept': "application/json",
    'Accept-Encoding': "gzip",
    'Param2': "2.0.142",
    'Param1': "abcd"
}

def make_key():
    ctime = str(int(time.time() * 1000))
    return ctime, ctime[-4:][::-1] + ctime[:4][::-1] + '!~)#@*&^'

def aes_encrypt_ecb_pkcs7(plaintext, key):
    key = key.encode() if isinstance(key, str) else key
    cipher = AES.new(key, AES.MODE_ECB)
    return base64.b64encode(cipher.encrypt(pad(plaintext.encode(), AES.block_size))).decode()

def aes_decrypt_ecb_pkcs7(encrypted_text, key):
    key = key.encode() if isinstance(key, str) else key
    encrypted_data = base64.b64decode(encrypted_text)
    cipher = AES.new(key, AES.MODE_ECB)
    return unpad(cipher.decrypt(encrypted_data), AES.block_size).decode()

def post_encrypted(url, plain_json, access_token, label):
    ctime, key = make_key()
    payload = json.dumps({"data": base64.b64encode(aes_encrypt_ecb_pkcs7(plain_json, key).encode()).decode()})
    headers = dict(COMMON_HEADERS)
    headers['Content-Type'] = "application/json; charset=utf-8"
    headers['timestamp'] = ctime
    headers['Authorization'] = f"Bearer {access_token}"

    try:
        r = requests.post(url, data=payload, headers=headers, timeout=15)
        if not r.text.strip():
            return None
        
        j = r.json()
        data = j.get("data")
        if not data:
            return None
        
        return aes_decrypt_ecb_pkcs7(base64.b64decode(data).decode(), key)
    except:
        return None

def getAccesToken():
    url = f"{BASE}/oauth2/token"
    payload = ("grant_type=client_credentials&scope=napix"
               "&client_id=b91c303443f61b37106750823881cd2f"
               "&client_secret=de83eeeb148878ae375f28756492e8a0")
    headers = {'User-Agent': "okhttp/4.9.2", 'Connection': "Keep-Alive",
               'Accept-Encoding': "gzip", 'Content-Type': "application/x-www-form-urlencoded"}
    
    try:
        r = requests.post(url, data=payload, headers=headers, timeout=15)
        j = r.json()
        return j.get("access_token")
    except:
        return None

def getVehicleByNumber(number, access_token):
    url = f"{BASE}/mparivahan/wrapperapi/vahan/vahancapi/common/getvehiclevalidity"
    return post_encrypted(url, '{"mobileNo":"' + number + '"}', access_token, "vehicle")

@app.route('/', methods=['GET'])
def home():
    return jsonify({
        "message": "Parivahan Vehicle API"
    })

@app.route('/api/vehicle', methods=['GET'])
def vehicle():
    mobile = request.args.get('mobile', '').strip()
    
    if not mobile or len(mobile) != 10 or not mobile.isdigit():
        return jsonify({
            "success": False,
            "error": "Invalid mobile number. Please provide 10 digit mobile number."
        }), 400

    access_token = getAccesToken()
    if not access_token:
        return jsonify({
            "success": False,
            "error": "Failed to get access token"
        }), 500

    result = getVehicleByNumber(mobile, access_token)
    
    if not result:
        return jsonify({
            "success": False,
            "error": "No data found or API error"
        }), 404

    try:
        data = json.loads(result)
        return jsonify({
            "success": True,
            "mobile": mobile,
            "data": data
        })
    except:
        return jsonify({
            "success": True,
            "mobile": mobile,
            "raw_data": result
        })