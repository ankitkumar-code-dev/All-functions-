from flask import Flask, request, jsonify
import requests
import json
import random

app = Flask(__name__)

PROXIES = [
    "31.59.20.176:6754:bbpsdjvy:229lu1zbkyws",
    "45.38.107.97:6014:bbpsdjvy:229lu1zbkyws",
    "198.105.121.200:6462:bbpsdjvy:229lu1zbkyws",
    "64.137.96.74:6641:bbpsdjvy:229lu1zbkyws",
    "198.23.243.226:6361:bbpsdjvy:229lu1zbkyws",
    "38.154.185.97:6370:bbpsdjvy:229lu1zbkyws",
    "84.247.60.125:6095:bbpsdjvy:229lu1zbkyws",
    "142.111.67.146:5611:bbpsdjvy:229lu1zbkyws",
    "191.96.254.138:6185:bbpsdjvy:229lu1zbkyws",
    "31.58.9.4:6077:bbpsdjvy:229lu1zbkyws"
]

def get_headers():
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ]
    return {
        "Host": "web.justpolicy.in",
        "Connection": "keep-alive",
        "User-Agent": random.choice(user_agents),
        "Accept": "*/*",
        "Referer": "https://web.justpolicy.in/car-insurance/?type=rollover",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "DNT": "1",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin"
    }

def get_proxy(proxy_str):
    ip, port, user, pwd = proxy_str.split(":")
    return f"http://{user}:{pwd}@{ip}:{port}"

def get_fresh_session(proxy):
    url = "https://web.justpolicy.in/car-insurance/?type=rollover"
    headers = get_headers()
    proxies = {"http": proxy, "https": proxy}

    try:
        session = requests.Session()
        response = session.get(url, headers=headers, proxies=proxies, timeout=10)
        if response.status_code == 200:
            return {
                "PHPSESSID": session.cookies.get("PHPSESSID"),
                "session": session
            }
    except Exception:
        return None
    return None

def unwrap_data(data):
    """Nested 'data' keys ko flatten karo - sirf actual vehicle info rakho"""
    # Agar dict hai aur usme sirf 'data' key hai, to andar jao
    while isinstance(data, dict) and "data" in data and len(data) == 1:
        data = data["data"]
    
    # Agar dict hai aur usme 'data' + kuch aur keys hain (jaise success, source)
    # to andar wala 'data' nikaal lo
    if isinstance(data, dict) and "data" in data:
        inner = data["data"]
        # Baaki useful keys bhi saath rakho (success, source waghera)
        extra = {k: v for k, v in data.items() if k != "data"}
        # Recursively unwrap inner
        inner = unwrap_data(inner)
        if isinstance(inner, dict):
            # merge extra keys
            return {**inner, **extra}
        return inner
    
    return data

def clean_response(data):
    if isinstance(data, dict):
        cleaned = {}
        for key, value in data.items():
            if key in ["mmvResponse", "blacklistDetails", "blacklistStatus", "dbResult", "partialData"]:
                continue
            if value is not None and value != "" and value != [] and value != "NA":
                cleaned[key] = clean_response(value)
        return cleaned
    elif isinstance(data, list):
        return [clean_response(item) for item in data if item not in ["", None, "NA"]]
    else:
        return data

def fetch_vehicle_details(reg_number):
    proxy_list = [get_proxy(p) for p in PROXIES]
    random.shuffle(proxy_list)

    for proxy in proxy_list:
        session_data = get_fresh_session(proxy)
        if not session_data or not session_data["PHPSESSID"]:
            continue

        try:
            url = f"https://web.justpolicy.in/php-vahaan/service.php/?action=VAHAAN_DETAILS&reg_number={reg_number}&type=rc"
            headers = get_headers()
            headers["Referer"] = f"https://web.justpolicy.in/car-insurance/?reg_no={reg_number}"

            response = session_data["session"].get(
                url,
                headers=headers,
                timeout=15
            )

            if response.status_code == 200:
                try:
                    parsed = json.loads(response.text)
                    # Pehle nested 'data' unwrap karo
                    flattened = unwrap_data(parsed)
                    # Phir unwanted fields clean karo
                    cleaned = clean_response(flattened)
                    return {
                        "data": cleaned,
                        "proxy_status": f"Working: {proxy.split('@')[1]}",
                        "session_id": session_data["PHPSESSID"][:8] + "..."
                    }
                except json.JSONDecodeError:
                    return {
                        "raw_data": response.text,
                        "proxy_status": f"Working: {proxy.split('@')[1]}",
                        "session_id": session_data["PHPSESSID"][:8] + "..."
                    }
        except Exception:
            continue

    return {"error": "All proxies failed", "proxy_status": "Not working"}

@app.route("/api/vehicle", methods=["GET"])
def get_vehicle():
    reg_number = request.args.get("rc", "").upper().strip()
    if not reg_number:
        return jsonify({"error": "Missing 'rc' parameter"}), 400

    result = fetch_vehicle_details(reg_number)
    if "error" in result:
        return jsonify(result), 500

    return jsonify({
        "rc": reg_number,
        **result
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)