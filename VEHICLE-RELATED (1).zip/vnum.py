from flask import Flask, request, jsonify
import requests
import re
import time
import threading
import xml.etree.ElementTree as ET
import json
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

app = Flask(__name__)

UPSTREAM = "https://horizon.policyboss.com:5443/quote/vehicle_info_loggedin"
SECRET_KEY = "SECRET-HZ07QRWY-JIBT-XRMQ-ZP95-J0RWP3DYRACW"
CLIENT_KEY = "CLIENT-CNTP6NYE-CU9N-DUZW-CSPI-SH1IS4DOVHB9"
SOURCE = "PB-BETA"
UPSTREAM_TIMEOUT = 60
CACHE_TTL = 3600

HEADERS = {
    "Content-Type": "application/json;charset=utf-8",
    "Accept": "application/json",
    "Origin": "https://www.policyboss.com",
    "Referer": "https://www.policyboss.com/car-insurance",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
}

REGEX = re.compile(
    r"^[A-Z]{2}\s?\d{1,2}\s?[A-Z]{1,3}\s?\d{4}$|^[A-Z]{2}\s?\d{1,2}\s?BH\s?\d{4}$", re.I
)
REGEX_STRIP = re.compile(r"[\s-]+")

RENEWBUY_URL = "https://apex.renewbuyinsurance.com/api/v1/vaahan/registration_number/"
SMC_API_URL = "https://www.smcinsurance.com/central/centralcall/CallReqWithHeader"

SMC_HEADERS = {
    "content-type": "application/json;charset=UTF-8",
    "accept": "application/json, text/plain, */*",
    "origin": "https://www.smcinsurance.com",
    "referer": "https://www.smcinsurance.com/rto/vehicle-owner-details",
    "x-requested-with": "XMLHttpRequest",
    "user-agent": (
        "Mozilla/5.0 (X11; Linux x86_64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/148.0.0.0 Safari/537.36"
    ),
    "cookie": (
        "_gcl_au=1.1.1438248880.1779788708; "
        "_gid=GA1.2.1153916911.1779959297; "
        "_ga=GA1.2.1149128124.1779788709; "
        "MCBC=0VqWZYKix5Xvpi%2BqafMsmM8VEAsoffaCxor1evU5WsU%3D%3A"
        "62f9089e5fd48fc8ff5e8cc44401651e9ae1df4b992a8a046081f29f60afc6ea"
    )
}

HOMEPAGE_URL = "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml?statecd=Mzc2MzM2MzAzNjY0MzIzODM3NjIzNjY0MzY2MjM3NDQ0Yw=="
HOMEPAGE_BASE = "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml"
LOGIN_URL = "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/usermgmt/login.xhtml"
FORM_URL = "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/balanceservice/form_reschedule_fitness.xhtml"

_local = threading.local()
_cache = {}
_cache_lock = threading.Lock()
_inflight = {}
_inflight_lock = threading.Lock()


def _session() -> requests.Session:
    s = getattr(_local, "sess", None)
    if s is None:
        s = requests.Session()
        s.headers.update(HEADERS)
        _local.sess = s
    return s


def normalize_number(number: str) -> str:
    return REGEX_STRIP.sub("", number or "").upper()


def is_valid_number(number: str) -> bool:
    return bool(REGEX.match(number.strip()))


def _cache_get(key: str):
    with _cache_lock:
        hit = _cache.get(key)
        if hit and hit["ts"] + CACHE_TTL > time.time():
            return hit["data"]
        if hit:
            _cache.pop(key, None)
    return None


def _cache_set(key: str, data):
    with _cache_lock:
        _cache[key] = {"ts": time.time(), "data": data}


def parse_fastlane_response(fastlane_response):
    if not fastlane_response:
        return None
    
    try:
        return json.loads(fastlane_response)
    except (json.JSONDecodeError, TypeError):
        pass
    
    try:
        root = ET.fromstring(fastlane_response)
        
        def element_to_dict(elem):
            result = {}
            if elem.attrib:
                result.update(elem.attrib)
            
            for child in elem:
                child_dict = element_to_dict(child)
                if child.tag in result:
                    if not isinstance(result[child.tag], list):
                        result[child.tag] = [result[child.tag]]
                    result[child.tag].append(child_dict)
                else:
                    result[child.tag] = child_dict
            
            if elem.text and elem.text.strip():
                if len(result) == 0:
                    result = elem.text.strip()
                else:
                    result["text"] = elem.text.strip()
            
            return result
        
        return {root.tag: element_to_dict(root)}
    except ET.ParseError:
        return None


def clean_upstream(raw: dict) -> dict:
    junk = {"Ip_Address", "Calling_Source", "Product_Id_Request", "Ss_Id", "Channel",
            "Is_LM", "FastLaneId", "Match_Mode", "FastlaneResponse", "FastlaneResponse_Obj"}
    no_vahan = raw.get("0") == "N" or all(k.isdigit() for k in list(raw)[:6])
    out = {k: v for k, v in raw.items() if k not in junk and not k.isdigit()}
    out["found"] = not no_vahan and bool(out.get("Make_Name"))
    
    if "FastlaneResponse" in raw and raw["FastlaneResponse"]:
        parsed = parse_fastlane_response(raw["FastlaneResponse"])
        if parsed:
            out["vehicle_details"] = parsed
    
    return out


def upstream_lookup(number: str, product_id: int):
    payload = {
        "secret_key": SECRET_KEY,
        "client_key": CLIENT_KEY,
        "RegistrationNumber": number,
        "product_id": product_id,
        "ss_id": 0,
        "source": SOURCE,
        "session_id": "",
    }
    resp = _session().post(UPSTREAM, json=payload, timeout=UPSTREAM_TIMEOUT)
    if resp.status_code == 403:
        raise RuntimeError("Upstream captcha gate triggered (unexpected)")
    if resp.status_code != 200:
        raise RuntimeError(f"Upstream error HTTP {resp.status_code}")
    return resp.json()


def renewbuy_lookup(number: str) -> dict:
    params = {
        "regn_no": number,
        "partner_code": "",
        "mobile_no": "7451010349",
        "source": "apex",
        "originData": "false"
    }
    
    resp = _session().get(RENEWBUY_URL, params=params, timeout=UPSTREAM_TIMEOUT)
    
    if resp.status_code != 200:
        raise RuntimeError(f"RenewBuy API error HTTP {resp.status_code}")
    
    data = resp.json()
    
    if isinstance(data, dict):
        if "code" in data and data.get("code") not in [200, 0, None]:
            raise ValueError("No chassis in RenewBuy response")
        
        chassis_no = data.get("chassis_number", "")
        
        if not chassis_no:
            meta_data = data.get("meta_data", {})
            if isinstance(meta_data, dict):
                signzy_response = meta_data.get("signzy_response", {})
                if isinstance(signzy_response, dict):
                    result = signzy_response.get("result", {})
                    if isinstance(result, dict):
                        chassis_no = result.get("chassis", "")
        
        if not chassis_no:
            vehicle_details = data.get("vehicle_details", {})
            if isinstance(vehicle_details, dict):
                chassis_no = vehicle_details.get("chassis_no", "")
        
        if chassis_no:
            return {"Chassis_No": chassis_no}
    
    raise ValueError("Chassis number not found in RenewBuy response")


def smc_lookup(number: str) -> dict:
    payload = {
        "URL": "GetVaahanDetailsByVehicleNo",
        "Props": [number],
        "Token": ""
    }
    
    resp = _session().post(SMC_API_URL, headers=SMC_HEADERS, json=payload, timeout=UPSTREAM_TIMEOUT)
    
    if resp.status_code != 200:
        raise RuntimeError(f"SMC API error HTTP {resp.status_code}")
    
    data = resp.json()
    
    if isinstance(data, dict):
        response_data = data.get("response", {})
        
        if isinstance(response_data, dict):
            chassis_no = response_data.get("chassis", "")
            
            if chassis_no and "*" in chassis_no:
                chassis_no = chassis_no.replace("*", "")
            
            if chassis_no:
                return {"Chassis_No": chassis_no}
    
    raise ValueError("Chassis number not found in SMC response")


def lookup(number: str, product_id: int = 1, use_cache: bool = True):
    norm = normalize_number(number)
    if not is_valid_number(norm):
        raise ValueError("Invalid Indian vehicle registration number")

    key = f"{norm}|{product_id}"
    if use_cache:
        hit = _cache_get(key)
        if hit is not None:
            return hit, True

    with _inflight_lock:
        holder = _inflight.get(key)
        if holder is None:
            holder = {"event": threading.Event(), "result": None, "owner": threading.get_ident()}
            _inflight[key] = holder
            am_owner = True
        else:
            am_owner = False

    if not am_owner:
        holder["event"].wait(timeout=UPSTREAM_TIMEOUT + 5)
        res = holder["result"]
        if isinstance(res, Exception):
            raise res
        return res, False

    try:
        raw = upstream_lookup(norm, product_id)
        result = clean_upstream(raw)
    except Exception as exc:
        holder["result"] = exc
        raise
    finally:
        holder["event"].set()
        with _inflight_lock:
            _inflight.pop(key, None)

    holder["result"] = result
    if use_cache:
        _cache_set(key, result)
    return result, False


def get_chassis_from_policyboss(vehicle_number):
    try:
        vehicle_data, cached = lookup(vehicle_number, 1, True)
        
        if not vehicle_data or not vehicle_data.get("found"):
            return None
        
        chassis_number = vehicle_data.get("Chassis_Number")
        
        if not chassis_number and "vehicle_details" in vehicle_data:
            details = vehicle_data["vehicle_details"]
            if isinstance(details, dict):
                data = details.get("data", {})
                if isinstance(data, dict):
                    chassis_number = data.get("rc_chasi_no")
        
        return chassis_number
    except Exception as e:
        return None


def get_chassis_from_renewbuy(vehicle_number):
    try:
        result = renewbuy_lookup(vehicle_number)
        return result.get("Chassis_No")
    except Exception as e:
        return None


def get_chassis_from_smc(vehicle_number):
    try:
        result = smc_lookup(vehicle_number)
        chassis_no = result.get("Chassis_No")
        if chassis_no and "*" in chassis_no:
            chassis_no = chassis_no.replace("*", "")
        return chassis_no
    except Exception as e:
        return None


def get_chassis_number(vehicle_number):
    chassis_number = get_chassis_from_renewbuy(vehicle_number)
    if chassis_number:
        return chassis_number
    
    chassis_number = get_chassis_from_smc(vehicle_number)
    if chassis_number:
        return chassis_number
    
    return None


def extract_chassis_number(vehicle_data):
    chassis_number = None
    
    if "vehicle_details" in vehicle_data and vehicle_data["vehicle_details"]:
        details = vehicle_data["vehicle_details"]
        
        if "result" in details:
            result = details["result"]
            chassis_number = result.get("rc_chassis_number")
        
        elif "response" in details:
            response = details["response"]
            if "result" in response:
                result = response["result"]
                if "vehicle" in result:
                    chassis_number = result["vehicle"].get("chasi_no")
    
    if not chassis_number:
        chassis_number = vehicle_data.get("Chassis_Number")
    
    return chassis_number


def get_vehicle_details_from_policyboss(vehicle_number):
    try:
        vehicle_data, cached = lookup(vehicle_number, 1, True)
        
        if not vehicle_data or not vehicle_data.get("found"):
            chassis_number = get_chassis_from_renewbuy(vehicle_number)
            if not chassis_number:
                chassis_number = get_chassis_from_smc(vehicle_number)
            
            if chassis_number:
                return {
                    "success": True,
                    "chassis_last_5": chassis_number[-5:],
                    "mobile_no": "",
                    "vehicle_data": {}
                }
            
            return {"success": False, "error": "Vehicle not found"}
        
        chassis_number = extract_chassis_number(vehicle_data)
        
        if not chassis_number:
            chassis_number = get_chassis_number(vehicle_number)
        
        if not chassis_number:
            return {"success": False, "error": "ChassisNo Not Found"}
        
        chassis_number = chassis_number.replace(" ", "")
        
        if len(chassis_number) >= 5:
            return {
                "success": True,
                "chassis_last_5": chassis_number[-5:],
                "mobile_no": "",
                "vehicle_data": vehicle_data
            }
        
        return {"success": False, "error": "ChassisNo Not Found"}
        
    except Exception as e:
        chassis_number = get_chassis_from_renewbuy(vehicle_number)
        if not chassis_number:
            chassis_number = get_chassis_from_smc(vehicle_number)
        
        if chassis_number:
            return {
                "success": True,
                "chassis_last_5": chassis_number[-5:],
                "mobile_no": "",
                "vehicle_data": {}
            }
        
        return {"success": False, "error": str(e)}


def create_session():
    session = requests.Session()
    retry = Retry(total=1, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
    session.mount('https://', adapter)
    session.mount('http://', adapter)
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
    })
    return session


def extract_viewstate(html):
    soup = BeautifulSoup(html, 'html.parser')
    vs = soup.find('input', {'name': 'javax.faces.ViewState'})
    return vs.get('value') if vs else None


def extract_viewstate_from_ajax(text):
    m = re.search(r'<update id="j_id1:javax.faces.ViewState:0"><!\[CDATA\[(.*?)\]\]></update>', text)
    return m.group(1) if m else None


def find_checkbox_id(html):
    m = re.search(r'<div[^>]*id="(j_idt\d+)"[^>]*class="[^"]*ui-chkbox', html)
    if not m:
        m = re.search(r'PrimeFaces.cw("SelectBooleanCheckbox"[^}]*id:"(j_idt\d+)"', html)
    return m.group(1) if m else "j_idt193"


def fetch_mobile_number(vehicle_number, chassis_last_5, fallback_mobile=""):
    session = create_session()

    ajax_headers = {
        'Accept': 'application/xml, text/xml, */*; q=0.01',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Faces-Request': 'partial/ajax',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://vahan.parivahan.gov.in',
    }

    for attempt in range(2):
        try:
            r1 = session.get(HOMEPAGE_URL, timeout=20)
            if r1.status_code != 200:
                continue
            viewstate = extract_viewstate(r1.text)
            if not viewstate:
                continue

            checkbox_id = find_checkbox_id(r1.text)

            ajax_headers['Referer'] = HOMEPAGE_URL
            r2 = session.post(HOMEPAGE_BASE, data={
                'javax.faces.partial.ajax': 'true',
                'javax.faces.source': 'fit_c_office_to',
                'javax.faces.partial.execute': 'fit_c_office_to',
                'javax.faces.behavior.event': 'change',
                'javax.faces.partial.event': 'change',
                'homepageformid': 'homepageformid',
                'fit_c_office_to_input': '1',
                'javax.faces.ViewState': viewstate,
            }, headers=ajax_headers, timeout=20)
            viewstate = extract_viewstate_from_ajax(r2.text) or viewstate

            r3 = session.post(HOMEPAGE_BASE, data={
                'javax.faces.partial.ajax': 'true',
                'javax.faces.source': checkbox_id,
                'javax.faces.partial.execute': checkbox_id,
                'javax.faces.partial.render': 'proccedHomeButtonId',
                'javax.faces.behavior.event': 'change',
                'homepageformid': 'homepageformid',
                f'{checkbox_id}_input': 'on',
                'javax.faces.ViewState': viewstate,
            }, headers=ajax_headers, timeout=20)
            viewstate = extract_viewstate_from_ajax(r3.text) or viewstate

            r4 = session.post(HOMEPAGE_BASE, data={
                'javax.faces.partial.ajax': 'true',
                'javax.faces.source': 'proccedHomeButtonId',
                'javax.faces.partial.execute': '@all',
                'proccedHomeButtonId': 'proccedHomeButtonId',
                'homepageformid': 'homepageformid',
                f'{checkbox_id}_input': 'on',
                'javax.faces.ViewState': viewstate,
            }, headers=ajax_headers, timeout=20)
            viewstate = extract_viewstate_from_ajax(r4.text) or viewstate

            dialog_match = re.search(r'id="(j_idt\d+)"[^>]*class="[^"]*ui-button', r4.text)
            dialog_btn = dialog_match.group(1) if dialog_match else "j_idt536"
            r5 = session.post(HOMEPAGE_BASE, data={
                'javax.faces.partial.ajax': 'true',
                'javax.faces.source': dialog_btn,
                'javax.faces.partial.execute': '@all',
                f'{dialog_btn}': dialog_btn,
                'homepageformid': 'homepageformid',
                f'{checkbox_id}_input': 'on',
                'javax.faces.ViewState': viewstate,
            }, headers=ajax_headers, timeout=20)
            viewstate = extract_viewstate_from_ajax(r5.text) or viewstate

            r6 = session.get(LOGIN_URL + "?faces-redirect=true", timeout=20, allow_redirects=True)
            viewstate = extract_viewstate(r6.text)
            if not viewstate:
                continue

            fit_match = re.search(r'id="(j_idt\d+)"[^>]*name="\1"[^>]*type="submit"', r6.text)
            fit_btn = fit_match.group(1) if fit_match else "j_idt506"
            post_headers = {
                **session.headers,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://vahan.parivahan.gov.in',
                'Referer': LOGIN_URL + "?faces-redirect=true",
            }
            r7 = session.post(LOGIN_URL, data={
                'loginForm': 'loginForm',
                f'{fit_btn}': fit_btn,
                'javax.faces.ViewState': viewstate,
                'fitbalcTest': 'fitbalcTest',
                'pur_cd': '86',
            }, headers=post_headers, timeout=20, allow_redirects=True)

            form_headers = {**session.headers, 'Referer': LOGIN_URL + "?faces-redirect=true"}
            r8 = session.get(FORM_URL, headers=form_headers, timeout=20)
            viewstate = extract_viewstate(r8.text)
            if not viewstate:
                continue

            ajax_headers['Referer'] = FORM_URL
            r9 = session.post(FORM_URL, data={
                'javax.faces.partial.ajax': 'true',
                'javax.faces.source': 'balanceFeesFine:validate_dtls',
                'javax.faces.partial.execute': '@all',
                'javax.faces.partial.render': 'balanceFeesFine:auth_panel',
                'balanceFeesFine:validate_dtls': 'balanceFeesFine:validate_dtls',
                'balanceFeesFine': 'balanceFeesFine',
                'balanceFeesFine:tf_reg_no': vehicle_number,
                'balanceFeesFine:tf_chasis_no': chassis_last_5,
                'javax.faces.ViewState': viewstate,
            }, headers=ajax_headers, timeout=20)

            text = r9.text

            for pat in [r'id="balanceFeesFine:tf_mobile"[^>]*value="(\d{10})"',
                        r'value="(\d{10})"[^>]*id="balanceFeesFine:tf_mobile"',
                        r'balanceFeesFine:tf_mobile[^>]*value="(\d{10})"']:
                m = re.search(pat, text, re.DOTALL)
                if m and m.group(1)[0] in '6789':
                    return {"success": True, "mobile_number": m.group(1)}

            fallback = re.findall(r'\b[6-9]\d{9}\b', text)
            if fallback:
                return {"success": True, "mobile_number": fallback[0]}

        except Exception as e:
            print(f"Attempt {attempt+1}: {e}")

        if attempt == 0:
            time.sleep(2)

    if fallback_mobile and len(fallback_mobile) == 10 and fallback_mobile[0] in '6789':
        return {"success": True, "mobile_number": fallback_mobile}

    return {"success": False, "error": "Mobile number not found"}


@app.route("/fetch", methods=["GET"])
def fetch_contact():
    vehicle_number = request.args.get("vehicle_number", "").strip().upper()
    vehicle_number = re.sub(r'[^A-Z0-9]', '', vehicle_number)

    if not vehicle_number or len(vehicle_number) < 6 or len(vehicle_number) > 12:
        return jsonify({"error": "Invalid vehicle number"}), 400

    vehicle_result = get_vehicle_details_from_policyboss(vehicle_number)

    if not vehicle_result["success"]:
        if "ChassisNo Not Found" in vehicle_result["error"]:
            return jsonify({"error": "ChassisNo Not Found"}), 400
        return jsonify({"error": vehicle_result["error"]}), 400

    mobile_result = fetch_mobile_number(
        vehicle_number,
        vehicle_result["chassis_last_5"],
        vehicle_result.get("mobile_no", "")
    )

    mobile = "Not Found"
    if mobile_result["success"]:
        mobile = mobile_result["mobile_number"]
    elif vehicle_result.get("mobile_no"):
        mobile = vehicle_result["mobile_no"]

    return jsonify({
        "vehicle": vehicle_number,
        "mobile": mobile
    })