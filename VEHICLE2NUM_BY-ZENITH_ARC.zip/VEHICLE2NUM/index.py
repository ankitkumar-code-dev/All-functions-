#ZENITH_ARC
#PRINCE_WEBZ
from flask import Flask, request, jsonify
from flask_caching import Cache
import requests
import re
import time
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
import os
import hashlib
import random
from collections import defaultdict
from functools import wraps

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.config['CACHE_TYPE'] = 'SimpleCache'
app.config['CACHE_DEFAULT_TIMEOUT'] = 3600
app.config['CACHE_THRESHOLD'] = 200
cache = Cache(app)

ip_requests = defaultdict(list)
blocked_ips = {}

MAX_REQUESTS_PER_MINUTE = 20
MAX_REQUESTS_PER_5_MIN = 30
BLOCK_DURATION_HOURS = 24
REQUEST_WINDOW_1MIN = 60
REQUEST_WINDOW_5MIN = 300

NEW_VEHICLE_API = "https://chass-id-info.princewebz.workers.dev/info?vehicle="
REQUEST_TIMEOUT = 20
MAX_RETRIES = 3

WORKING_COOKIES = {
    "JSESSIONID": "06A35CACFA7F12C4158E399F24E62CC9",
    "SERVERID_175": "vahan_ser8095",
    "SERVERID_135": "vahan_ser8081"
}

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Cache-Control": "no-cache",
    "Upgrade-Insecure-Requests": "1"
}

AJAX_HEADERS = {
    "Accept": "application/xml, text/xml, */*; q=0.01",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Faces-Request": "partial/ajax",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": "https://vahan.parivahan.gov.in"
}

_session_cache = {}
_session_cache_time = {}

def rate_limit():
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            client_ip = request.remote_addr
            if request.headers.get('X-Forwarded-For'):
                client_ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()
            
            current_time = time.time()
            
            if client_ip in blocked_ips:
                block_until = blocked_ips[client_ip]
                if current_time < block_until:
                    remaining_time = int((block_until - current_time) / 3600)
                    return jsonify({
                        "error": "IP blocked due to rate limit violation",
                        "message": f"Your IP is blocked for approximately {remaining_time} hours",
                        "unblock_time": datetime.fromtimestamp(block_until).isoformat(),
                        "status": "blocked"
                    }), 429
                else:
                    del blocked_ips[client_ip]
                    if client_ip in ip_requests:
                        del ip_requests[client_ip]
            
            if client_ip in ip_requests:
                ip_requests[client_ip] = [
                    t for t in ip_requests[client_ip] 
                    if current_time - t <= REQUEST_WINDOW_5MIN
                ]
            
            five_min_requests = len(ip_requests.get(client_ip, []))
            if five_min_requests >= MAX_REQUESTS_PER_5_MIN:
                blocked_ips[client_ip] = current_time + (BLOCK_DURATION_HOURS * 3600)
                logger.warning(f"IP {client_ip} blocked for 24 hours - 5-minute limit exceeded")
                return jsonify({
                    "error": "Rate limit exceeded",
                    "message": f"Maximum {MAX_REQUESTS_PER_5_MIN} requests per 5 minutes allowed. IP blocked for {BLOCK_DURATION_HOURS} hours.",
                    "status": "blocked",
                    "block_duration_hours": BLOCK_DURATION_HOURS
                }), 429
            
            if client_ip in ip_requests:
                one_min_requests = len([
                    t for t in ip_requests[client_ip] 
                    if current_time - t <= REQUEST_WINDOW_1MIN
                ])
                if one_min_requests >= MAX_REQUESTS_PER_MINUTE:
                    blocked_ips[client_ip] = current_time + (BLOCK_DURATION_HOURS * 3600)
                    logger.warning(f"IP {client_ip} blocked for 24 hours - 1-minute limit exceeded")
                    return jsonify({
                        "error": "Rate limit exceeded",
                        "message": f"Maximum {MAX_REQUESTS_PER_MINUTE} requests per minute allowed. IP blocked for {BLOCK_DURATION_HOURS} hours.",
                        "status": "blocked",
                        "block_duration_hours": BLOCK_DURATION_HOURS
                    }), 429
            
            ip_requests[client_ip].append(current_time)
            
            remaining_5min = MAX_REQUESTS_PER_5_MIN - five_min_requests - 1
            remaining_1min = MAX_REQUESTS_PER_MINUTE - len([
                t for t in ip_requests.get(client_ip, []) 
                if current_time - t <= REQUEST_WINDOW_1MIN
            ])
            
            logger.info(f"Rate limit - IP: {client_ip}, Remaining 5min: {remaining_5min}, Remaining 1min: {remaining_1min}")
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def extract_viewstate(text: str) -> Optional[str]:
    patterns = [
        r'<input[^>]*name="javax\.faces\.ViewState"[^>]*value="([^"]+)"',
        r'<input[^>]*name="j_id1:javax\.faces\.ViewState:0"[^>]*value="([^"]+)"',
        r'<update id="j_id1:javax\.faces\.ViewState:0"><!\[CDATA\[(.*?)\]\]></update>',
        r'<update id="[^"]*ViewState[^"]*"><!\[CDATA\[(.*?)\]\]></update>',
        r'javax\.faces\.ViewState[^>]*value="([^"]+)"',
        r'ViewState:0">(.*?)</update>'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            vs = match.group(1).strip()
            if '%' in vs:
                try:
                    vs = requests.utils.unquote(vs)
                except:
                    pass
            return vs
    return None

def extract_mobile_from_response(text: str) -> Optional[str]:
    cdata_matches = re.findall(r'<!\[CDATA\[(.*?)\]\]>', text, re.DOTALL)
    search_text = text
    if cdata_matches:
        search_text = ' '.join(cdata_matches)
    
    patterns = [
        r'id="[^"]*tf_mobile[^"]*"[^>]*value="([6-9]\d{9})"',
        r'value="([6-9]\d{9})"[^>]*id="[^"]*tf_mobile[^"]*"',
        r'tf_mobile[^>]*value="([6-9]\d{9})"',
        r'<input[^>]*value="([6-9]\d{9})"[^>]*id="[^"]*mobile[^"]*"',
        r'value="([6-9]\d{9})"[^>]*id="[^"]*mobile[^"]*"',
        r'<input[^>]*id="[^"]*mobile[^"]*"[^>]*value="([6-9]\d{9})"',
        r'\b([6-9]\d{9})\b'
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, search_text)
        for match in matches:
            if len(match) == 10 and match[0] in '6789':
                if not match.startswith(('60', '70')):
                    return match
    return None

def get_chassis_last5(rc: str) -> Tuple[Optional[str], Optional[Dict]]:
    for attempt in range(MAX_RETRIES):
        try:
            logger.info(f"Fetching vehicle details for {rc} (attempt {attempt + 1}/{MAX_RETRIES})")
            response = requests.get(
                NEW_VEHICLE_API + rc,
                timeout=REQUEST_TIMEOUT,
                headers={"User-Agent": "Mozilla/5.0"}
            )
            data = response.json()

            if data.get("statusCode") != 200:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(random.uniform(1, 3))
                    continue
                return None, None

            chassis = data.get("response", {}).get("chassis", "")
            if not chassis or chassis == "N/A":
                if attempt < MAX_RETRIES - 1:
                    time.sleep(random.uniform(1, 3))
                    continue
                return None, None

            return chassis[-5:], data.get("response", {})

        except Exception as e:
            logger.error(f"Chassis fetch error (attempt {attempt + 1}): {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(random.uniform(2, 5))
                continue
            return None, None
    
    return None, None

def get_mobile(rc: str, last5: str, force_fresh: bool = False) -> Optional[str]:
    if force_fresh:
        cache_key = f"session_{rc[:6]}"
        if cache_key in _session_cache:
            del _session_cache[cache_key]
            del _session_cache_time[cache_key]
        logger.info(f"Force fresh: Cleared session for {rc}")
    
    session = get_cached_session(rc)
    if not session:
        session = requests.Session()
        for key, value in WORKING_COOKIES.items():
            session.cookies.set(key, value)
        session.headers.update(DEFAULT_HEADERS)
        cache_session(rc, session)
    
    URLS = {
        "homepage": "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml",
        "homepage_enc": "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml?statecd=Mzc2MzM2MzAzNjY0MzIzODM3NjIzNjY0MzY2MjM3NDQ0Yw==",
        "login": "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/usermgmt/login.xhtml",
        "fitness": "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/balanceservice/form_reschedule_fitness.xhtml"
    }
    
    for attempt in range(MAX_RETRIES):
        try:
            logger.info(f"Fetching mobile for {rc} (attempt {attempt + 1}/{MAX_RETRIES})")
            
            r = session.get(URLS["homepage_enc"], timeout=REQUEST_TIMEOUT)
            r.raise_for_status()
            
            vs = extract_viewstate(r.text)
            if not vs:
                r = session.get(URLS["homepage"], timeout=REQUEST_TIMEOUT)
                vs = extract_viewstate(r.text)
                if not vs:
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(random.uniform(2, 4))
                        continue
                    return None
            
            cid = "j_idt196"
            cm = re.search(r'<div[^>]*id="(j_idt\d+)"[^>]*class="[^"]*ui-chkbox', r.text)
            if cm:
                cid = cm.group(1)
            
            r = session.post(URLS["homepage"], headers=AJAX_HEADERS, data={
                "javax.faces.partial.ajax": "true",
                "javax.faces.source": "fit_c_office_to",
                "javax.faces.partial.execute": "fit_c_office_to",
                "javax.faces.behavior.event": "change",
                "homepageformid": "homepageformid",
                "fit_c_office_to_input": "1",
                "javax.faces.ViewState": vs
            }, timeout=REQUEST_TIMEOUT)
            
            new_vs = extract_viewstate(r.text)
            if new_vs:
                vs = new_vs
            
            r = session.post(URLS["homepage"], headers=AJAX_HEADERS, data={
                "javax.faces.partial.ajax": "true",
                "javax.faces.source": cid,
                "javax.faces.partial.execute": cid,
                "javax.faces.partial.render": "proccedHomeButtonId",
                "javax.faces.behavior.event": "change",
                "homepageformid": "homepageformid",
                f"{cid}_input": "on",
                "javax.faces.ViewState": vs
            }, timeout=REQUEST_TIMEOUT)
            
            new_vs = extract_viewstate(r.text)
            if new_vs:
                vs = new_vs
            
            r = session.post(URLS["homepage"], headers=AJAX_HEADERS, data={
                "javax.faces.partial.ajax": "true",
                "javax.faces.source": "proccedHomeButtonId",
                "javax.faces.partial.execute": "@all",
                "javax.faces.partial.render": "regnid facelesslist portaldownMsgPnl mainhomepagepnl leftmenupnlid leftmenupnlidservdown",
                "proccedHomeButtonId": "proccedHomeButtonId",
                "homepageformid": "homepageformid",
                "j_idt20": "",
                "j_idt49_input": "en",
                "regnid": rc,
                "state_cd_filter": "",
                "fit_c_office_to_filter": "",
                f"{cid}_input": "on",
                "abc": "abc",
                "pmtchk_input": "-1",
                "nocregnno": "",
                "javax.faces.ViewState": vs
            }, timeout=REQUEST_TIMEOUT)
            
            new_vs = extract_viewstate(r.text)
            if new_vs:
                vs = new_vs
            
            dlg = "j_idt530"
            dm = re.search(r'id="(j_idt\d+)"[^>]*class="[^"]*ui-button', r.text)
            if dm:
                dlg = dm.group(1)
            
            r = session.post(URLS["homepage"], headers=AJAX_HEADERS, data={
                "javax.faces.partial.ajax": "true",
                "javax.faces.source": dlg,
                "javax.faces.partial.execute": "@all",
                dlg: dlg,
                "homepageformid": "homepageformid",
                f"{cid}_input": "on",
                "javax.faces.ViewState": vs
            }, timeout=REQUEST_TIMEOUT)
            
            new_vs = extract_viewstate(r.text)
            if new_vs:
                vs = new_vs
            
            r = session.get(URLS["login"] + "?faces-redirect=true",
                           headers={"Referer": URLS["homepage_enc"]},
                           timeout=REQUEST_TIMEOUT)
            
            vs = extract_viewstate(r.text)
            if not vs:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(random.uniform(2, 4))
                    continue
                return None
            
            fit = "j_idt506"
            fm = re.search(r'id="(j_idt\d+)"[^>]*type="submit"', r.text)
            if fm:
                fit = fm.group(1)
            
            r = session.post(URLS["login"], headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "https://vahan.parivahan.gov.in",
                "Referer": URLS["login"] + "?faces-redirect=true"
            }, data={
                "loginForm": "loginForm",
                fit: fit,
                "javax.faces.ViewState": vs,
                "fitbalcTest": "fitbalcTest",
                "pur_cd": "86"
            }, timeout=REQUEST_TIMEOUT)
            
            r = session.get(URLS["fitness"],
                           headers={"Referer": URLS["login"] + "?faces-redirect=true"},
                           timeout=REQUEST_TIMEOUT)
            
            vs = extract_viewstate(r.text)
            if not vs:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(random.uniform(2, 4))
                    continue
                return None
            
            r = session.post(URLS["fitness"],
                            headers={**AJAX_HEADERS, "Referer": URLS["fitness"]},
                            data={
                                "javax.faces.partial.ajax": "true",
                                "javax.faces.source": "balanceFeesFine:validate_dtls",
                                "javax.faces.partial.execute": "@all",
                                "javax.faces.partial.render": "balanceFeesFine:auth_panel",
                                "balanceFeesFine:validate_dtls": "balanceFeesFine:validate_dtls",
                                "balanceFeesFine": "balanceFeesFine",
                                "balanceFeesFine:tf_reg_no": rc,
                                "balanceFeesFine:tf_chasis_no": last5,
                                "javax.faces.ViewState": vs
                            }, timeout=REQUEST_TIMEOUT)
            
            mobile = extract_mobile_from_response(r.text)
            
            if mobile:
                logger.info(f"Mobile number found for {rc}: {mobile}")
                return mobile
            else:
                logger.warning(f"No mobile number found for {rc} (attempt {attempt + 1})")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(random.uniform(3, 6))
                    cache_key = f"session_{rc[:6]}"
                    if cache_key in _session_cache:
                        del _session_cache[cache_key]
                        del _session_cache_time[cache_key]
                    session = requests.Session()
                    for key, value in WORKING_COOKIES.items():
                        session.cookies.set(key, value)
                    session.headers.update(DEFAULT_HEADERS)
                    cache_session(rc, session)
                    continue
                return None
                
        except Exception as e:
            logger.error(f"Mobile fetch error for {rc} (attempt {attempt + 1}): {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(random.uniform(3, 6))
                cache_key = f"session_{rc[:6]}"
                if cache_key in _session_cache:
                    del _session_cache[cache_key]
                    del _session_cache_time[cache_key]
                session = requests.Session()
                for key, value in WORKING_COOKIES.items():
                    session.cookies.set(key, value)
                session.headers.update(DEFAULT_HEADERS)
                cache_session(rc, session)
                continue
            return None
    
    return None

def get_mobile_direct(rc: str, last5: str, force_fresh: bool = False) -> Optional[str]:
    view_state = "zYH2jaeiwoeUVCPjhQ/n0U5CSFASeBCiexPDaX40qOQ1QjUHUGStLsXPFjVjFMAIN6InoieuN0OSuqE0OUSJ47/36P+vnvAYpe2aOhckXZIkp0biMQ4FNqB0ZL/1yKdoWr0xzmvNTvYKkEZ2vcH3DELSKwNbvDJ8aOy+m6OhOA+ph1QIUzQZoqL/ShjyGZVuRz5TWtJbDCypPxp6jU997BsiwcxvAGVFpGZXRX4RLz/4F7Fi/T4/7TlzezKbDEpEEAGdj+IfiliFHkRn88hISsHCC+ba2zuPTNXgnVlgYFeDv9MWsYMqsN4EQ0+JrYfba+XM/5VbNnBKz8TY4obwX8aY6o/zK2g5jqOMw57HpI0p0MZgI1U3p+27LmovpKomuYel2HuS6WshfqWvp2E2aFv17oVKJ3Y+3md+k8mMuxoMCaOoyf7IbZAnZCtnMhQxRptSXnkXuCZahk++JIBcC35d7maVE9wdAHAEsdWEXojpavk7FN7CYLLTBIfsmDagxBfpn2qRMkTWn82zzAM41fywsSIvlXgCEwMFPxuns/VBGFqb/cU8HPCEj2q9NmwBnDh6b48CrykMeQyC3YiQydRC+efyVYfA+lywKOIFYQgKvph7WCf8YdhqLY+e4H+8dOGSibIkt7xqXRE1TA6wky611LMFS/WhHSjj4xJrBbOIesJnxNiwtiN1zWZl4GP6J9n2cduTa5HTOUAsmykwJHlbDaG+T8PPth3F5NlOXhLuOLJ4sln66IDgdtYPWydoWiGl6Paidn0r24Bj9tGWdLB3wBKqVR7IHqwJo+zoXs2Eyl2ogQEuaZQKsBqSifDkkzd888TZDBV07fC9ni5B0IUnTLvxeY6tziP0Aq8x/7h7pReHx4xfr9cF187He0tB1bTVIUrxTvOXUTaV/kjCpXxESqjQzPsInZgWdZh9fLocu0q0H9RCXNrPxwhB0mTCiZrn7gQAYNJl0ZAm5zzTOGNb1eIf2XZIv0RfwNhQqMS2l5y3DRCT7DFVi9gqtzzVKzRG06Aul4ebW09I58YxVUrkeZo89Q0DDT8sIIZZR9EYK33vNwCknaS3wIK+EjTfXZaIkYUXoP2dVQEA6dMeuCnR8BX1UXve5/2YHAgmPKqgNvAHHgNHp41CP9lDytlcaQRQYvDYpZVMcE6OZd99iVxzJRsOJFtugAsrbJT9cJuuMmEe0MDblSXPs2eI7oYyycx0O+zyDbMfpWaEQNZ/Z4PnPhcgIAfsShiiAfuVjqln0rVA3BYg/yiz/K+nCYP5zH2E02pGmg01ghKVGK5kb5EaccsMi6HcdZjxS+6knQvyPsU9p3/JMig1hbUG19SELLuv6HYuurgSXE5mH20Jr7H8XmtxKQZNRJGa1A2SYhXGun7JvrXyd93Ca3EQI7mTewdqutfyf0lgmgdRrtnwhuXHLp5FWxAdfzXvSzK0lJtdNf8JwLILpGj569Mc3fvgb8CJGdz/r+UwlxVURMWoZYsCY0Zoa589Qms/sls/NQRGYVzeyxz2o7rw105R0yHZqGyJGdFuEVUQs0dKGxFbgg4DzH/nlw05t+ovWc9oOK6u1J3OCmcMm0XPZ/uF/q/BeHMUd6/u+kB9mw/DSMEs3Y1MqlAzEl82ZMTue7aFuQhO8D4Oj7MajkTncZd3mtjX6lwwx2uFqaDO/Ympqmf2Z02+LGJzOJ8+7LWWZqwMXJa0RuALJP33oF78pAwgjHNew0AJd1oNtUm3imETmYPYaYnoCqGJBfZ6OOGqBUi8OD1xlAcfUL1aMeBYbKVVYLUe4/aDJBxibBAINebX9sznqQLN6F9/bAiwxZ5BNR9QeK0di41ABoJq1gom2eYS+5saJ3dkHss6Me+Az6z7e/H4kzfqPNmGEgS7FbAEUBiq3rd2jHDvPVarLwkego/I2KAmA0bvTQa3d8T+Pj0qj0g8vLurmmLYqnqMaLBEKds5aPi9y0sZubaej+rQwBNiUt4O"
    
    for attempt in range(MAX_RETRIES):
        try:
            logger.info(f"Direct method for {rc} (attempt {attempt + 1}/{MAX_RETRIES})")
            
            session = requests.Session()
            for key, value in WORKING_COOKIES.items():
                session.cookies.set(key, value)
            
            response = session.post(
                "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/balanceservice/form_reschedule_fitness.xhtml",
                headers=AJAX_HEADERS,
                data={
                    "javax.faces.partial.ajax": "true",
                    "javax.faces.source": "balanceFeesFine:validate_dtls",
                    "javax.faces.partial.execute": "@all",
                    "javax.faces.partial.render": "balanceFeesFine:auth_panel",
                    "balanceFeesFine:validate_dtls": "balanceFeesFine:validate_dtls",
                    "balanceFeesFine": "balanceFeesFine",
                    "balanceFeesFine:tf_reg_no": rc,
                    "balanceFeesFine:tf_chasis_no": last5,
                    "javax.faces.ViewState": view_state
                },
                timeout=REQUEST_TIMEOUT
            )
            
            mobile = extract_mobile_from_response(response.text)
            
            if mobile:
                logger.info(f"Direct method found mobile for {rc}: {mobile}")
                return mobile
            else:
                logger.warning(f"Direct method no mobile for {rc} (attempt {attempt + 1})")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(random.uniform(2, 4))
                    continue
                return None
                
        except Exception as e:
            logger.error(f"Direct method error for {rc} (attempt {attempt + 1}): {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(random.uniform(2, 4))
                continue
            return None
    
    return None

def get_cached_session(vehicle: str) -> Optional[requests.Session]:
    cache_key = f"session_{vehicle[:6]}"
    if cache_key in _session_cache:
        if time.time() - _session_cache_time.get(cache_key, 0) < 600:
            return _session_cache[cache_key]
        else:
            del _session_cache[cache_key]
            del _session_cache_time[cache_key]
    return None

def cache_session(vehicle: str, session: requests.Session):
    cache_key = f"session_{vehicle[:6]}"
    _session_cache[cache_key] = session
    _session_cache_time[cache_key] = time.time()

@app.route("/info", methods=["GET"])
@rate_limit()
def get_vehicle_info():
    start_time = time.time()
    
    vehicle = request.args.get("vehicle", "").strip().upper()
    vehicle = re.sub(r'[^A-Z0-9]', '', vehicle)
    
    force_fresh = request.args.get("refresh", "false").lower() == "true"
    
    if not vehicle:
        return jsonify({
            "error": "Vehicle parameter required",
            "example": "/info?vehicle=AP05CU6210",
            "refresh_example": "/info?vehicle=AP05CU6210&refresh=true"
        }), 400
    
    if len(vehicle) < 4:
        return jsonify({
            "error": "Invalid vehicle number",
            "message": "Vehicle number must be at least 4 characters"
        }), 400
    
    cache_key = f"vehicle_{vehicle}"
    
    if force_fresh:
        cache.delete(cache_key)
        logger.info(f"Force refresh: Cache cleared for {vehicle}")
    
    cached_response = cache.get(cache_key)
    if cached_response and not force_fresh:
        cached_response["cached"] = True
        cached_response["response_time"] = round(time.time() - start_time, 2)
        logger.info(f"Returning cached response for {vehicle}")
        return jsonify(cached_response)
    
    last5, vehicle_details = get_chassis_last5(vehicle)
    
    if not last5 or not vehicle_details:
        return jsonify({
            "error": "Vehicle not found",
            "reg_no": vehicle,
            "response_time": round(time.time() - start_time, 2),
            "retry_hint": "vehicle not found check the vehicle number and Try again"
        }), 404
    
    mobile = get_mobile(vehicle, last5, force_fresh)
    
    if not mobile:
        logger.info("Primary method failed, trying direct method...")
        mobile = get_mobile_direct(vehicle, last5, force_fresh)
    
    response_data = {
        "reg_no": vehicle,
        "chassis": vehicle_details.get("chassis"),
        "chassis_last5": last5,
        "engine": vehicle_details.get("engine"),
        "mobile": mobile if mobile else "Not Available try again after few min.",
        "manufacturer": vehicle_details.get("manufacturer"),
        "vehicle_model": vehicle_details.get("vehicle"),
        "reg_date": vehicle_details.get("regDate"),
        "fuel_type": vehicle_details.get("fuelType"),
        "cubic_capacity": vehicle_details.get("cubicCapacity"),
        "owner_name": vehicle_details.get("owner"),
        "vehicle_class": vehicle_details.get("vehicleClass"),
        "status": vehicle_details.get("status"),
        "response_time": round(time.time() - start_time, 2),
        "cached": False,
        "mobile_found": mobile is not None,
    }
    
    if mobile:
        cache.set(cache_key, response_data, timeout=3600)
        logger.info(f"Cached response for {vehicle}")
    else:
        cache.set(cache_key, response_data, timeout=300)
        logger.info(f"Cached failure response for {vehicle} (5 min)")
    
    return jsonify(response_data)

@app.route("/info/bulk", methods=["POST"])
@rate_limit()
def get_bulk_vehicle_info():
    data = request.get_json()
    
    if not data or "vehicles" not in data:
        return jsonify({
            "error": "vehicles array required",
            "example": {"vehicles": ["DL9C0001", "AP05CU6210"]}
        }), 400
    
    vehicles = data.get("vehicles", [])
    force_fresh = data.get("refresh", False)
    
    if len(vehicles) > 5:
        return jsonify({
            "error": "Too many vehicles in bulk request",
            "max_allowed": 5,
            "requested": len(vehicles)
        }), 400
    
    results = []
    for vehicle in vehicles:
        vehicle = re.sub(r'[^A-Z0-9]', '', vehicle.strip().upper())
        if vehicle:
            last5, vehicle_details = get_chassis_last5(vehicle)
            if last5 and vehicle_details:
                mobile = get_mobile(vehicle, last5, force_fresh)
                if not mobile:
                    mobile = get_mobile_direct(vehicle, last5, force_fresh)
                
                results.append({
                    "reg_no": vehicle,
                    "mobile": mobile if mobile else "Not Available",
                    "chassis_last5": last5,
                    "owner_name": vehicle_details.get("owner"),
                    "vehicle_model": vehicle_details.get("vehicle")
                })
    
    return jsonify({
        "total": len(results),
        "results": results,
        "refresh_used": force_fresh
    })

@app.route("/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "session_count": len(_session_cache),
        "max_retries": MAX_RETRIES,
        "cache_size": len(cache._cache) if hasattr(cache, '_cache') else 0,
        "rate_limiting": {
            "max_requests_per_minute": MAX_REQUESTS_PER_MINUTE,
            "max_requests_per_5min": MAX_REQUESTS_PER_5_MIN,
            "block_duration_hours": BLOCK_DURATION_HOURS,
            "blocked_ips_count": len(blocked_ips),
            "active_ips": len(ip_requests)
        }
    })

@app.route("/clear_cache", methods=["POST"])
def clear_cache():
    cache.clear()
    _session_cache.clear()
    _session_cache_time.clear()
    return jsonify({
        "message": "Cache cleared successfully",
        "timestamp": datetime.now().isoformat()
    })

@app.route("/clear_vehicle_cache", methods=["POST"])
def clear_vehicle_cache():
    vehicle = request.json.get("vehicle", "").strip().upper()
    vehicle = re.sub(r'[^A-Z0-9]', '', vehicle)
    
    if not vehicle:
        return jsonify({"error": "Vehicle parameter required"}), 400
    
    cache_key = f"vehicle_{vehicle}"
    cache.delete(cache_key)
    
    cache_key_session = f"session_{vehicle[:6]}"
    if cache_key_session in _session_cache:
        del _session_cache[cache_key_session]
        del _session_cache_time[cache_key_session]
    
    return jsonify({
        "message": f"Cache cleared for {vehicle}",
        "vehicle": vehicle
    })

@app.route("/rate_limit/status", methods=["GET"])
def rate_limit_status():
    client_ip = request.remote_addr
    if request.headers.get('X-Forwarded-For'):
        client_ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()
    
    current_time = time.time()
    
    if client_ip in blocked_ips:
        block_until = blocked_ips[client_ip]
        if current_time < block_until:
            remaining_hours = int((block_until - current_time) / 3600)
            return jsonify({
                "ip": client_ip,
                "status": "blocked",
                "block_until": datetime.fromtimestamp(block_until).isoformat(),
                "remaining_hours": remaining_hours,
                "message": f"IP blocked for approximately {remaining_hours} hours"
            })
        else:
            del blocked_ips[client_ip]
    
    requests_history = ip_requests.get(client_ip, [])
    requests_history = [t for t in requests_history if current_time - t <= REQUEST_WINDOW_5MIN]
    
    one_min_requests = len([t for t in requests_history if current_time - t <= REQUEST_WINDOW_1MIN])
    five_min_requests = len(requests_history)
    
    return jsonify({
        "ip": client_ip,
        "status": "active",
        "requests_last_minute": one_min_requests,
        "requests_last_5_minutes": five_min_requests,
        "remaining_1min": MAX_REQUESTS_PER_MINUTE - one_min_requests,
        "remaining_5min": MAX_REQUESTS_PER_5_MIN - five_min_requests,
        "limits": {
            "max_1min": MAX_REQUESTS_PER_MINUTE,
            "max_5min": MAX_REQUESTS_PER_5_MIN,
            "block_duration_hours": BLOCK_DURATION_HOURS
        }
    })

@app.route("/rate_limit/unblock", methods=["POST"])
def unblock_ip():
    ip_to_unblock = request.json.get("ip")
    
    if not ip_to_unblock:
        return jsonify({"error": "IP parameter required"}), 400
    
    if ip_to_unblock in blocked_ips:
        del blocked_ips[ip_to_unblock]
        if ip_to_unblock in ip_requests:
            del ip_requests[ip_to_unblock]
        return jsonify({
            "message": f"IP {ip_to_unblock} unblocked successfully",
            "timestamp": datetime.now().isoformat()
        })
    else:
        return jsonify({
            "message": f"IP {ip_to_unblock} is not blocked",
            "timestamp": datetime.now().isoformat()
        })

def handler(request):
    return app(request)

if __name__ == "__main__":
    print("=" * 60)
    print("VAHAN PORTAL API - Enhanced with Rate Limiting")
    print("=" * 60)
    print(f"Rate Limits:")
    print(f"  - Max {MAX_REQUESTS_PER_MINUTE} requests per minute")
    print(f"  - Max {MAX_REQUESTS_PER_5_MIN} requests per 5 minutes")
    print(f"  - Block duration: {BLOCK_DURATION_HOURS} hours")
    print(f"\nMax Retries: {MAX_RETRIES}")
    print(f"Server running on http://0.0.0.0:5003")
    print("\nEndpoints:")
    print("  GET  /info?vehicle=DL9C0001")
    print("  GET  /info?vehicle=DL9C0001&refresh=true")
    print("  POST /info/bulk (max 5 vehicles)")
    print("  GET  /health")
    print("  GET  /rate_limit/status")
    print("  POST /rate_limit/unblock (admin)")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5003, debug=False, threaded=True)