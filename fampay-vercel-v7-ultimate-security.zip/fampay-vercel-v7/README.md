# UPI Payment Verifier v7.0 — Ultimate Security Edition

## One-Click Vercel Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_REPO)

---

## Features

| Category | Features |
|---|---|
| 🔒 Security | Rate limiting (IP), JWT access + refresh tokens, 2FA TOTP, CORS hardening, security headers (CSP, HSTS, X-Frame, XSS), IP whitelist/blacklist, input sanitization, audit logging, anti double-spend, webhook HMAC-SHA256 |
| 🧠 UTR Engine | 30+ patterns, fuzzy matching (SequenceMatcher), confidence scoring 0-100, multi-bank support |
| 📧 Email | Multi-account Gmail IMAP, FamPay + generic UPI email support |
| 🔔 Alerts | Telegram bot notifications, outbound signed webhooks |
| 💳 Subscriptions | Auto-pay subscription management API |
| 🛡️ Admin | JWT-protected admin dashboard, audit log, IP blacklist management |

---

## Deploy to Vercel

### Step 1 — Upload this folder to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
cd fampay-vercel-v7
vercel deploy --prod
```

### Step 2 — Set Environment Variables in Vercel Dashboard

Go to: **Vercel Dashboard → Your Project → Settings → Environment Variables**

| Variable | Required | Description |
|---|---|---|
| `RECEIVER_EMAIL` | ✅ | Gmail address of FamPay receiver |
| `RECEIVER_PASSWORD` | ✅ | Gmail App Password (generate at myaccount.google.com → Security → App Passwords) |
| `JWT_SECRET` | ✅ | Long random string, e.g. `openssl rand -hex 32` |
| `ADMIN_PASSWORD_HASH` | ✅ | bcrypt hash — call `POST /api/auth/hash` with `{"password":"yourpw"}` to get it |
| `TOTP_SECRET` | Optional | Base32 2FA secret. Generate: `python3 -c "import pyotp; print(pyotp.random_base32())"` |
| `TELEGRAM_BOT_TOKEN` | Optional | From @BotFather on Telegram |
| `TELEGRAM_CHAT_ID` | Optional | Your chat/channel ID |
| `WEBHOOK_SECRET` | Optional | HMAC secret for signed outbound webhooks |
| `WEBHOOK_URL` | Optional | URL to POST payment events to |
| `EXTRA_EMAILS` | Optional | Additional Gmail accounts: `email1:pass1,email2:pass2` |
| `ALLOWED_ORIGINS` | Optional | CORS origins (default `*`) |
| `IP_WHITELIST` | Optional | Comma-separated IPs that skip rate limiting |
| `IP_BLACKLIST` | Optional | Comma-separated banned IPs |
| `SCAN_WINDOW_MIN` | Optional | Minutes to scan back (default `15`) |
| `RATE_LIMIT_MAX` | Optional | Max requests per 15 min per IP (default `60`) |

---

## API Reference

### Public Endpoints

```
GET  /api/healthz
GET  /api/verify?txn_id=UTR123&amount=99
POST /api/verify           { "txn_id": "...", "amount": "..." }
POST /api/verify/webhook   Signed webhook (X-Signature-SHA256 header required)
```

### Auth Endpoints

```
POST /api/auth/login   { "password": "...", "totp_code": "..." }  → access_token + refresh_token
POST /api/auth/refresh { "refresh_token": "..." }                 → access_token
POST /api/auth/hash    { "password": "plaintext" }                → bcrypt hash (setup helper)
```

### Admin Endpoints (Bearer token required)

```
GET    /api/admin/stats
GET    /api/admin/audit?limit=50
GET    /api/admin/verified-utrs
GET    /api/admin/blacklist
POST   /api/admin/blacklist    { "ip": "1.2.3.4" }
DELETE /api/admin/blacklist    { "ip": "1.2.3.4" }
POST   /api/admin/telegram-test
```

### Subscription Endpoints (Bearer token required)

```
GET    /api/subscriptions
POST   /api/subscriptions   { "name": "Pro Plan", "amount": "99", "interval": "monthly" }
DELETE /api/subscriptions/:id
```

---

## Security Architecture

```
Request
  ↓
[IP Blacklist Check]  → 403
  ↓
[Rate Limit]          → 429 (X-RateLimit-Limit / Remaining headers)
  ↓
[Security Headers]    → CSP, HSTS, X-Frame-Options, XSS protection
  ↓
[Input Sanitization]  → XSS stripping, control char removal, length limits
  ↓
[JWT Validation]      → For protected routes
  ↓
[TOTP 2FA]            → For admin login
  ↓
[Business Logic]
  ↓
[Audit Log]           → Every request/result logged
  ↓
[Webhook + Telegram]  → Outbound signed notifications
```

---

## UTR Patterns (30+)

- NPCI 12-digit UTR (all banks)
- FamPay FMPIB / FMP prefixes
- Labelled UTR / UPI Ref / RRN
- PhonePe, GPay, Paytm, BHIM
- ICICI, HDFC, SBI, Axis (UTIB), Kotak (KKBK), Yes Bank (YBL/YESB)
- PNB, Bank of Baroda, Canara, Union Bank, Indian Overseas
- Generic bank code patterns (BANKCODE + digits)
- Order ID, TID, Approval Code

Matching uses **fuzzy SequenceMatcher** with confidence scoring — handles typos, prefix labels, and partial matches.

---

## Gmail App Password Setup

1. Go to myaccount.google.com
2. Security → 2-Step Verification → ON
3. Security → App Passwords → Generate
4. Select "Mail" + device → Copy 16-char password
5. Set as `RECEIVER_PASSWORD` in Vercel (with or without spaces)

---

## Version History

| Version | Key Feature |
|---|---|
| v1.0 | Basic payment QR + SQLite |
| v2.0 | Custom amount, auto-pay, webhooks |
| v3.0 | MongoDB Atlas, multi-account |
| v4.0 | JWT auth, admin dashboard, API keys |
| v5.0 | 30+ UTR patterns, fuzzy match, confidence |
| v6.0 | Telegram bot, /stats, security alerts |
| **v7.0** | **Rate limiting, refresh tokens, HTTPS headers, injection prevention, XSS protection, CORS hardening, Helmet headers, IP whitelist/blacklist, request validation, audit logging, 2FA TOTP, webhook signatures** |
